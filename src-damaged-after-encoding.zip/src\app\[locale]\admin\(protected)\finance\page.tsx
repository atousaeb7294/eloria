﻿import Link from "next/link";

import {
  AlertTriangle,
  BarChart3,
  Banknote,
  CircleDollarSign,
  Download,
  FilePlus2,
  ReceiptText,
  RotateCcw,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  TrendingDown,
  TrendingUp,
  WalletCards,
} from "lucide-react";

import {
  notFound,
} from "next/navigation";

import {
  formatAdminDate,
  formatAdminMoney,
} from "@/lib/admin-format";
import {
  getAdminFinanceReport,
} from "@/lib/admin-finance";
import {
  saveFinanceExpenseAction,
  voidFinanceExpenseAction,
} from "@/app/[locale]/admin/(protected)/finance/actions";
import {
  financeExpenseCategories,
  getFinanceExpenseCategoryLabel,
} from "@/lib/finance-expense";
import {
  financePeriods,
  formatFinancePeriod,
  parseFinancePeriod,
  percentageChange,
  percentageOf,
  type FinancePeriod,
} from "@/lib/finance-analytics";

export const dynamic =
  "force-dynamic";

export const revalidate = 0;

function singleValue(
  value:
    | string
    | string[]
    | undefined,
): string | undefined {
  return Array.isArray(value)
    ? value[0]
    : value;
}

function formatPercentage(
  value: number,
): string {
  return `${new Intl.NumberFormat(
    "fa-IR",
    {
      maximumFractionDigits: 1,
    },
  ).format(value)}٪`;
}

function periodHref(
  locale: string,
  period: FinancePeriod,
): string {
  return `/${locale}/admin/finance?period=${period}`;
}

function exportHref(
  locale: string,
  period: FinancePeriod,
  mode: "ledger" | "audit",
): string {
  return `/${locale}/admin/finance/export?period=${period}&mode=${mode}`;
}

function changeSummary(
  change: number | null,
  currentValue: bigint,
): string {
  if (
    change === null
  ) {
    return currentValue > 0n
      ? "�?خست�O�? فر�^ش در ا�O�? باز�?"
      : "�?�?�^ز �.ب�?ا�O �.�,ا�Oس�?�?Oا�O �?�Oست";
  }

  if (
    change === 0
  ) {
    return "بد�^�? تغ�O�Oر �?سبت ب�? باز�? �,ب�"";
  }

  return `${formatPercentage(
    Math.abs(change),
  )} ${change > 0 ? "رشد" : "کا�?ش"} �?سبت ب�? باز�? �,ب�"`;
}

function formatSignedMoney(
  value: bigint,
): string {
  if (value === 0n) {
    return formatAdminMoney(value);
  }

  return `${value > 0n ? "+" : "�^'"}${formatAdminMoney(
    value > 0n ? value : -value,
  )}`;
}

type InsightTone =
  | "emerald"
  | "gold"
  | "amber"
  | "red"
  | "slate";

export default async function AdminFinancePage({
  params,
  searchParams,
}: {
  params: Promise<{
    locale: string;
  }>;
  searchParams: Promise<{
    period?: string | string[];
    expenseSaved?: string | string[];
    expenseVoided?: string | string[];
    expenseError?: string | string[];
  }>;
}) {
  const {
    locale,
  } = await params;

  if (
    locale !== "fa" &&
    locale !== "en"
  ) {
    notFound();
  }

  const query =
    await searchParams;

  const period =
    parseFinancePeriod(
      singleValue(
        query.period,
      ),
    );

  const report =
    await getAdminFinanceReport(
      period,
    );

  const salesChange =
    percentageChange(
      report.salesToman,
      report.previousSalesToman,
    );

  const marginRate =
    percentageOf(
      report.priceMarginToman,
      report.salesToman,
    );

  const refundRate =
    percentageOf(
      report.refundedToman,
      report.receivedToman,
    );

  const maxDailyRevenue =
    report.dailySales.reduce(
      (maximum, point) =>
        point.revenueToman >
        maximum
          ? point.revenueToman
          : maximum,
      0n,
    );

  const firstDay =
    report.dailySales[0];

  const lastDay =
    report.dailySales[
      report.dailySales.length - 1
    ];

  const topProduct =
    report.topProducts[0];

  const expenseDate =
    report.range.dayKeys.at(-1) ?? "";

  const expenseError =
    singleValue(
      query.expenseError,
    )?.slice(0, 400);

  const reconciliationIsClear =
    report.reconciliation.mismatchCount === 0 &&
    report.reconciliation.paymentReview.count === 0;

  const insights: Array<{
    tone: InsightTone;
    title: string;
    body: string;
  }> = [
    report.salesToman > 0n
      ? {
          tone: "emerald",
          title:
            salesChange !== null &&
            salesChange < 0
              ? "فر�^ش �?�Oاز ب�? ت�^ج�? دارد"
              : "ر�^�?د فر�^ش",
          body: changeSummary(
            salesChange,
            report.salesToman,
          ),
        }
      : {
          tone: "amber",
          title: "فر�^ش �,طع�O ثبت �?شد�?",
          body: "برا�O �?�.ا�Oش تح�"�O�"�O با�Oد حدا�,�" �Oک پرداخت تأ�O�Oدشد�? در ا�O�? باز�? �^ج�^د داشت�? باشد.",
        },
    reconciliationIsClear
      ? {
          tone: "emerald",
          title: "تطب�O�, پرداخت پاک است",
          body: `${new Intl.NumberFormat("fa-IR").format(report.reconciliation.inspectedOrderCount)} سفارش پرداخت�?Oشد�? با �.ب�"غ ثبت�?Oشد�? در درگا�? تطب�O�, داد�? شد.`,
        }
      : {
          tone: "red",
          title: "�.غا�Oرت پرداخت �?�Oاز�.�?د رس�Oدگ�O است",
          body: `${new Intl.NumberFormat("fa-IR").format(report.reconciliation.mismatchCount)} سفارش دارا�O اخت�"اف �^ ${new Intl.NumberFormat("fa-IR").format(report.reconciliation.paymentReview.count)} پرداخت در صف بررس�O است.`,
        },
    report.expenses.count > 0
      ? {
          tone: "gold",
          title: "دفتر �?ز�O�?�? ب�?�?Oر�^ز است",
          body: `${new Intl.NumberFormat("fa-IR").format(report.expenses.count)} س�?د �?ز�O�?�?�" فعا�" ب�? ارزش ${formatAdminMoney(report.expenses.totalToman)} در ا�O�? باز�? ثبت شد�? است.`,
        }
      : {
          tone: "amber",
          title: "�?ز�O�?�?�?Oا�O ثبت �?شد�?",
          body: "تا �^�,ت�O خر�Oد�O ارسا�"�O ح�,�^�, �^ �?ز�O�?�?�?O�?ا�O ب�Oر�^�?�O ثبت �?ش�^�?د�O جر�Oا�? �?�,د�Oِ پس از �?ز�O�?�? کا�.�" �?�Oست.",
        },
    topProduct
      ? {
          tone: "gold",
          title: "�.حص�^�" پ�Oشتاز",
          body: `${topProduct.name} با ${new Intl.NumberFormat("fa-IR").format(topProduct.quantity)} عدد �^ ${formatAdminMoney(topProduct.revenueToman)} فر�^ش.`,
        }
      : {
          tone: "slate",
          title: "داد�?�" �.حص�^�" کاف�O �?�Oست",
          body: "پس از پرداخت سفارش�?O�?ا�O پرفر�^ش�?Oتر�O�? �.حص�^�"ات ا�O�?جا ظا�?ر �.�O�?Oش�^�?د.",
        },
    refundRate &&
    refundRate > 0
      ? {
          tone: refundRate >= 5
            ? "red"
            : "amber",
          title: "�?رخ بازپرداخت",
          body: `${formatPercentage(refundRate)} از در�Oافت�O ا�O�? باز�? بازپرداخت شد�? است.`,
        }
      : {
          tone: "slate",
          title: "بازپرداخت�O در ا�O�? باز�? �?�Oست",
          body: "اگر بازپرداخت ا�?جا�. ش�^د�O ف�,ط پس از ثبت ش�.ار�? �.رجع با�?ک�O در �.حاسبات �^ارد �.�O�?Oش�^د.",
        },
  ];

  const insightTone: Record<
    InsightTone,
    string
  > = {
    emerald:
      "border-emerald-300/15 bg-emerald-950/15 text-emerald-100",
    gold:
      "border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#f1d98a]",
    amber:
      "border-amber-300/15 bg-amber-950/15 text-amber-100",
    red:
      "border-red-300/15 bg-red-950/15 text-red-100",
    slate:
      "border-white/10 bg-white/[0.025] text-[#d9caa9]",
  };

  const saveExpense =
    saveFinanceExpenseAction.bind(
      null,
      locale,
    );

  return (
    <div className="space-y-7">
      <header className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
        <div>
          <p className="text-xs tracking-[0.25em] text-[#b99e4f]">
            دفتر �.ا�"�O �^ حسابرس�O
          </p>
          <h1 className="mt-2 text-2xl font-semibold text-[#f7e4b6] sm:text-3xl">
            حسابدار�O ع�.�"�Oات�O ا�"�^ر�Oا
          </h1>
          <p className="mt-2 max-w-3xl text-sm leading-7 text-[#9f9279]">
            فر�^ش �^ پرداخت از سفارش�?O�?ا�O �^ا�,ع�O خ�^ا�?د�? �.�O�?Oش�^د�> �?ز�O�?�?�?O�?ا ف�,ط با ثبت س�?د �^ارد �.�O�?Oش�^�?د �^ �?�O�? س�?د�O از پ�?�" حذف �?�.�O�?Oش�^د.
          </p>
        </div>

        <nav
          aria-label="باز�?�" گزارش"
          className="flex w-full flex-wrap gap-1.5 rounded-2xl border border-[#d0b359]/15 bg-[#041d15]/82 p-1.5 xl:w-fit"
        >
          {financePeriods.map(
            option => (
              <Link
                key={option}
                href={periodHref(
                  locale,
                  option,
                )}
                aria-current={
                  period === option
                    ? "page"
                    : undefined
                }
                className={`flex-1 whitespace-nowrap rounded-xl px-3 py-2.5 text-center text-sm transition sm:flex-none sm:px-4 ${period === option ? "bg-[#d2b55f] font-semibold text-[#10251c]" : "text-[#cdbf9f] hover:bg-white/5 hover:text-[#f0d981]"}`}
              >
                {formatFinancePeriod(option)}
              </Link>
            ),
          )}
        </nav>
      </header>

      {expenseError ? (
        <div
          role="alert"
          className="rounded-2xl border border-red-300/20 bg-red-950/25 px-4 py-3 text-sm leading-7 text-red-100"
        >
          {expenseError}
        </div>
      ) : null}

      {singleValue(query.expenseSaved) === "1" ? (
        <div className="rounded-2xl border border-emerald-300/20 bg-emerald-950/25 px-4 py-3 text-sm leading-7 text-emerald-100">
          س�?د �?ز�O�?�? ثبت شد �^ �Oک ر�^�Oداد حسابرس�O برا�O آ�? ساخت�? شد.
        </div>
      ) : null}

      {singleValue(query.expenseVoided) === "1" ? (
        <div className="rounded-2xl border border-amber-300/20 bg-amber-950/25 px-4 py-3 text-sm leading-7 text-amber-100">
          س�?د حذف �?شد�> با د�"�O�" ش�.ا باط�" شد �^ ساب�,�?�" آ�? برا�O حسابرس�O حفظ شد�? است.
        </div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 shadow-[0_18px_55px_rgba(0,0,0,0.17)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-[#a99c82]">
                فر�^ش �,طع�O
              </p>
              <p className="mt-3 text-xl font-semibold text-[#f5e4bb] sm:text-2xl">
                {formatAdminMoney(report.salesToman)}
              </p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-emerald-300/15 bg-emerald-950/20 text-emerald-200">
              <ShoppingBag className="h-5 w-5" />
            </span>
          </div>
          <div className="mt-4 flex flex-wrap gap-x-3 gap-y-1 text-xs leading-6 text-[#a99c82]">
            <span>{new Intl.NumberFormat("fa-IR").format(report.orderCount)} سفارش پرداخت�?Oشد�?</span>
            <span className={salesChange !== null && salesChange < 0 ? "text-orange-200" : "text-emerald-200"}>
              {changeSummary(salesChange, report.salesToman)}
            </span>
          </div>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 shadow-[0_18px_55px_rgba(0,0,0,0.17)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-[#a99c82]">
                �?�,د�O�?گ�O پس از �?ز�O�?�?
              </p>
              <p className={`mt-3 text-xl font-semibold sm:text-2xl ${report.netCashAfterExpensesToman < 0n ? "text-red-200" : "text-[#f5e4bb]"}`}>
                {formatAdminMoney(report.netCashAfterExpensesToman)}
              </p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-sky-300/15 bg-sky-950/20 text-sky-200">
              <WalletCards className="h-5 w-5" />
            </span>
          </div>
          <p className="mt-4 text-xs leading-6 text-[#a99c82]">
            {formatAdminMoney(report.receivedToman)} در�Oافت�O �^' {formatAdminMoney(report.refundedToman)} بازپرداخت �^' {formatAdminMoney(report.expenses.totalToman)} �?ز�O�?�?
          </p>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 shadow-[0_18px_55px_rgba(0,0,0,0.17)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-[#a99c82]">
                �?ز�O�?�?�?O�?ا�O ثبت�?Oشد�?
              </p>
              <p className="mt-3 text-xl font-semibold text-[#f5e4bb] sm:text-2xl">
                {formatAdminMoney(report.expenses.totalToman)}
              </p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-orange-300/15 bg-orange-950/20 text-orange-200">
              <ReceiptText className="h-5 w-5" />
            </span>
          </div>
          <p className="mt-4 text-xs leading-6 text-[#a99c82]">
            {new Intl.NumberFormat("fa-IR").format(report.expenses.count)} س�?د فعا�"�> شا�.�" {formatAdminMoney(report.expenses.taxToman)} �.ا�"�Oات س�?د
          </p>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 shadow-[0_18px_55px_rgba(0,0,0,0.17)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-[#a99c82]">
                �?ت�Oج�?�" ع�.�"�Oات�O
              </p>
              <p className={`mt-3 text-xl font-semibold sm:text-2xl ${report.operatingResultToman < 0n ? "text-red-200" : "text-[#f5e4bb]"}`}>
                {formatAdminMoney(report.operatingResultToman)}
              </p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#e4c870]">
              <CircleDollarSign className="h-5 w-5" />
            </span>
          </div>
          <p className="mt-4 text-xs leading-6 text-[#a99c82]">
            حاش�O�?�" ثبت�?Oشد�? {formatAdminMoney(report.priceMarginToman)}{marginRate === null ? "" : ` (${formatPercentage(marginRate)} از فر�^ش)`} �^' �?ز�O�?�?�" ع�.�"�Oات�O {formatAdminMoney(report.expenses.operatingToman)}
          </p>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 shadow-[0_18px_55px_rgba(0,0,0,0.17)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-[#a99c82]">
                خر�Oد کا�"ا �^ ط�"ا
              </p>
              <p className="mt-3 text-xl font-semibold text-[#f5e4bb] sm:text-2xl">
                {formatAdminMoney(report.expenses.inventoryPurchaseToman)}
              </p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-violet-300/15 bg-violet-950/20 text-violet-200">
              <Banknote className="h-5 w-5" />
            </span>
          </div>
          <p className="mt-4 text-xs leading-6 text-[#a99c82]">
            ا�O�? بخش جدا �?گ�? داشت�? �.�O�?Oش�^د تا با �.�^ج�^د�O �^ ب�?ا�O ت�.ا�.�?Oشد�? اشتبا�? �?ش�^د.
          </p>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 shadow-[0_18px_55px_rgba(0,0,0,0.17)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-[#a99c82]">
                �.�Oا�?گ�O�? �?ر سفارش
              </p>
              <p className="mt-3 text-xl font-semibold text-[#f5e4bb] sm:text-2xl">
                {formatAdminMoney(report.averageOrderToman)}
              </p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-violet-300/15 bg-violet-950/20 text-violet-200">
              <Banknote className="h-5 w-5" />
            </span>
          </div>
          <p className="mt-4 text-xs leading-6 text-[#a99c82]">
            ف�,ط سفارش�?O�?ا�O�O ک�? پرداختشا�? تأ�O�Oد شد�? است.
          </p>
        </article>
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.3fr_0.7fr]">
        <article className="rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 sm:p-6">
          <header className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl border border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#e4c870]">
                <BarChart3 className="h-5 w-5" />
              </span>
              <div>
                <h2 className="font-semibold text-[#efd782]">
                  ر�^�?د فر�^ش ر�^زا�?�?
                </h2>
                <p className="mt-1 text-xs text-[#8f846d]">
                  فر�^ش �,طع�O در {formatFinancePeriod(period)}
                </p>
              </div>
            </div>

            <span className="rounded-lg bg-[#d1b45d]/8 px-2.5 py-1 text-xs text-[#dcc573]">
              {formatAdminMoney(report.salesToman)}
            </span>
          </header>

          {maxDailyRevenue > 0n ? (
            <div className="mt-8">
              <div className="flex h-52 items-end gap-1" aria-label="�?�.�^دار فر�^ش ر�^زا�?�?">
                {report.dailySales.map(
                  point => {
                    const height = Math.max(
                      4,
                      Number(
                        (point.revenueToman * 100n) /
                          maxDailyRevenue,
                      ),
                    );

                    return (
                      <div
                        key={point.key}
                        className="group relative flex h-full min-w-0 flex-1 items-end"
                        title={`${point.label}: ${formatAdminMoney(point.revenueToman)} (${new Intl.NumberFormat("fa-IR").format(point.orderCount)} سفارش)`}
                      >
                        <div
                          style={{
                            height: `${height}%`,
                          }}
                          className="w-full rounded-t-md bg-[linear-gradient(180deg,#efda87,#a77d31)] opacity-90 transition group-hover:opacity-100"
                        />
                      </div>
                    );
                  },
                )}
              </div>
              <div className="mt-3 flex items-center justify-between text-[11px] text-[#8f846d]">
                <span>{firstDay?.label}</span>
                <span>�?ر ست�^�? �Oک ر�^ز است</span>
                <span>{lastDay?.label}</span>
              </div>
            </div>
          ) : (
            <div className="grid min-h-52 place-items-center rounded-2xl border border-dashed border-[#d0b359]/16 px-5 text-center text-sm leading-7 text-[#91866f]">
              در ا�O�? باز�? �?�?�^ز فر�^ش �,طع�O ثبت �?شد�? است.
            </div>
          )}
        </article>

        <article className="rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl border border-violet-300/15 bg-violet-950/20 text-violet-200">
              <Sparkles className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-semibold text-[#efd782]">
                �?شدار�?ا�O �?�^ش�.�?د
              </h2>
              <p className="mt-1 text-xs text-[#8f846d]">
                �?ت�Oج�?�" �,�^اعد حسابرس�O ر�^�O داد�?�?O�?ا�O �^ا�,ع�O
              </p>
            </div>
          </div>

          <div className="mt-5 space-y-3">
            {insights.map(
              insight => (
                <div
                  key={insight.title}
                  className={`rounded-2xl border p-3.5 ${insightTone[insight.tone]}`}
                >
                  <p className="text-sm font-medium">
                    {insight.title}
                  </p>
                  <p className="mt-1.5 text-xs leading-6 opacity-80">
                    {insight.body}
                  </p>
                </div>
              ),
            )}
          </div>
        </article>
      </section>

      <section className="grid gap-5 xl:grid-cols-[0.92fr_1.08fr]">
        <article className="rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#e4c870]">
              <FilePlus2 className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-semibold text-[#efd782]">
                ثبت س�?د �?ز�O�?�?
              </h2>
              <p className="mt-1 text-xs leading-6 text-[#8f846d]">
                ش�.ار�?�" فاکت�^ر�O رس�Oد ا�?ت�,ا�" �Oا �?ر �.رجع �,اب�" پ�Oگ�Oر�O را ب�?�^�Oس�Oد�> تکرار �Oک �.رجع برا�O �?�.ا�? فر�^ش�?د�? پذ�Oرفت�? �?�.�O�?Oش�^د.
              </p>
            </div>
          </div>

          <form action={saveExpense} className="mt-5 grid gap-3">
            <input type="hidden" name="period" value={period} />

            <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
              دست�?�?Oب�?د�O �?ز�O�?�?
              <select
                name="category"
                required
                defaultValue=""
                className="h-11 rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 text-sm text-[#f4e2b9] outline-none focus:border-[#d8ba62]/55"
              >
                <option value="" disabled>ا�?تخاب ک�?�Oد</option>
                {financeExpenseCategories.map(
                  category => (
                    <option key={category} value={category}>
                      {getFinanceExpenseCategoryLabel(category)}
                    </option>
                  ),
                )}
              </select>
            </label>

            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
                تار�Oخ س�?د
                <input
                  name="occurredAt"
                  type="date"
                  required
                  defaultValue={expenseDate}
                  className="h-11 rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 text-sm text-[#f4e2b9] outline-none focus:border-[#d8ba62]/55"
                />
              </label>
              <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
                �.ب�"غ اص�"�O (ت�^�.ا�?)
                <input
                  name="amountToman"
                  type="text"
                  inputMode="numeric"
                  required
                  maxLength={30}
                  placeholder="�.ثا�": ۱۲۵۰۰۰۰"
                  className="h-11 rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 text-sm text-[#f4e2b9] outline-none placeholder:text-[#776d5a] focus:border-[#d8ba62]/55"
                />
              </label>
            </div>

            <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
              �.ا�"�Oات �Oا ع�^ارض س�?د (ت�^�.ا�?�O اخت�Oار�O)
              <input
                name="taxToman"
                type="text"
                inputMode="numeric"
                maxLength={30}
                placeholder="در ص�^رت �?داشت�?�O خا�"�O بگذار�Oد"
                className="h-11 rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 text-sm text-[#f4e2b9] outline-none placeholder:text-[#776d5a] focus:border-[#d8ba62]/55"
              />
            </label>

            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
                فر�^ش�?د�? �Oا طرف حساب
                <input
                  name="supplier"
                  type="text"
                  required
                  minLength={2}
                  maxLength={160}
                  placeholder="�.ثا�": تا�.�O�?�?Oک�?�?د�? ط�"ا"
                  className="h-11 rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 text-sm text-[#f4e2b9] outline-none placeholder:text-[#776d5a] focus:border-[#d8ba62]/55"
                />
              </label>
              <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
                ش�.ار�?�" فاکت�^ر �Oا رس�Oد
                <input
                  name="reference"
                  type="text"
                  required
                  minLength={3}
                  maxLength={160}
                  placeholder="�.ثا�": inv-1405-101"
                  className="h-11 rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 text-sm text-[#f4e2b9] outline-none placeholder:text-[#776d5a] focus:border-[#d8ba62]/55"
                />
              </label>
            </div>

            <label className="grid gap-1.5 text-sm text-[#cbbd9d]">
              ت�^ض�Oح (اخت�Oار�O)
              <textarea
                name="note"
                maxLength={2000}
                rows={3}
                placeholder="د�"�O�"�O �?�^ع پرداخت �Oا �?ر جزئ�Oات �"از�. برا�O حسابرس�O"
                className="resize-y rounded-xl border border-[#d0b359]/18 bg-[#02150f] px-3 py-2.5 text-sm text-[#f4e2b9] outline-none placeholder:text-[#776d5a] focus:border-[#d8ba62]/55"
              />
            </label>

            <button
              type="submit"
              className="mt-1 inline-flex h-11 items-center justify-center rounded-xl bg-[#d2b55f] px-4 text-sm font-semibold text-[#10251c] transition hover:bg-[#e0c973]"
            >
              ثبت �,طع�O س�?د �^ ر�^�Oداد حسابرس�O
            </button>
          </form>
        </article>

        <article className="overflow-hidden rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82">
          <header className="flex flex-col gap-4 border-b border-[#d0b359]/12 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl border border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#e4c870]">
                <ReceiptText className="h-5 w-5" />
              </span>
              <div>
                <h2 className="font-semibold text-[#efd782]">
                  دفتر �?ز�O�?�? �^ �.ست�?دات
                </h2>
                <p className="mt-1 text-xs text-[#8f846d]">
                  ۸۰ س�?د آخر ا�O�? باز�?�> {new Intl.NumberFormat("fa-IR").format(report.expenses.auditEventCount)} ر�^�Oداد حسابرس�O ثبت�?Oشد�?
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link
                href={exportHref(locale, period, "ledger")}
                className="inline-flex items-center gap-2 rounded-xl border border-[#d0b359]/20 px-3 py-2 text-xs text-[#e2c96f] transition hover:bg-[#d1b45d]/8"
              >
                <Download className="h-4 w-4" />
                دفتر csv
              </Link>
              <Link
                href={exportHref(locale, period, "audit")}
                className="inline-flex items-center gap-2 rounded-xl border border-[#d0b359]/20 px-3 py-2 text-xs text-[#e2c96f] transition hover:bg-[#d1b45d]/8"
              >
                <Download className="h-4 w-4" />
                ر�^�Oداد�?ا�O csv
              </Link>
            </div>
          </header>

          {report.expenses.ledger.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1050px] text-right text-sm">
                <thead className="bg-black/10 text-[#9f9279]">
                  <tr>
                    <th className="px-5 py-3 font-medium">س�?د �^ تار�Oخ</th>
                    <th className="px-5 py-3 font-medium">دست�? �^ طرف حساب</th>
                    <th className="px-5 py-3 font-medium">�.رجع</th>
                    <th className="px-5 py-3 font-medium">ج�.ع �?ز�O�?�?</th>
                    <th className="px-5 py-3 font-medium">�^ضع�Oت</th>
                    <th className="px-5 py-3 font-medium">ا�,دا�.</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#d0b359]/10">
                  {report.expenses.ledger.map(
                    expense => {
                      const voidExpense =
                        voidFinanceExpenseAction.bind(
                          null,
                          expense.id,
                          locale,
                        );

                      return (
                        <tr
                          key={expense.id}
                          className="align-top transition hover:bg-white/[0.025]"
                        >
                          <td className="px-5 py-4 text-[#dfcfac]">
                            <p className="font-medium text-[#ecd17c]">
                              {expense.documentNumber}
                            </p>
                            <p className="mt-1 text-xs text-[#93866f]">
                              {formatAdminDate(expense.occurredAt)}
                            </p>
                          </td>
                          <td className="px-5 py-4 text-[#d5c6a6]">
                            <p>{getFinanceExpenseCategoryLabel(expense.category)}</p>
                            <p className="mt-1 text-xs text-[#93866f]">
                              {expense.supplier}
                            </p>
                          </td>
                          <td className="px-5 py-4 text-[#c6b89a]">
                            <p className="font-mono text-xs">{expense.reference}</p>
                            {expense.note ? (
                              <p className="mt-1 max-w-56 text-xs leading-5 text-[#8f846d]">
                                {expense.note}
                              </p>
                            ) : null}
                          </td>
                          <td className="px-5 py-4 font-medium text-[#e4d2aa]">
                            {formatAdminMoney(
                              BigInt(expense.amountToman.toString().split(".")[0] || "0") +
                              BigInt(expense.taxToman.toString().split(".")[0] || "0"),
                            )}
                            {expense.taxToman.toString() !== "0" ? (
                              <p className="mt-1 text-xs font-normal text-[#93866f]">
                                شا�.�" {formatAdminMoney(expense.taxToman)} �.ا�"�Oات
                              </p>
                            ) : null}
                          </td>
                          <td className="px-5 py-4">
                            {expense.status === "POSTED" ? (
                              <span className="rounded-full border border-emerald-300/20 bg-emerald-950/25 px-2.5 py-1 text-xs text-emerald-100">
                                ثبت�?Oشد�?
                              </span>
                            ) : (
                              <div>
                                <span className="rounded-full border border-amber-300/20 bg-amber-950/25 px-2.5 py-1 text-xs text-amber-100">
                                  باط�"�?Oشد�?
                                </span>
                                <p className="mt-2 max-w-44 text-xs leading-5 text-[#b9a98a]">
                                  {expense.voidReason}
                                </p>
                              </div>
                            )}
                          </td>
                          <td className="px-5 py-4">
                            {expense.status === "POSTED" ? (
                              <details className="w-56">
                                <summary className="cursor-pointer text-xs text-amber-200 hover:text-amber-100">
                                  ابطا�" با د�"�O�"
                                </summary>
                                <form action={voidExpense} className="mt-2 grid gap-2">
                                  <input type="hidden" name="period" value={period} />
                                  <textarea
                                    name="voidReason"
                                    required
                                    minLength={5}
                                    maxLength={1000}
                                    rows={2}
                                    placeholder="د�"�O�" ابطا�" (حدا�,�" ۵ حرف)"
                                    className="resize-y rounded-lg border border-amber-300/20 bg-[#02150f] px-2.5 py-2 text-xs text-[#f4e2b9] outline-none placeholder:text-[#776d5a] focus:border-amber-300/50"
                                  />
                                  <button
                                    type="submit"
                                    className="rounded-lg border border-amber-300/25 bg-amber-950/30 px-2.5 py-2 text-xs text-amber-100 hover:bg-amber-950/45"
                                  >
                                    ثبت ابطا�"�> بد�^�? حذف س�?د
                                  </button>
                                </form>
                              </details>
                            ) : (
                              <span className="text-xs text-[#8f846d]">
                                �,اب�" بازگردا�?�O �?�Oست
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    },
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid min-h-64 place-items-center px-5 text-center text-sm leading-7 text-[#91866f]">
              �?�?�^ز س�?د �?ز�O�?�?�?Oا�O در ا�O�? باز�? ثبت �?شد�? است. از فر�. ک�?ار ا�O�? جد�^�"�O �Oک فاکت�^ر �Oا رس�Oد �^ا�,ع�O �^ارد ک�?�Oد.
            </div>
          )}
        </article>
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
        <article className="overflow-hidden rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82">
          <header className="flex items-center justify-between border-b border-[#d0b359]/12 px-5 py-4 sm:px-6">
            <div className="flex items-center gap-3">
              <span className={`grid h-10 w-10 place-items-center rounded-xl border ${reconciliationIsClear ? "border-emerald-300/15 bg-emerald-950/20 text-emerald-200" : "border-red-300/20 bg-red-950/20 text-red-200"}`}>
                {reconciliationIsClear ? <ShieldCheck className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
              </span>
              <div>
                <h2 className="font-semibold text-[#efd782]">
                  �.غا�Oرت�?Oگ�Oر�O سفارش �^ پرداخت
                </h2>
                <p className="mt-1 text-xs text-[#8f846d]">
                  �.ب�"غ �,اب�" پرداخت �?ر سفارش با �.ج�.�^ع پرداخت ثبت�?Oشد�? در درگا�? تطب�O�, داد�? �.�O�?Oش�^د.
                </p>
              </div>
            </div>
            <Link
              href={`/${locale}/admin/orders?status=PAYMENT_ATTEMPT_REVIEW`}
              className="shrink-0 text-xs text-[#e2c96f] hover:text-[#f3dc89]"
            >
              صف پرداخت�?O�?ا
            </Link>
          </header>

          <div className="grid gap-px bg-[#d0b359]/10 sm:grid-cols-3">
            <div className="bg-[#041d15]/82 px-5 py-4">
              <p className="text-xs text-[#8f846d]">سفارش بررس�O�?Oشد�?</p>
              <p className="mt-1 font-semibold text-[#e5d3ab]">{new Intl.NumberFormat("fa-IR").format(report.reconciliation.inspectedOrderCount)}</p>
            </div>
            <div className="bg-[#041d15]/82 px-5 py-4">
              <p className="text-xs text-[#8f846d]">اخت�"اف �.ج�.�^ع</p>
              <p className={`mt-1 font-semibold ${report.reconciliation.mismatchCount ? "text-red-200" : "text-emerald-200"}`}>{formatAdminMoney(report.reconciliation.mismatchToman)}</p>
            </div>
            <div className="bg-[#041d15]/82 px-5 py-4">
              <p className="text-xs text-[#8f846d]">صف بررس�O درگا�?</p>
              <p className={`mt-1 font-semibold ${report.reconciliation.paymentReview.count ? "text-red-200" : "text-emerald-200"}`}>{new Intl.NumberFormat("fa-IR").format(report.reconciliation.paymentReview.count)}</p>
            </div>
          </div>

          {report.reconciliation.examples.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[680px] text-right text-sm">
                <thead className="bg-black/10 text-[#9f9279]">
                  <tr>
                    <th className="px-5 py-3 font-medium">سفارش</th>
                    <th className="px-5 py-3 font-medium">ا�?تظار</th>
                    <th className="px-5 py-3 font-medium">ثبت�?Oشد�?</th>
                    <th className="px-5 py-3 font-medium">اخت�"اف</th>
                    <th className="px-5 py-3 font-medium">بررس�O</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#d0b359]/10">
                  {report.reconciliation.examples.map(
                    item => (
                      <tr key={item.id}>
                        <td className="px-5 py-4 font-medium text-[#ecd17c]">{item.orderNumber}</td>
                        <td className="px-5 py-4 text-[#d5c6a6]">{formatAdminMoney(item.expectedToman)}</td>
                        <td className="px-5 py-4 text-[#d5c6a6]">{formatAdminMoney(item.receivedToman)}</td>
                        <td className={`px-5 py-4 font-medium ${item.differenceToman < 0n ? "text-red-200" : "text-amber-200"}`}>{formatSignedMoney(item.differenceToman)}</td>
                        <td className="px-5 py-4">
                          <Link href={`/${locale}/admin/orders/${item.id}`} className="text-xs text-[#e2c96f] hover:text-[#f3dc89]">باز کرد�?</Link>
                        </td>
                      </tr>
                    ),
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="px-5 py-7 text-center text-sm leading-7 text-emerald-100">
              {reconciliationIsClear
                ? "در ا�O�? باز�? اخت�"اف�O �.�Oا�? سفارش�?O�?ا�O پرداخت�?Oشد�? �^ پرداخت ثبت�?Oشد�? د�Oد�? �?شد."
                : "اخت�"اف سفارش �^ج�^د �?دارد�O ا�.ا پرداخت�?O�?ا�O �?�Oاز�.�?د بررس�O را از صف پرداخت�?O�?ا پ�Oگ�Oر�O ک�?�Oد."}
            </div>
          )}
        </article>

        <article className="rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl border border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#e4c870]">
              <ReceiptText className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-semibold text-[#efd782]">
                تفک�Oک �?ز�O�?�?�?O�?ا�O ثبت�?Oشد�?
              </h2>
              <p className="mt-1 text-xs text-[#8f846d]">
                ف�,ط اس�?اد فعا�" �^ارد �.حاسب�? �.�O�?Oش�^�?د�> اس�?اد ابطا�"�?Oشد�? صرفا�< در تار�Oخ�?�? �.�O�?O�.ا�?�?د.
              </p>
            </div>
          </div>

          {report.expenses.categories.length ? (
            <div className="mt-5 divide-y divide-[#d0b359]/10 rounded-2xl border border-[#d0b359]/12 bg-[#02150f] px-4">
              {report.expenses.categories.map(
                expense => {
                  const share =
                    percentageOf(
                      expense.totalToman,
                      report.expenses.totalToman,
                    );

                  return (
                    <div key={expense.category} className="flex items-center justify-between gap-4 py-3.5 text-sm">
                      <dt className="text-[#b8aa8e]">{getFinanceExpenseCategoryLabel(expense.category)}</dt>
                      <dd className="text-left">
                        <p className="font-medium text-[#e5d3ab]">{formatAdminMoney(expense.totalToman)}</p>
                        <p className="mt-1 text-xs text-[#8f846d]">{share === null ? "�?"" : `${formatPercentage(share)} از �?ز�O�?�?�?O�?ا`}</p>
                      </dd>
                    </div>
                  );
                },
              )}
            </div>
          ) : (
            <div className="mt-5 grid min-h-48 place-items-center rounded-2xl border border-dashed border-[#d0b359]/16 px-5 text-center text-sm leading-7 text-[#91866f]">
              با ثبت س�?د�O س�?�. �?ر دست�? از �?ز�O�?�?�?O�?ا ا�O�?جا د�Oد�? �.�O�?Oش�^د.
            </div>
          )}
        </article>
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.1fr_0.9fr]">
        <article className="overflow-hidden rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82">
          <header className="flex items-center justify-between border-b border-[#d0b359]/12 px-5 py-4 sm:px-6">
            <div>
              <h2 className="font-semibold text-[#efd782]">
                پرفر�^ش�?Oتر�O�? �.حص�^�"ات
              </h2>
              <p className="mt-1 text-xs text-[#8f846d]">
                بر پا�O�?�" فر�^ش �,طع�O �?�.�O�? باز�?
              </p>
            </div>
            <TrendingUp className="h-5 w-5 text-[#d7bb67]" />
          </header>

          {report.topProducts.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[680px] text-right text-sm">
                <thead className="bg-black/10 text-[#9f9279]">
                  <tr>
                    <th className="px-5 py-3 font-medium">�.حص�^�"</th>
                    <th className="px-5 py-3 font-medium">تعداد</th>
                    <th className="px-5 py-3 font-medium">فر�^ش</th>
                    <th className="px-5 py-3 font-medium">حاش�O�?�" ثبت�?Oشد�?</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#d0b359]/10">
                  {report.topProducts.map(
                    product => (
                      <tr key={product.slug} className="transition hover:bg-white/[0.025]">
                        <td className="px-5 py-4 text-[#dfcfac]">{product.name}</td>
                        <td className="px-5 py-4 text-[#b8aa8d]">{new Intl.NumberFormat("fa-IR").format(product.quantity)}</td>
                        <td className="px-5 py-4 text-[#e4d2aa]">{formatAdminMoney(product.revenueToman)}</td>
                        <td className="px-5 py-4 text-[#cddfba]">{formatAdminMoney(product.priceMarginToman)}</td>
                      </tr>
                    ),
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid min-h-48 place-items-center px-5 text-center text-sm text-[#91866f]">
              با ثبت فر�^ش �,طع�O�O �.حص�^�"ات ا�O�?جا رتب�?�?Oب�?د�O �.�O�?Oش�^�?د.
            </div>
          )}
        </article>

        <article className="rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl border border-[#d1b45d]/18 bg-[#d1b45d]/8 text-[#e4c870]">
              <ReceiptText className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-semibold text-[#efd782]">
                تفک�Oک �.ا�"�O فر�^ش
              </h2>
              <p className="mt-1 text-xs text-[#8f846d]">
                اجزا�O ذخ�Oر�?�?Oشد�? در سفارش�?O�?ا�O پرداخت�?Oشد�?
              </p>
            </div>
          </div>

          <dl className="mt-5 divide-y divide-[#d0b359]/10 rounded-2xl border border-[#d0b359]/12 bg-[#02150f] px-4">
            <div className="flex items-center justify-between gap-4 py-3.5 text-sm">
              <dt className="text-[#b8aa8e]">فر�^ش ا�,�"ا�.</dt>
              <dd className="font-medium text-[#e5d3ab]">{formatAdminMoney(report.itemRevenueToman)}</dd>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-sm">
              <dt className="text-[#b8aa8e]">�?ز�O�?�?�" ارسا�" ثبت�?Oشد�?</dt>
              <dd className="font-medium text-[#e5d3ab]">{formatAdminMoney(report.shippingToman)}</dd>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-sm">
              <dt className="text-[#b8aa8e]">تخف�Oف ثبت�?Oشد�?</dt>
              <dd className="font-medium text-orange-200">�^'{formatAdminMoney(report.discountToman)}</dd>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-sm">
              <dt className="text-[#b8aa8e]">اجرت �^ �?ز�O�?�?�" �?�?ر�O</dt>
              <dd className="font-medium text-[#e5d3ab]">{formatAdminMoney(report.makingChargeToman + report.artisticFeeToman)}</dd>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-sm">
              <dt className="text-[#b8aa8e]">�.ا�"�Oات درج�?Oشد�? در سفارش</dt>
              <dd className="font-medium text-[#e5d3ab]">{formatAdminMoney(report.taxToman)}</dd>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-sm">
              <dt className="flex items-center gap-2 text-[#b8aa8e]"><RotateCcw className="h-4 w-4" /> بازپرداخت ثبت�?Oشد�?</dt>
              <dd className="font-medium text-red-200">{formatAdminMoney(report.refundedToman)}</dd>
            </div>
          </dl>
        </article>
      </section>

      <article className="flex flex-col gap-4 rounded-[24px] border border-[#d0b359]/15 bg-[#061f17]/85 p-5 sm:flex-row sm:items-start sm:justify-between sm:p-6">
        <div className="flex max-w-4xl gap-3">
          <span className="mt-0.5 text-[#d3b55f]">
            <TrendingDown className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-semibold text-[#f0d880]">
              �.حد�^د�?�" د�,�O�, ا�O�? ابزار
            </h2>
            <p className="mt-2 text-sm leading-7 text-[#ad9f82]">
              ا�O�? پ�?�" �Oک دفتر ع�.�"�Oات�O �,اب�" حسابرس�O است: فر�^ش�O پرداخت�O بازپرداخت�O �?ز�O�?�? �^ د�"�O�" ابطا�" را از داد�?�?O�?ا�O �^ا�,ع�O ثبت �^ تطب�O�, �.�O�?Oد�?د. «س�^د خا�"ص �,ا�?�^�?�O» ع�.دا�< �?�.ا�Oش داد�? �?�.�O�?Oش�^د�> برا�O آ�? با�Oد �.�^ج�^د�O�?Oگردا�?�O�O ب�?ا�O ت�.ا�.�?Oشد�?�" �?ر �,طع�?�O �.ا�"�Oات �^ اس�?اد خارج از سا�Oت �?�Oز ت�^سط حسابدار رس�.�O بررس�O ش�^�?د.
            </p>
          </div>
        </div>
        <Link
          href={`/${locale}/admin/orders`}
          className="inline-flex shrink-0 items-center justify-center rounded-xl border border-[#d0b359]/20 px-4 py-2.5 text-sm text-[#e2c96f] transition hover:bg-[#d1b45d]/8"
        >
          بررس�O سفارش�?O�?ا
        </Link>
      </article>
    </div>
  );
}

