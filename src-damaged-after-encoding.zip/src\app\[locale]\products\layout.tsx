﻿import type { ReactNode } from "react";
import type { Metadata } from "next";
import { localizedPageMetadata, type EloriaLocale } from "@/lib/seo";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (locale !== "fa" && locale !== "en") return {};

  return localizedPageMetadata({
    locale: locale as EloriaLocale,
    path: "/products",
    title: locale === "fa" ? "ت�.ا�. ج�^ا�?رات �^ آثار ا�"�^ر�Oا" : "All Eloria Jewellery",
    description:
      locale === "fa"
        ? "ت�.ا�. آثار ا�"�^ر�Oا را بر اساس گ�?ج�O�?�?�O ج�?س�O �.�^ج�^د�O �^ باز�? �,�O�.ت �.شا�?د�? �^ ف�O�"تر ک�?�Oد."
        : "Browse all Eloria creations and filter by collection, material, availability and price.",
  });
}

export default function ProductsLayout({ children }: { children: ReactNode }) {
  return children;
}

