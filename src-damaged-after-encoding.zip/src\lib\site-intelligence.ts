﻿import { productionEnvironmentChecks } from "@/lib/env-validation";
import { getAdminFinanceReport } from "@/lib/admin-finance";
import { getContentSeoHealth } from "@/lib/content-seo-health";
import { isCustomerProductWatchesEnabled } from "@/lib/customer-product-watches";
import { prisma, withDatabaseRetry } from "@/lib/prisma";
import { isSiteMeasurementEnabled } from "@/lib/site-measurement";

export type IntelligencePriority = "high" | "medium" | "low";

export type IntelligenceAction = {
  id: string;
  priority: IntelligencePriority;
  title: string;
  detail: string;
  href: string;
  hrefLabel: string;
};

export type WebVitalSummary = {
  name: string;
  samples: number;
  p75: number | null;
};

function minutesSince(value: Date, now: Date): number {
  return Math.max(0, Math.floor((now.getTime() - value.getTime()) / 60_000));
}

function percentile75(values: number[]): number | null {
  if (!values.length) return null;
  const ordered = [...values].sort((left, right) => left - right);
  return ordered[Math.min(ordered.length - 1, Math.ceil(ordered.length * 0.75) - 1)] ?? null;
}

function metricSummary(rows: Array<{ metricName: string | null; metricValue: { toString(): string } | null }>): WebVitalSummary[] {
  return ["LCP", "INP", "CLS", "FCP", "TTFB"].map((name) => {
    const values = rows
      .filter((row) => row.metricName === name && row.metricValue !== null)
      .map((row) => Number(row.metricValue?.toString()))
      .filter((value) => Number.isFinite(value));
    return { name, samples: values.length, p75: percentile75(values) };
  });
}

export async function getSiteIntelligence() {
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60_000);
  const environment = productionEnvironmentChecks().filter((check) => check.required);

  const [content, finance, prices, unavailableProducts, paymentReview, watchCount, eventGroups, vitalRows, latestBriefing] = await Promise.all([
    getContentSeoHealth(),
    getAdminFinanceReport(30),
    withDatabaseRetry(() =>
      prisma.metalPrice.findMany({
        select: { material: true, lastSuccessAt: true, lastError: true, source: true },
        orderBy: { material: "asc" },
      }),
    ),
    prisma.product.count({
      where: {
        OR: [
          { status: "OUT_OF_STOCK" },
          { status: "ACTIVE", stock: { lte: 0 }, variants: { none: { stock: { gt: 0 }, isActive: true } } },
        ],
      },
    }),
    prisma.paymentAttempt.count({ where: { status: "REQUIRES_REVIEW" } }),
    prisma.customerProductWatch.count(),
    prisma.siteMeasurementEvent.groupBy({
      by: ["eventType"],
      where: { occurredAt: { gte: thirtyDaysAgo } },
      _count: { _all: true },
    }),
    prisma.siteMeasurementEvent.findMany({
      where: { eventType: "web_vital", occurredAt: { gte: thirtyDaysAgo } },
      select: { metricName: true, metricValue: true },
      orderBy: { occurredAt: "desc" },
      take: 5_000,
    }),
    prisma.dailyStoreBriefing.findFirst({
      orderBy: { updatedAt: "desc" },
      select: { updatedAt: true },
    }),
  ]);

  const actions: IntelligenceAction[] = [];
  const failedEnvironment = environment.filter((check) => !check.valid);
  if (failedEnvironment.length) {
    actions.push({
      id: "production-environment",
      priority: "high",
      title: "�,رارداد Production کا�.�" �?�Oست",
      detail: `${failedEnvironment.length} �.�^رد از ${environment.length} ک�?تر�" �"از�. �?�?�^ز �.عتبر �?�Oست. �.�,دار�?ا�O �.حر�.ا�?�? �?رگز در ا�O�? پ�?�" �?�.ا�Oش داد�? �?�.�O�?Oش�^�?د.`,
      href: "/fa/admin/security",
      hrefLabel: "بازب�O�?�O ا�.�?�Oت",
    });
  }

  const stalePrices = prices.filter((price) => minutesSince(price.lastSuccessAt, now) > 20 || Boolean(price.lastError));
  if (stalePrices.length) {
    actions.push({
      id: "metal-price-freshness",
      priority: "high",
      title: "�?رخ ف�"ز �?�Oاز ب�? بررس�O دارد",
      detail: `${stalePrices.length} �?رخ ثبت�?Oشد�? �,د�O�.�O است �Oا خطا�O �.�?بع دارد. پ�Oش از فعا�"�?Oکرد�? فر�^ش�O �^ضع�Oت �?رخ �^ cron را بررس�O ک�?�Oد.`,
      href: "/fa/admin",
      hrefLabel: "�?�.ا�O �?رخ�?O�?ا",
    });
  }

  if (paymentReview > 0) {
    actions.push({
      id: "payment-review",
      priority: "high",
      title: "پرداخت�?O�?ا�O �?�Oاز�.�?د بررس�O دار�Oد",
      detail: `${paymentReview} پرداخت با�Oد با رس�Oد �Oا پ�?�" درگا�? تطب�O�, داد�? ش�^د�> ا�O�? �^ضع�Oت ب�?�?Oص�^رت خ�^دکار «�.�^ف�,» فرض �?�.�O�?Oش�^د.`,
      href: "/fa/admin/orders",
      hrefLabel: "بررس�O سفارش�?O�?ا",
    });
  }

  if (unavailableProducts > 0) {
    actions.push({
      id: "inventory-queue",
      priority: "medium",
      title: "�.�^ج�^د�O برخ�O �.حص�^�"ات �?�Oاز ب�? ا�,دا�. دارد",
      detail: `${unavailableProducts} �.حص�^�" فعا�" �Oا �,اب�"�?O�?�.ا�Oش�O �.�^ج�^د�O �,اب�" سفارش �?دارد.`,
      href: "/fa/admin/products",
      hrefLabel: "�.د�Oر�Oت �.�^ج�^د�O",
    });
  }

  for (const issue of content.issues.slice(0, 3)) {
    actions.push({
      id: `content-${issue.id.toLowerCase()}`,
      priority: issue.severity === "HIGH" ? "high" : issue.severity === "MEDIUM" ? "medium" : "low",
      title: issue.title,
      detail: issue.detail,
      href: "/fa/admin/content",
      hrefLabel: "�.حت�^ا �^ سئ�^",
    });
  }

  if (!isSiteMeasurementEnabled()) {
    actions.push({
      id: "measurement-consent",
      priority: "low",
      title: "س�?جش ع�.�"کرد رضا�Oت�O خا�.�^ش است",
      detail: "ا�O�? ا�?تخاب حر�O�. خص�^ص�O را حفظ �.�O�?Oک�?د. پس از تک�.�O�" �.ت�? حر�O�. خص�^ص�O�O �.�O�?Oت�^ا�?�Oد آ�? را ر�^ش�? ک�?�Oد تا ف�,ط با رضا�Oت کاربر�O سرعت �^ �.س�Oر�?ا�O خر�Oد بد�^�? داد�?�" �?�^�Oت�O ثبت ش�^�?د.",
      href: "/fa/admin/security",
      hrefLabel: "را�?�?�.ا�O ا�?تشار",
    });
  }

  if (isCustomerProductWatchesEnabled()) {
    actions.push({
      id: "customer-watch-cron",
      priority: "low",
      title: "پ�Oگ�Oر�O �,�O�.ت �^ �.�^ج�^د�O ب�? cron �?�Oاز دارد",
      detail: `${watchCount} پ�Oگ�Oر�O �.حص�^�" ثبت شد�? است. در �?است Production اجرا�O ر�^زا�?�?�" endpoint �.رب�^ط را ز�.ا�?�?Oب�?د�O ک�?�Oد تا اع�"ا�? داخ�" پ�?�" �.شتر�O �^ا�,عا�< ساخت�? ش�^د.`,
      href: "/fa/admin/security",
      hrefLabel: "�?ک�?O�"�Oست ا�?تشار",
    });
  }

  if (
    !latestBriefing ||
    minutesSince(latestBriefing.updatedAt, now) > 30 * 60
  ) {
    actions.push({
      id: "automation-schedule",
      priority: "medium",
      title: "گزارش خ�^دکار ر�^زا�?�? ب�? ز�.ا�?�?Oب�?د �?�Oاز دارد",
      detail: "تا �^�,ت�O �?رخ�?�" ز�.ا�?�?Oب�?د�O�?Oشد�? اجرا �?ش�^د�O �?رخ�O �.حت�^ا �^ پ�Oگ�Oر�O�?O�?ا�O �.شتر�O خ�^دکار پا�Oش �?�.�O�?Oش�^�?د. اجرا�O �Oک�?Oبار�?�" �?صب ز�.ا�?�?Oب�?د ا�O�? �.�^رد را فعا�" �.�O�?Oک�?د.",
      href: "/fa/admin/automation",
      hrefLabel: "خ�"با�? خ�^دکار",
    });
  }

  const eventCounts = Object.fromEntries(eventGroups.map((group) => [group.eventType, group._count._all]));
  return {
    generatedAt: now,
    environment: {
      total: environment.length,
      passed: environment.length - failedEnvironment.length,
      failed: failedEnvironment.map((check) => ({ key: check.key, message: check.message })),
    },
    finance: {
      salesToman: finance.salesToman,
      orderCount: finance.orderCount,
      netCashAfterExpensesToman: finance.netCashAfterExpensesToman,
      paymentReviewCount: finance.reconciliation.paymentReview.count,
    },
    content: {
      score: content.overallScore,
      publishedArticleCount: content.publishedArticleCount,
      productsMissingDescription: content.productsMissingDescription,
      productsMissingImageAlt: content.productsMissingImageAlt,
    },
    operations: {
      unavailableProducts,
      watches: watchCount,
      prices: prices.map((price) => ({
        material: price.material,
        minutesSinceSuccess: minutesSince(price.lastSuccessAt, now),
        source: price.source,
        hasError: Boolean(price.lastError),
      })),
    },
    measurement: {
      enabled: isSiteMeasurementEnabled(),
      eventCounts,
      vitals: metricSummary(vitalRows),
    },
    actions: actions.sort((left, right) => ({ high: 0, medium: 1, low: 2 }[left.priority] - { high: 0, medium: 1, low: 2 }[right.priority])),
  };
}

