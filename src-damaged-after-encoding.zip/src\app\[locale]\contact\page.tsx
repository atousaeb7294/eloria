﻿import type { CSSProperties } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { setRequestLocale } from "next-intl/server";
import { Handshake, Headphones, PackageSearch, Scale } from "lucide-react";

import { ContactRequestForm } from "@/components/support-forms";
import { InternalPageShell } from "@/components/internal-page-shell";
import { LuxuryPageHero } from "@/components/luxury-page-hero";
import { legalBusinessIdentity } from "@/lib/legal-business";

type ContactPageProps = {
  params: Promise<{ locale: string }>;
};

const contactPaths = [
  {
    icon: Headphones,
    fa: { title: "را�?�?�.ا�O ا�?تخاب", description: "برا�O بررس�O دست�?�?Oب�?د�O�O ج�?س�O �.شخصات �^ �.س�Oر خر�Oد از ا�O�? بخش استفاد�? ک�?�Oد." },
    en: { title: "Purchase guidance", description: "Use this path for help with categories, materials, specifications and the purchase journey." },
  },
  {
    icon: PackageSearch,
    fa: { title: "پ�Oگ�Oر�O سفارش", description: "�^ضع�Oت سفارش �^ اط�"اعات ثبت�?Oشد�? را از صفح�? پ�Oگ�Oر�O بررس�O ک�?�Oد." },
    en: { title: "Order tracking", description: "Review your order status and submitted details through the tracking page." },
  },
  {
    icon: Handshake,
    fa: { title: "�?�.کار�O با ا�"�^ر�Oا", description: "درخ�^است�?O�?ا�O �?�.کار�O�O رسا�?�?�?Oا�O �^ تجار�O در فر�. ارتباط ثبت �.�O�?Oش�^�?د." },
    en: { title: "Work with Eloria", description: "Partnership, media and business enquiries can be recorded through the contact form." },
  },
] as const;

export default async function ContactPage({ params }: ContactPageProps) {
  const { locale } = await params;
  if (locale !== "fa" && locale !== "en") notFound();

  setRequestLocale(locale);

  const isPersian = locale === "fa";
  const seller = legalBusinessIdentity();

  return (
    <InternalPageShell locale={locale}>
      <section className="eloria-page-container relative z-10 pb-28 pt-36 sm:pt-40">
        <LuxuryPageHero
          eyebrow="Eloria Support"
          title={isPersian ? "ارتباط با ا�"�^ر�Oا" : "Contact Eloria"}
          description={
            isPersian
              ? "برا�O را�?�?�.ا�O�O خر�Oد�O پ�Oگ�Oر�O سفارش�O ثبت درخ�^است ح�,�^�, �.صرف�?Oک�?�?د�? �Oا پ�Oش�?�?اد �?�.کار�O از فر�. رس�.�O �?�.�O�? صفح�? استفاد�? ک�?�Oد."
              : "Use the official form on this page for purchase guidance, order tracking, consumer-rights requests or partnership enquiries."
          }
          isPersian={isPersian}
          actions={
            <>
              <Link className="eloria-button-primary" href={`/${locale}/order-tracking`}>
                {isPersian ? "پ�Oگ�Oر�O سفارش" : "Track an order"}
              </Link>
              <Link className="eloria-button-secondary" href={`/${locale}/products`}>
                {isPersian ? "�.شا�?د�? ج�^ا�?ر�?ا" : "Browse jewelry"}
              </Link>
            </>
          }
        />

        <div className="mt-14 grid gap-4 md:grid-cols-3">
          {contactPaths.map((path, index) => {
            const Icon = path.icon;
            const item = path[isPersian ? "fa" : "en"];
            return (
              <article
                key={path.en.title}
                data-reveal
                style={{ "--reveal-delay": `${index * 90}ms` } as CSSProperties}
                className="eloria-panel rounded-[2rem] p-6 transition duration-500 hover:-translate-y-1 hover:border-[#dfc16f]/36"
              >
                <span className="grid size-13 place-items-center rounded-2xl border border-[#dfc16f]/24 bg-[#dfc16f]/[0.055] text-[#e2c46f]">
                  <Icon className="size-6" />
                </span>
                <h2 className="mt-5 text-xl font-semibold text-[#f0e2c2]">{item.title}</h2>
                <p className="mt-3 text-sm leading-8 text-[#cdbf9f]/66">{item.description}</p>
              </article>
            );
          })}
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
          <ContactRequestForm locale={locale} />

          <div className="space-y-6">
            <aside data-reveal="right" className="eloria-panel rounded-[2.2rem] p-6 sm:p-8">
              <p className="eloria-kicker">{isPersian ? "پ�Oش از ارسا�"" : "Before sending"}</p>
              <h2 className="mt-3 text-2xl font-semibold text-[#f2e4c5]">
                {isPersian ? "اط�"اعات �"از�. را آ�.اد�? ک�?�Oد" : "Prepare the essential details"}
              </h2>
              <div className="mt-6 space-y-4 text-sm leading-8 text-[#d4c6a7]/68">
                <p>{isPersian ? "ش�.ار�? سفارش را برا�O درخ�^است�?O�?ا�O �.رب�^ط ب�? خر�Oد ب�?�^�Oس�Oد." : "Include the order number for purchase-related requests."}</p>
                <p>{isPersian ? "برا�O ا�?صراف�O �.رج�^ع�O �Oا �.غا�Oرت�O �?�^ع درخ�^است را ب�?�?Oص�^رت ر�^ش�? در پ�Oا�. ب�?�^�Oس�Oد تا ثبت آ�? �,اب�" پ�Oگ�Oر�O باشد." : "For withdrawal, return or mismatch requests, state the request type clearly so it can be tracked."}</p>
                <p>{isPersian ? "اط�"اعات کارت با�?ک�O�O ر�.ز�O CVV2 �Oا کد�?ا�O ا�.�?�Oت�O را در پ�Oا�. �^ارد �?ک�?�Oد." : "Never include bank-card credentials, passwords, CVV2 or security codes in your message."}</p>
              </div>
            </aside>

            <aside data-reveal="right" className="eloria-panel rounded-[2.2rem] p-6 sm:p-8">
              <span className="grid size-12 place-items-center rounded-2xl border border-[#dfc16f]/24 bg-[#dfc16f]/[0.055] text-[#e2c46f]">
                <Scale className="size-6" />
              </span>
              <p className="eloria-kicker mt-5">{isPersian ? "اط�"اعات فر�^ش�?د�?" : "Seller information"}</p>
              <h2 className="mt-3 text-2xl font-semibold text-[#f2e4c5]">{seller.sellerName}</h2>

              {seller.complete ? (
                <div className="mt-5 space-y-3 text-sm leading-8 text-[#d4c6a7]/68">
                  <p>{seller.businessAddress}</p>
                  {seller.supportPhone ? <a className="block underline-offset-4 hover:underline" href={`tel:${seller.supportPhone}`}>{seller.supportPhone}</a> : null}
                  {seller.supportEmail ? <a className="block underline-offset-4 hover:underline" href={`mailto:${seller.supportEmail}`}>{seller.supportEmail}</a> : null}
                </div>
              ) : (
                <p className="mt-5 text-sm leading-8 text-[#d4c6a7]/68">
                  {isPersian
                    ? "فر�^ش آ�?�"ا�O�? در حا�"ت پ�Oش�?Oرا�?�?Oا�?داز�O است. �.شخصات �,ا�?�^�?�O �^ را�? ت�.اس �.ست�,�O�. فر�^ش�?د�? �,ب�" از فعا�"�?Oشد�? Commerce در ت�?ظ�O�.ات Production اجبار�O است."
                    : "Online commerce is in pre-launch mode. Legal seller details and a direct contact method are required in Production before Commerce can be enabled."}
                </p>
              )}
            </aside>
          </div>
        </div>
      </section>
    </InternalPageShell>
  );
}
