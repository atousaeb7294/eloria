﻿import Link from "next/link";

import {
  ArrowRight,
  Banknote,
  MapPin,
  Package,
  ReceiptText,
  UserRound,
} from "lucide-react";

import {
  notFound,
} from "next/navigation";

import { AdminOrderWorkflow } from "@/components/admin/admin-order-workflow";
import { markAdminPaymentRefundedAction } from "../actions";

import {
  formatAdminDate,
  formatAdminMoney,
  getOrderStatusLabel,
} from "@/lib/admin-format";

import {
  prisma,
} from "@/lib/prisma";

export const dynamic =
  "force-dynamic";

export const revalidate = 0;

function JsonPreview({
  value,
}: {
  value: unknown;
}) {
  if (
    value === null ||
    value === undefined
  ) {
    return (
      <span className="text-[#7f7460]">
        بد�^�? داد�?
      </span>
    );
  }

  let output = "";

  try {
    output =
      JSON.stringify(
        value,
        null,
        2,
      );
  } catch {
    output =
      String(value);
  }

  return (
    <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-black/20 p-3 text-left text-xs leading-6 text-[#b7aa90]" dir="ltr">
      {output}
    </pre>
  );
}

export default async function AdminOrderDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string; id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const {
    locale,
    id,
  } = await params;

  if (
    locale !== "fa" &&
    locale !== "en"
  ) {
    notFound();
  }

  const safeLocale: "fa" | "en" = locale;

  const order =
    await prisma.order.findUnique({
      where: {
        id,
      },
      include: {
        items: {
          orderBy: {
            createdAt:
              "asc",
          },
        },
        payments: {
          orderBy: {
            createdAt:
              "desc",
          },
        },
        shipments: {
          orderBy: {
            updatedAt:
              "desc",
          },
          take: 1,
        },
        auditEvents: {
          orderBy: {
            createdAt:
              "desc",
          },
          take: 100,
        },
      },
    });

  if (!order) {
    notFound();
  }

  const query = await searchParams;
  const one = (value: string | string[] | undefined) =>
    Array.isArray(value) ? value[0] ?? "" : value ?? "";
  const decode = (value: string | string[] | undefined) => {
    const raw = one(value);
    if (!raw) return undefined;
    try { return decodeURIComponent(raw); } catch { return raw; }
  };
  const latestShipment = order.shipments[0]
    ? {
        carrier: order.shipments[0].carrier,
        trackingCode: order.shipments[0].trackingCode,
        note: order.shipments[0].note ?? undefined,
      }
    : undefined;

  return (
    <div className="space-y-6">
      <header>
        <Link
          href={`/${locale}/admin/orders`}
          className="inline-flex items-center gap-2 text-sm text-[#b9aa8c] hover:text-[#ecd17c]"
        >
          <ArrowRight className="h-4 w-4" />
          بازگشت ب�? سفارش�?O�?ا
        </Link>

        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs tracking-[0.22em] text-[#b99e4f]">
              ORDER {order.orderNumber}
            </p>
            <h1 className="mt-2 text-2xl font-semibold text-[#f7e4b6] sm:text-3xl">
              جزئ�Oات سفارش
            </h1>
          </div>

          <span className="w-fit rounded-full border border-[#d5b75f]/20 bg-[#d0b258]/8 px-4 py-2 text-sm text-[#ebd17c]">
            {getOrderStatusLabel(order.status)}
          </span>
        </div>
      </header>

      <AdminOrderWorkflow
        orderId={order.id}
        locale={safeLocale}
        status={order.status}
        workflowSaved={one(query.workflowSaved) === "1"}
        workflowError={decode(query.workflowError)}
        shipmentSaved={one(query.shipmentSaved) === "1"}
        shipmentError={decode(query.shipmentError)}
        latestShipment={latestShipment}
      />

      {one(query.paymentRefunded) === "1" ? (
        <div className="rounded-2xl border border-emerald-300/20 bg-emerald-950/20 px-5 py-4 text-sm text-emerald-100">
          بازپرداخت دست�O ت�"اش پرداخت ثبت شد.
        </div>
      ) : null}
      {decode(query.paymentError) ? (
        <div className="rounded-2xl border border-red-300/20 bg-red-950/20 px-5 py-4 text-sm text-red-100">
          {decode(query.paymentError)}
        </div>
      ) : null}

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5">
          <div className="flex items-center gap-3 text-[#d8bd68]">
            <UserRound className="h-5 w-5" />
            <h2 className="font-semibold">�.شتر�O</h2>
          </div>
          <div className="mt-4 space-y-2 text-sm leading-7 text-[#b8aa8e]">
            <p>{order.customerFullName || "�?ا�. ثبت �?شد�?"}</p>
            <p dir="ltr" className="text-right">{order.customerMobile || "�?""}</p>
            <p className="break-all">{order.customerEmail || "�?""}</p>
          </div>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5">
          <div className="flex items-center gap-3 text-[#d8bd68]">
            <MapPin className="h-5 w-5" />
            <h2 className="font-semibold">�?شا�?�O</h2>
          </div>
          <div className="mt-4 text-sm leading-7 text-[#b8aa8e]">
            <p>{[order.province, order.city].filter(Boolean).join("�O ") || "�?""}</p>
            <p>{order.address || "�?شا�?�O ثبت �?شد�?"}</p>
            <p>کدپست�O: {order.postalCode || "�?""}</p>
          </div>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5">
          <div className="flex items-center gap-3 text-[#d8bd68]">
            <Banknote className="h-5 w-5" />
            <h2 className="font-semibold">�.با�"غ</h2>
          </div>
          <div className="mt-4 space-y-2 text-sm leading-7 text-[#b8aa8e]">
            <div className="flex justify-between gap-3"><span>ج�.ع ا�,�"ا�.</span><span>{formatAdminMoney(order.subtotalToman)}</span></div>
            <div className="flex justify-between gap-3"><span>ارسا�"</span><span>{formatAdminMoney(order.shippingToman)}</span></div>
            <div className="flex justify-between gap-3"><span>تخف�Oف</span><span>{formatAdminMoney(order.discountToman)}</span></div>
            <div className="flex justify-between gap-3 border-t border-[#d0b359]/12 pt-2 font-semibold text-[#efd27b]"><span>�,اب�" پرداخت</span><span>{formatAdminMoney(order.payableToman)}</span></div>
          </div>
        </article>

        <article className="rounded-[22px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5">
          <div className="flex items-center gap-3 text-[#d8bd68]">
            <ReceiptText className="h-5 w-5" />
            <h2 className="font-semibold">ز�.ا�?�?Oب�?د�O</h2>
          </div>
          <div className="mt-4 space-y-2 text-sm leading-7 text-[#b8aa8e]">
            <p>ثبت: {formatAdminDate(order.createdAt)}</p>
            <p>ا�?�,ضا�O �,�O�.ت: {formatAdminDate(order.priceExpiresAt)}</p>
            <p>پرداخت: {formatAdminDate(order.paidAt)}</p>
            <p>ارسا�"/تک�.�O�": {formatAdminDate(order.inventoryCommittedAt)}</p>
          </div>
        </article>
      </section>

      <section className="overflow-hidden rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82">
        <header className="flex items-center gap-3 border-b border-[#d0b359]/12 px-5 py-4">
          <Package className="h-5 w-5 text-[#d8bd68]" />
          <h2 className="font-semibold text-[#efd782]">
            ا�,�"ا�. سفارش
          </h2>
        </header>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[950px] text-right text-sm">
            <thead className="bg-black/10 text-[#9f9279]">
              <tr>
                <th className="px-5 py-3 font-medium">�.حص�^�"</th>
                <th className="px-5 py-3 font-medium">ت�?�^ع</th>
                <th className="px-5 py-3 font-medium">ج�?س</th>
                <th className="px-5 py-3 font-medium">تعداد</th>
                <th className="px-5 py-3 font-medium">�,�O�.ت �^احد</th>
                <th className="px-5 py-3 font-medium">ج�.ع</th>
                <th className="px-5 py-3 font-medium">�.�^ج�^د�O رزر�^</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#d0b359]/10">
              {order.items.map(
                (item) => (
                  <tr key={item.id}>
                    <td className="px-5 py-4">
                      <p className="text-[#dfcfac]">{item.productNameFa}</p>
                      <p className="mt-1 text-xs text-[#857a66]">{item.productSku || item.productSlug}</p>
                    </td>
                    <td className="px-5 py-4 text-[#b8aa8e]">
                      {item.variantTitleFa || "�?""}
                    </td>
                    <td className="px-5 py-4 text-[#b8aa8e]">
                      {item.material === "GOLD" ? "ط�"ا" : "�?�,ر�?"}
                    </td>
                    <td className="px-5 py-4 text-[#dfcfac]">
                      {new Intl.NumberFormat("fa-IR").format(item.quantity)}
                    </td>
                    <td className="px-5 py-4 text-[#dfcfac]">
                      {formatAdminMoney(item.unitPriceToman)}
                    </td>
                    <td className="px-5 py-4 font-medium text-[#efd27b]">
                      {formatAdminMoney(item.lineTotalToman)}
                    </td>
                    <td className="px-5 py-4 text-[#a99c82]">
                      {new Intl.NumberFormat("fa-IR").format(item.stockBeforeReservation)} �?' {new Intl.NumberFormat("fa-IR").format(item.stockAfterReservation)}
                    </td>
                  </tr>
                ),
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="grid gap-5 xl:grid-cols-2">
        <article className="overflow-hidden rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82">
          <header className="border-b border-[#d0b359]/12 px-5 py-4">
            <h2 className="font-semibold text-[#efd782]">ت�"اش�?O�?ا�O پرداخت</h2>
          </header>

          {order.payments.length ? (
            <div className="divide-y divide-[#d0b359]/10">
              {order.payments.map(
                (payment) => (
                  <div key={payment.id} className="p-5">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="font-medium text-[#dfcfac]">{payment.provider}</p>
                        <p className="mt-1 text-xs text-[#857a66]">{formatAdminDate(payment.createdAt)}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-sm text-[#efd27b]">{formatAdminMoney(payment.amountToman)}</p>
                        <p className="mt-1 text-xs text-[#a99c82]">{payment.status}</p>
                      </div>
                    </div>
                    {payment.errorMessage ? (
                      <p className="mt-3 rounded-xl bg-red-950/20 px-3 py-2 text-xs leading-6 text-red-100/80">
                        {payment.errorCode ? `${payment.errorCode}: ` : ""}{payment.errorMessage}
                      </p>
                    ) : null}
                    {["PAID", "REQUIRES_REVIEW"].includes(payment.status) ? (
                      <form
                        action={markAdminPaymentRefundedAction.bind(null, payment.id, order.id, safeLocale)}
                        className="mt-4 rounded-xl border border-amber-300/15 bg-amber-950/10 p-3"
                      >
                        <p className="text-xs leading-6 text-amber-100/80">
                          ابتدا �^ج�? را �^ا�,عا�< از �.س�Oر با�?ک�O/زر�O�?�?Oپا�" بازگردا�?�Oد�> سپس ش�.ار�? �.رجع �,طع�O را ثبت ک�?�Oد. ثبت س�Oست�.�O بد�^�? �.رجع پذ�Oرفت�? �?�.�O�?Oش�^د.
                        </p>
                        <input
                          name="refundReference"
                          required
                          minLength={6}
                          maxLength={160}
                          placeholder="ش�.ار�? �.رجع با�?ک�O/زر�O�?�?Oپا�" بازپرداخت"
                          className="mt-3 h-10 w-full rounded-lg border border-[#d0b359]/15 bg-black/20 px-3 text-xs text-[#dfcfac] outline-none"
                        />
                        <input
                          name="note"
                          maxLength={1000}
                          placeholder="�Oادداشت داخ�"�O بازپرداخت (اخت�Oار�O)"
                          className="mt-3 h-10 w-full rounded-lg border border-[#d0b359]/15 bg-black/20 px-3 text-xs text-[#dfcfac] outline-none"
                        />
                        <button className="mt-3 rounded-lg border border-amber-300/30 px-3 py-2 text-xs text-amber-100 hover:bg-amber-300/10">
                          ثبت بازپرداخت دست�O ا�O�? پرداخت
                        </button>
                      </form>
                    ) : null}
                  </div>
                ),
              )}
            </div>
          ) : (
            <div className="grid min-h-36 place-items-center px-5 text-sm text-[#91866f]">
              ت�"اش پرداخت�O ثبت �?شد�? است.
            </div>
          )}
        </article>

        <article className="overflow-hidden rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82">
          <header className="border-b border-[#d0b359]/12 px-5 py-4">
            <h2 className="font-semibold text-[#efd782]">تار�Oخ�?�? س�Oست�.�O</h2>
          </header>

          {order.auditEvents.length ? (
            <div className="max-h-[520px] divide-y divide-[#d0b359]/10 overflow-auto">
              {order.auditEvents.map(
                (event) => (
                  <details key={event.id} className="group p-5">
                    <summary className="cursor-pointer list-none">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <p className="font-medium text-[#dfcfac]">{event.eventType}</p>
                          <p className="mt-1 text-xs text-[#857a66]">{event.actorType} · {formatAdminDate(event.createdAt)}</p>
                        </div>
                        <span className="text-xs text-[#8f846d] group-open:text-[#d9bd68]">�?�.ا�Oش داد�?</span>
                      </div>
                    </summary>
                    <div className="mt-4">
                      <JsonPreview value={event.payload} />
                    </div>
                  </details>
                ),
              )}
            </div>
          ) : (
            <div className="grid min-h-36 place-items-center px-5 text-sm text-[#91866f]">
              ر�^�Oداد س�Oست�.�O ثبت �?شد�? است.
            </div>
          )}
        </article>
      </section>

      <details className="rounded-[24px] border border-[#d0b359]/15 bg-[#041d15]/82 p-5">
        <summary className="cursor-pointer font-semibold text-[#efd782]">
          Snapshot �,�O�.ت�?Oگذار�O سفارش
        </summary>
        <div className="mt-4">
          <JsonPreview value={order.pricingSnapshot} />
        </div>
      </details>
    </div>
  );
}

