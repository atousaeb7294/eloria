﻿import { Prisma } from "@/generated/prisma/client";

import { articleSeoScore } from "@/lib/content-studio";
import { prisma, withDatabaseRetry } from "@/lib/prisma";

export type ContentSeoIssue = {
  id: string;
  severity: "HIGH" | "MEDIUM" | "LOW";
  title: string;
  detail: string;
  action: string;
};

export type ContentSeoHealth = {
  overallScore: number;
  publishedArticleCount: number;
  draftArticleCount: number;
  activeProductCount: number;
  productsMissingDescription: number;
  productsMissingImageAlt: number;
  stalePublishedArticleCount: number;
  averagePublishedArticleScore: number;
  issues: ContentSeoIssue[];
};

type ContentSeoMetrics = Omit<ContentSeoHealth, "overallScore" | "issues">;

function nonEmpty(value: string | null | undefined): boolean {
  return Boolean(value?.trim());
}

function clampScore(value: number): number {
  return Math.min(100, Math.max(0, Math.round(value)));
}

export function buildContentSeoHealth(
  metrics: ContentSeoMetrics,
): ContentSeoHealth {
  const issues: ContentSeoIssue[] = [];
  let score = 100;

  if (metrics.activeProductCount === 0) {
    issues.push({
      id: "NO_ACTIVE_PRODUCTS",
      severity: "LOW",
      title: "�?�?�^ز �.حص�^�" فعا�"�O برا�O س�?جش �?دار�Oد",
      detail:
        "ا�.ت�Oاز کاتا�"�^گ تا ز�.ا�? فعا�"�?Oشد�? �.حص�^�" �^ا�,ع�O ا�?داز�?�?Oگ�Oر�O �?�.�O�?Oش�^د.",
      action: "پس از �^ر�^د �.حص�^�"�O �.شخصات �^ تص�^�Oر�?ا�O آ�? را کا�.�" ک�?�Oد.",
    });
  } else {
    const descriptionRatio =
      metrics.productsMissingDescription / metrics.activeProductCount;
    const imageRatio =
      metrics.productsMissingImageAlt / metrics.activeProductCount;

    score -= descriptionRatio * 32;
    score -= imageRatio * 24;

    if (metrics.productsMissingDescription > 0) {
      issues.push({
        id: "PRODUCT_DESCRIPTIONS_INCOMPLETE",
        severity: descriptionRatio >= 0.3 ? "HIGH" : "MEDIUM",
        title: "ت�^ض�Oح د�^�?Oزبا�?�?�" بعض�O �.حص�^�"ات کا�.�" �?�Oست",
        detail: `${metrics.productsMissingDescription} �.حص�^�" فعا�" در دست�?Oک�. �Oک زبا�? ت�^ض�Oح �.ف�Oد �?دارد.`,
        action: "در پ�?�" �.حص�^�"ات�O ت�^ض�Oح فارس�O �^ ا�?گ�"�Oس�O �?ر �.حص�^�" را کا�.�" ک�?�Oد.",
      });
    }

    if (metrics.productsMissingImageAlt > 0) {
      issues.push({
        id: "PRODUCT_IMAGE_ALT_INCOMPLETE",
        severity: imageRatio >= 0.3 ? "HIGH" : "MEDIUM",
        title: "�.ت�? جا�Oگز�O�? تص�^�Oر برخ�O �.حص�^�"ات �?ا�,ص است",
        detail: `${metrics.productsMissingImageAlt} �.حص�^�" فعا�"�O تص�^�Oر بد�^�? alt فارس�O �Oا ا�?گ�"�Oس�O دارد �Oا تص�^�Oر �?دارد.`,
        action: "برا�O تص�^�Oر اص�"�O �?ر �.حص�^�"�O alt فارس�O �^ ا�?گ�"�Oس�O د�,�O�, �^ارد ک�?�Oد.",
      });
    }
  }

  if (metrics.publishedArticleCount === 0) {
    score -= 18;
    issues.push({
      id: "NO_PUBLISHED_ARTICLES",
      severity: "MEDIUM",
      title: "�.ج�"�? �?�?�^ز �.�,ا�"�?�" �.�?تشرشد�? �?دارد",
      detail:
        "�.س�Oر ع�.�^�.�O �.�,ا�"�? �^ داد�?�" ساختار�Oافت�? آ�.اد�? است�O ا�.ا �?�?�^ز �.ط�"ب تأ�O�Oدشد�?�?Oا�O برا�O �.�^ت�^ر جست�?O�^ج�^ �^ج�^د �?دارد.",
      action:
        "از �Oک �.حص�^�" �^ا�,ع�O پ�Oش�?O�?�^�Oس بساز�Oد�O �.ت�? را بازب�O�?�O ک�?�Oد �^ سپس �.�?تشرش ک�?�Oد.",
    });
  } else {
    const articleQualityPenalty =
      Math.max(0, 75 - metrics.averagePublishedArticleScore) * 0.22;

    score -= articleQualityPenalty;

    if (metrics.averagePublishedArticleScore < 75) {
      issues.push({
        id: "PUBLISHED_ARTICLE_SEO_INCOMPLETE",
        severity: "MEDIUM",
        title: "برخ�O �.�,ا�"�?�?O�?ا�O �.�?تشرشد�? داد�?�" سئ�^�O کا�.�" �?دار�?د",
        detail: `�.�Oا�?گ�O�? س�"ا�.ت �.حت�^ا�O �.�,ا�"�?�?O�?ا�O �.�?تشرشد�? ${metrics.averagePublishedArticleScore} از ۱۰۰ است.`,
        action:
          "ع�?�^ا�? سئ�^�O ت�^ض�Oح سئ�^�O ک�"�.�?�" ک�"�Oد�O�O تص�^�Oر �^ �.ت�? �?ر د�^ زبا�? را تک�.�O�" ک�?�Oد.",
      });
    }
  }

  if (metrics.stalePublishedArticleCount > 0) {
    score -= Math.min(12, metrics.stalePublishedArticleCount * 3);
    issues.push({
      id: "STALE_PUBLISHED_ARTICLES",
      severity: "LOW",
      title: "�.�,ا�"�?�?O�?ا�O �,د�O�.�O �?�Oاز ب�? بازب�O�?�O دار�?د",
      detail: `${metrics.stalePublishedArticleCount} �.�,ا�"�?�" �.�?تشرشد�? ب�Oش از ۱۲۰ ر�^ز بد�^�? بازب�O�?�O �.ا�?د�? است.`,
      action:
        "اط�"اعات �.حص�^�"�O پ�O�^�?د�?ا�O تص�^�Oر �^ ت�^ض�Oح سئ�^�O �.�,ا�"�?�?O�?ا�O �,د�O�.�O را بازب�O�?�O ک�?�Oد.",
    });
  }

  if (metrics.draftArticleCount > 8) {
    issues.push({
      id: "DRAFT_BACKLOG",
      severity: "LOW",
      title: "پ�Oش�?O�?�^�Oس�?O�?ا�O ز�Oاد�O در صف �?ست�?د",
      detail: `${metrics.draftArticleCount} پ�Oش�?O�?�^�Oس �?�?�^ز تص�.�O�. تحر�Oر�O�? �?گرفت�? است.`,
      action:
        "پ�Oش�?O�?�^�Oس�?O�?ا را تأ�O�Oد�O اص�"اح �Oا با�Oگا�?�O ک�?�Oد تا صف �.حت�^ا �,اب�" �.د�Oر�Oت ب�.ا�?د.",
    });
  }

  return {
    ...metrics,
    overallScore: clampScore(score),
    issues,
  };
}

function tehranDay(): Date {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tehran",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const values = Object.fromEntries(
    parts
      .filter((part) => part.type !== "literal")
      .map((part) => [part.type, part.value]),
  );

  return new Date(
    Date.UTC(Number(values.year), Number(values.month) - 1, Number(values.day)),
  );
}

export async function getContentSeoHealth(): Promise<ContentSeoHealth> {
  const staleBefore = new Date(Date.now() - 120 * 24 * 60 * 60 * 1_000);

  const [activeProducts, articleCounts, publishedArticles] =
    await withDatabaseRetry(() =>
      Promise.all([
        prisma.product.findMany({
          where: {
            status: {
              in: ["ACTIVE", "OUT_OF_STOCK"],
            },
          },
          select: {
            descriptionFa: true,
            descriptionEn: true,
            images: {
              orderBy: [
                {
                  isPrimary: "desc",
                },
                {
                  displayOrder: "asc",
                },
              ],
              select: {
                altFa: true,
                altEn: true,
              },
            },
          },
        }),
        prisma.contentArticle.groupBy({
          by: ["status"],
          _count: {
            _all: true,
          },
        }),
        prisma.contentArticle.findMany({
          where: {
            status: "PUBLISHED",
          },
          select: {
            titleFa: true,
            titleEn: true,
            excerptFa: true,
            excerptEn: true,
            contentFa: true,
            contentEn: true,
            seoTitleFa: true,
            seoTitleEn: true,
            seoDescriptionFa: true,
            seoDescriptionEn: true,
            focusKeywordFa: true,
            focusKeywordEn: true,
            coverImageUrl: true,
            sourceProductId: true,
            sourceCollectionId: true,
            publishedAt: true,
          },
        }),
      ]),
    );

  const countByStatus = new Map(
    articleCounts.map((item) => [item.status, item._count._all]),
  );
  const productsMissingDescription = activeProducts.filter(
    (product) =>
      !nonEmpty(product.descriptionFa) || !nonEmpty(product.descriptionEn),
  ).length;
  const productsMissingImageAlt = activeProducts.filter((product) => {
    const primary = product.images[0];

    return !primary || !nonEmpty(primary.altFa) || !nonEmpty(primary.altEn);
  }).length;
  const scores = publishedArticles.map((article) => articleSeoScore(article));
  const averagePublishedArticleScore =
    scores.length === 0
      ? 0
      : Math.round(
          scores.reduce((total, score) => total + score, 0) / scores.length,
        );
  const stalePublishedArticleCount = publishedArticles.filter(
    (article) =>
      article.publishedAt !== null && article.publishedAt < staleBefore,
  ).length;

  return buildContentSeoHealth({
    publishedArticleCount: countByStatus.get("PUBLISHED") ?? 0,
    draftArticleCount:
      (countByStatus.get("DRAFT") ?? 0) + (countByStatus.get("IN_REVIEW") ?? 0),
    activeProductCount: activeProducts.length,
    productsMissingDescription,
    productsMissingImageAlt,
    stalePublishedArticleCount,
    averagePublishedArticleScore,
  });
}

export async function recordContentSeoSnapshot(): Promise<{
  created: boolean;
  health: ContentSeoHealth;
}> {
  const health = await getContentSeoHealth();
  const recordedFor = tehranDay();

  const existing = await withDatabaseRetry(() =>
    prisma.contentSeoSnapshot.findUnique({
      where: {
        recordedFor,
      },
      select: {
        id: true,
      },
    }),
  );

  if (existing) {
    return {
      created: false,
      health,
    };
  }

  try {
    await withDatabaseRetry(() =>
      prisma.contentSeoSnapshot.create({
        data: {
          recordedFor,
          overallScore: health.overallScore,
          publishedArticleCount: health.publishedArticleCount,
          draftArticleCount: health.draftArticleCount,
          activeProductCount: health.activeProductCount,
          productsMissingDescription: health.productsMissingDescription,
          productsMissingImageAlt: health.productsMissingImageAlt,
          stalePublishedArticleCount: health.stalePublishedArticleCount,
          issues: JSON.parse(
            JSON.stringify(health.issues),
          ) as Prisma.InputJsonValue,
        },
      }),
    );
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    ) {
      return {
        created: false,
        health,
      };
    }

    throw error;
  }

  return {
    created: true,
    health,
  };
}

