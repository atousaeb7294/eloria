﻿export function formatAdminMoney(
  value:
    | { toString(): string }
    | string
    | number
    | null
    | undefined,
): string {
  if (
    value === null ||
    value === undefined
  ) {
    return "�?"";
  }

  const rawValue =
    value.toString().trim();

  const integerPart =
    rawValue.split(".")[0];

  if (
    !/^-?\d+$/.test(
      integerPart,
    )
  ) {
    return rawValue;
  }

  try {
    return `${new Intl.NumberFormat("fa-IR").format(BigInt(integerPart))} ت�^�.ا�?`;
  } catch {
    return `${integerPart} ت�^�.ا�?`;
  }
}

export function formatAdminDate(
  value:
    | Date
    | string
    | null
    | undefined,
): string {
  if (!value) {
    return "�?"";
  }

  const date =
    value instanceof Date
      ? value
      : new Date(value);

  if (
    Number.isNaN(
      date.getTime(),
    )
  ) {
    return "�?"";
  }

  return new Intl.DateTimeFormat(
    "fa-IR",
    {
      dateStyle: "medium",
      timeStyle: "short",
    },
  ).format(date);
}

export function getProductStatusLabel(
  status: string,
): string {
  const labels: Record<string, string> = {
    DRAFT: "پ�Oش�?O�?�^�Oس",
    ACTIVE: "�.�?تشرشد�?",
    OUT_OF_STOCK: "�?ا�.�^ج�^د",
    ARCHIVED: "با�Oگا�?�O�?Oشد�?",
  };

  return labels[status] ?? status;
}

export function getOrderStatusLabel(
  status: string,
): string {
  const labels: Record<string, string> = {
    PENDING_PAYMENT: "در ا�?تظار پرداخت",
    PAID: "پرداخت�?Oشد�?",
    PROCESSING: "در حا�" آ�.اد�?�?Oساز�O",
    SHIPPED: "ارسا�"�?Oشد�?",
    COMPLETED: "تک�.�O�"�?Oشد�?",
    PAYMENT_FAILED: "پرداخت �?ا�.�^ف�,",
    PAYMENT_REVIEW: "پرداخت �?�Oاز�.�?د بررس�O",
    CANCELLED: "�"غ�^شد�?",
    EXPIRED: "�.�?�,ض�O�?Oشد�?",
    REFUNDED: "بازپرداخت�?Oشد�?",
  };

  return labels[status] ?? status;
}

