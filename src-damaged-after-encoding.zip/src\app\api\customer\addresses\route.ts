﻿import {
  NextRequest,
  NextResponse,
} from "next/server";

import {
  getCustomerFromRequest,
} from "@/lib/customer-auth";
import {
  createCustomerAddress,
  CustomerDataError,
} from "@/lib/customer-data";
import { prisma } from "@/lib/prisma";
import {
  readJsonBody,
} from "@/lib/security/json-body";
import {
  hasTrustedOrigin,
} from "@/lib/security/request";

export const runtime = "nodejs";

export async function GET(
  request: NextRequest,
) {
  const auth =
    await getCustomerFromRequest(
      request,
    );

  if (!auth) {
    return NextResponse.json(
      { successful: false },
      { status: 401 },
    );
  }

  const addresses =
    await prisma.customerAddress.findMany({
      where: {
        customerId:
          auth.customer.id,
      },
      orderBy: [
        {
          isDefault: "desc",
        },
        {
          createdAt: "desc",
        },
      ],
    });

  return NextResponse.json(
    {
      successful: true,
      addresses,
    },
    {
      headers: {
        "Cache-Control":
          "no-store",
      },
    },
  );
}

export async function POST(
  request: NextRequest,
) {
  if (!hasTrustedOrigin(request)) {
    return NextResponse.json(
      {
        successful: false,
        message:
          "�.بدأ درخ�^است �.عتبر �?�Oست.",
      },
      { status: 403 },
    );
  }

  const auth =
    await getCustomerFromRequest(
      request,
    );

  if (!auth) {
    return NextResponse.json(
      {
        successful: false,
        message:
          "ابتدا �^ارد حساب ش�^�Oد.",
      },
      { status: 401 },
    );
  }

  const body =
    await readJsonBody<unknown>(
      request,
      16 * 1024,
    ).catch(() => null);

  if (!body) {
    return NextResponse.json(
      {
        successful: false,
        message:
          "اط�"اعات آدرس �.عتبر �?�Oست.",
      },
      { status: 400 },
    );
  }

  try {
    return NextResponse.json(
      {
        successful: true,
        address:
          await createCustomerAddress(
            auth.customer.id,
            body,
          ),
      },
      { status: 201 },
    );
  } catch (error) {
    if (error instanceof CustomerDataError) {
      return NextResponse.json(
        {
          successful: false,
          message: error.message,
        },
        { status: 400 },
      );
    }

    console.error(
      "[Eloria Customer Address] Unexpected create failure.",
      error,
    );

    return NextResponse.json(
      {
        successful: false,
        message: "ذخ�Oر�? آدرس �?ا�.�^ف�, ب�^د.",
      },
      { status: 500 },
    );
  }
}

