﻿"use client";

import { useEffect, useState } from "react";

type ProductCardLivePriceProps = {
  slug: string;
  locale: string;
  initialPriceToman?: string | null;
};

type PriceResponse = {
  successful?: boolean;
  pricing?: {
    finalPriceToman?: string;
  };
};

function formatPrice(value: string, locale: string) {
  try {
    return BigInt(value).toLocaleString(locale === "fa" ? "fa-IR" : "en-US");
  } catch {
    return value;
  }
}

export function ProductCardLivePrice({
  slug,
  locale,
  initialPriceToman = null,
}: ProductCardLivePriceProps) {
  const [price, setPrice] = useState<string | null>(initialPriceToman);
  const [failed, setFailed] = useState(false);
  const isPersian = locale === "fa";

  useEffect(() => {
    if (initialPriceToman) {
      return;
    }

    const controller = new AbortController();

    async function loadPrice() {
      try {
        const response = await fetch(
          `/api/products/${encodeURIComponent(slug)}/price?display=1`,
          {
            signal: controller.signal,
            cache: "default",
          },
        );

        if (!response.ok) {
          throw new Error("Price request failed");
        }

        const payload = (await response.json()) as PriceResponse;
        const finalPrice = payload.pricing?.finalPriceToman;

        if (!payload.successful || !finalPrice) {
          throw new Error("Price unavailable");
        }

        setPrice(finalPrice);
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }

        setFailed(true);
      }
    }

    void loadPrice();

    return () => controller.abort();
  }, [initialPriceToman, slug]);

  if (failed) {
    return (
      <p className="text-sm text-[#d8c79e]/75">
        {isPersian ? "�,�O�.ت در صفح�? �.حص�^�"" : "Price on product page"}
      </p>
    );
  }

  if (!price) {
    return (
      <div
        className="h-7 w-36 animate-pulse rounded-full bg-white/[0.07]"
        aria-label={isPersian ? "در حا�" در�Oافت �,�O�.ت" : "Loading price"}
      />
    );
  }

  return (
    <p className="flex items-baseline gap-2 text-[#f3d98c]">
      <strong className="text-xl font-semibold tracking-tight">
        {formatPrice(price, locale)}
      </strong>
      <span className="text-xs text-[#d9c28b]/80">
        {isPersian ? "ت�^�.ا�?" : "Toman"}
      </span>
    </p>
  );
}

