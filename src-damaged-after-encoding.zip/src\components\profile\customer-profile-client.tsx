﻿"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { FormEvent } from "react";
import { Bell, Check, CircleCheck, CreditCard, Heart, LogOut, MapPin, Package, PackageCheck, Plus, Save, Trash2, Truck, UserRound } from "lucide-react";

type Order = {
  id: string; orderNumber: string; status: string; payableToman: string; createdAt: string; paidAt: string | null;
  items: Array<{ id: string; productSlug: string; productNameFa: string; productNameEn: string; quantity: number; lineTotalToman: string }>;
};
type Address = { id: string; title: string; recipientName: string; mobile: string; province: string; city: string; postalCode: string; address: string; isDefault: boolean };
type Favorite = { slug: string; nameFa: string; nameEn: string; status: string; imageUrl: string; savedAt: string };
type Notification = { id: string; type: string; titleFa: string; titleEn: string; bodyFa: string; bodyEn: string; orderId: string | null; readAt: string | null; createdAt: string };
type Data = {
  customer: { id: string; mobile: string; fullName: string | null; email: string | null; mobileVerifiedAt: Date | string | null; createdAt: Date | string };
  orders: Order[]; addresses: Address[]; favorites: Favorite[]; notifications: Notification[];
};

type AddressForm = Omit<Address, "id">;
const emptyAddress: AddressForm = { title: "", recipientName: "", mobile: "", province: "", city: "", postalCode: "", address: "", isDefault: false };

function toman(value: string, fa: boolean) {
  const n = Number(value);
  if (!Number.isFinite(n)) return value;
  return new Intl.NumberFormat(fa ? "fa-IR" : "en-US").format(n);
}

function statusLabel(status: string, fa: boolean) {
  const map: Record<string, [string, string]> = {
    PENDING_PAYMENT: ["در ا�?تظار پرداخت", "Pending payment"], PAID: ["پرداخت�?Oشد�?", "Paid"], PROCESSING: ["در حا�" آ�.اد�?�?Oساز�O", "Processing"],
    SHIPPED: ["ارسا�"�?Oشد�?", "Shipped"], COMPLETED: ["تک�.�O�"�?Oشد�?", "Completed"], PAYMENT_FAILED: ["پرداخت �?ا�.�^ف�,", "Payment failed"],
    PAYMENT_REVIEW: ["�?�Oاز�.�?د بررس�O", "Payment review"], CANCELLED: ["�"غ�^شد�?", "Cancelled"], EXPIRED: ["�.�?�,ض�O", "Expired"], REFUNDED: ["بازپرداخت�?Oشد�?", "Refunded"],
  };
  return map[status]?.[fa ? 0 : 1] ?? status;
}

function orderJourney(status: string, fa: boolean) {
  const copy: Record<string, { current: number; title: string; detail: string }> = {
    PENDING_PAYMENT: { current: 0, title: fa ? "پرداخت ا�O�? سفارش را تک�.�O�" ک�?�Oد" : "Complete payment", detail: fa ? "رزر�^ سفارش تا ز�.ا�? �.عتبر ب�^د�? پرداخت حفظ �.�O�?Oش�^د." : "Your reservation remains available while payment is valid." },
    PAYMENT_FAILED: { current: 0, title: fa ? "پرداخت ا�?جا�. �?شد�? است" : "Payment was not completed", detail: fa ? "�.�O�?Oت�^ا�?�Oد پرداخت را د�^بار�? آغاز �Oا سفارش را �"غ�^ ک�?�Oد." : "You can restart payment or cancel this order." },
    PAID: { current: 1, title: fa ? "پرداخت ثبت شد�? است" : "Payment is recorded", detail: fa ? "سفارش برا�O آ�.اد�?�?Oساز�O در صف �,رار دارد." : "Your order is queued for preparation." },
    PAYMENT_REVIEW: { current: 1, title: fa ? "پرداخت در حا�" بررس�O است" : "Payment is being reviewed", detail: fa ? "تا تأ�O�Oد �?�?ا�O�O�O �?�O�? پرداخت�O خ�^دکار �.�^ف�, فرض �?�.�O�?Oش�^د." : "No payment is treated as successful until final verification." },
    PROCESSING: { current: 2, title: fa ? "سفارش در حا�" آ�.اد�?�?Oساز�O است" : "Your order is being prepared", detail: fa ? "بعد از تح�^�O�" ب�? ارسا�"�?Oک�?�?د�?�O کد پ�Oگ�Oر�O در �?�.�O�? حساب د�Oد�? �.�O�?Oش�^د." : "Tracking appears here after handoff to the carrier." },
    SHIPPED: { current: 3, title: fa ? "سفارش ارسا�" شد�? است" : "Your order has shipped", detail: fa ? "از �.س�Oر پ�Oگ�Oر�O سفارش�O �^ضع�Oت ارسا�" را بب�O�?�Oد." : "Use order tracking for the shipment status." },
  };
  return copy[status] ?? null;
}

export function CustomerProfileClient({ locale, initialData }: { locale: "fa" | "en"; initialData: Data }) {
  const fa = locale === "fa";
  const router = useRouter();
  const [profile, setProfile] = useState({ fullName: initialData.customer.fullName ?? "", email: initialData.customer.email ?? "" });
  const [addressForm, setAddressForm] = useState<AddressForm>({ ...emptyAddress, mobile: initialData.customer.mobile, recipientName: initialData.customer.fullName ?? "" });
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const unread = useMemo(() => initialData.notifications.filter(n => !n.readAt).length, [initialData.notifications]);
  const activeOrder = initialData.orders.find(order => Boolean(orderJourney(order.status, fa)));
  const activeJourney = activeOrder ? orderJourney(activeOrder.status, fa) : null;

  async function jsonAction(url: string, method: string, body?: unknown) {
    const response = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
    const data = await response.json().catch(() => null) as { successful?: boolean; message?: string } | null;
    if (!response.ok || !data?.successful) throw new Error(data?.message || (fa ? "ع�.�"�Oات �?ا�.�^ف�, ب�^د." : "Action failed."));
  }

  async function saveProfile(event: FormEvent) {
    event.preventDefault(); setBusy("profile"); setMessage(null);
    try { await jsonAction("/api/customer/me", "PATCH", profile); setMessage(fa ? "اط�"اعات حساب ذخ�Oر�? شد." : "Account details saved."); router.refresh(); }
    catch (e) { setMessage(e instanceof Error ? e.message : "Error"); } finally { setBusy(null); }
  }

  async function saveAddress(event: FormEvent) {
    event.preventDefault(); setBusy("address"); setMessage(null);
    try {
      await jsonAction(editingAddressId ? `/api/customer/addresses/${editingAddressId}` : "/api/customer/addresses", editingAddressId ? "PATCH" : "POST", addressForm);
      setEditingAddressId(null); setAddressForm({ ...emptyAddress, mobile: initialData.customer.mobile, recipientName: initialData.customer.fullName ?? "" });
      setMessage(fa ? "آدرس ذخ�Oر�? شد." : "Address saved."); router.refresh();
    } catch (e) { setMessage(e instanceof Error ? e.message : "Error"); } finally { setBusy(null); }
  }

  async function removeAddress(id: string) {
    setBusy(`address-${id}`); setMessage(null);
    try { await jsonAction(`/api/customer/addresses/${id}`, "DELETE"); router.refresh(); }
    catch (e) { setMessage(e instanceof Error ? e.message : "Error"); } finally { setBusy(null); }
  }

  async function removeFavorite(slug: string) {
    setBusy(`fav-${slug}`);
    try { await jsonAction("/api/customer/favorites", "DELETE", { slug }); router.refresh(); }
    catch (e) { setMessage(e instanceof Error ? e.message : "Error"); } finally { setBusy(null); }
  }

  async function markAllRead() {
    setBusy("notifications");
    try { await jsonAction("/api/customer/notifications", "PATCH", { all: true }); router.refresh(); }
    catch (e) { setMessage(e instanceof Error ? e.message : "Error"); } finally { setBusy(null); }
  }

  async function continuePayment(orderId: string) {
    setBusy(`pay-${orderId}`); setMessage(null);
    try {
      const response = await fetch("/api/payments/zarinpal/start", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        cache: "no-store",
        body: JSON.stringify({ orderId, mobile: initialData.customer.mobile }),
      });
      const data = await response.json().catch(() => null) as { successful?: boolean; message?: string; payment?: { redirectUrl?: string | null } } | null;
      const redirectUrl = data?.payment?.redirectUrl;
      if (!response.ok || data?.successful !== true || !redirectUrl) throw new Error(data?.message || (fa ? "اتصا�" ب�? درگا�? �?ا�.�^ف�, ب�^د." : "Unable to start payment."));
      window.location.assign(redirectUrl);
    } catch (e) { setMessage(e instanceof Error ? e.message : "Error"); setBusy(null); }
  }

  async function cancelOrder(orderId: string) {
    if (typeof window !== "undefined" && !window.confirm(fa ? "ا�O�? سفارش �"غ�^ ش�^د �^ رزر�^ �.�^ج�^د�O آزاد ش�^د�Y" : "Cancel this order and release its inventory reservation?")) return;
    setBusy(`cancel-${orderId}`); setMessage(null);
    try {
      await jsonAction(`/api/customer/orders/${orderId}/cancel`, "POST");
      setMessage(fa ? "سفارش �"غ�^ شد." : "Order cancelled.");
      router.refresh();
    } catch (e) { setMessage(e instanceof Error ? e.message : "Error"); }
    finally { setBusy(null); }
  }

  async function logout() {
    setBusy("logout");
    try { await jsonAction("/api/customer/auth/logout", "POST"); router.replace(`/${locale}/login`); router.refresh(); }
    finally { setBusy(null); }
  }

  const card = "rounded-[28px] border border-[#d8b967]/12 bg-[linear-gradient(155deg,rgba(6,33,24,.72),rgba(2,17,12,.72))] p-5 sm:p-7";
  const input = "h-12 w-full rounded-2xl border border-[#d8b967]/12 bg-black/18 px-4 text-sm text-[#eee0bf] outline-none focus:border-[#dfc575]/35";

  return (
    <main dir={fa ? "rtl" : "ltr"} className="mx-auto max-w-7xl px-4 pb-24 pt-32 sm:px-6 sm:pt-40">
      <header className="rounded-[34px] border border-[#d8b967]/14 bg-[linear-gradient(145deg,rgba(8,42,30,.84),rgba(2,18,13,.9))] p-6 sm:p-9">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-xs text-[#d9c277]/65">{fa ? "حساب �^ا�,ع�O �.شتر�O" : "Customer account"}</p>
            <h1 className={fa ? "font-persian-title mt-3 text-3xl text-[#f2e6c9] sm:text-4xl" : "mt-3 text-3xl font-semibold text-[#f2e6c9] sm:text-4xl"}>{initialData.customer.fullName || (fa ? "عض�^ ا�"�^ر�Oا" : "Eloria member")}</h1>
            <p className="mt-3 text-sm text-[#cbbd9a]/60">{initialData.customer.mobile}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2"><Link href={`/${locale}/profile/watches`} className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-[#d8b967]/16 bg-[#d8b967]/[.05] px-4 text-xs text-[#e8d08a]/78"><Bell className="h-4 w-4" />{fa ? "پ�Oگ�Oر�O�?O�?ا" : "Watches"}</Link><button onClick={() => void logout()} disabled={busy === "logout"} className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-red-300/15 bg-red-300/[.04] px-5 text-xs text-red-100/70"><LogOut className="h-4 w-4" />{fa ? "خر�^ج ا�.�?" : "Sign out"}</button></div>
        </div>
      </header>

      <nav aria-label={fa ? "دسترس�O سر�Oع حساب" : "Account shortcuts"} className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {[
          ["#orders", fa ? "سفارش�?O�?ا" : "Orders"],
          ["#addresses", fa ? "آدرس�?O�?ا" : "Addresses"],
          ["#favorites", fa ? "ع�"ا�,�?�?O�.�?د�O�?O�?ا" : "Favorites"],
          ["#notifications", fa ? "اع�"ا�?�?O�?ا" : "Notifications"],
          ["#account", fa ? "حساب" : "Account"],
        ].map(([href, label]) => <a key={href} href={href} className="shrink-0 rounded-full border border-[#d8b967]/12 bg-black/10 px-4 py-2 text-xs text-[#d9ca9f]/68 transition hover:border-[#d8b967]/28 hover:text-[#ead58e]">{label}</a>)}
        <Link href={`/${locale}/profile/watches`} className="shrink-0 rounded-full border border-[#d8b967]/12 bg-black/10 px-4 py-2 text-xs text-[#d9ca9f]/68 transition hover:border-[#d8b967]/28 hover:text-[#ead58e]">{fa ? "پ�Oگ�Oر�O �,�O�.ت" : "Price watches"}</Link>
      </nav>

      {message ? <div className="mt-5 rounded-2xl border border-[#d8b967]/12 bg-[#071d15]/80 p-4 text-sm text-[#e4d4ae]/75">{message}</div> : null}

      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          [Package, fa ? "سفارش�?O�?ا" : "Orders", initialData.orders.length],
          [MapPin, fa ? "آدرس�?O�?ا" : "Addresses", initialData.addresses.length],
          [Heart, fa ? "ع�"ا�,�?�?O�.�?د�O�?O�?ا" : "Favorites", initialData.favorites.length],
          [Bell, fa ? "اع�"ا�? جد�Oد" : "Unread", unread],
        ].map(([Icon, label, value], i) => {
          const C = Icon as typeof Package;
          return <div key={i} className={card}><C className="h-5 w-5 text-[#d9bd72]/65" /><p className="mt-4 text-2xl text-[#f0dfb4]">{String(value)}</p><p className="mt-1 text-xs text-[#c5b797]/55">{String(label)}</p></div>;
        })}
      </div>

      {activeOrder && activeJourney ? <section id="active-order" className={`${card} mt-6 border-[#d8b967]/20 bg-[linear-gradient(135deg,rgba(16,57,41,.9),rgba(3,22,15,.9))]`}>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-[#d8b967]/20 bg-[#d8b967]/[.07] text-[#e3c978]"><PackageCheck className="h-5 w-5" /></span><div><p className="text-xs text-[#d9c277]/65">{fa ? "سفارش فعا�" ش�.ا" : "Your active order"}</p><h2 className={fa ? "font-persian-title mt-2 text-xl text-[#f2e6c9]" : "mt-2 text-xl font-semibold text-[#f2e6c9]"}>{activeJourney.title}</h2><p className="mt-2 text-xs leading-6 text-[#cbbd9a]/62">{activeJourney.detail}</p></div></div>
          <div className="text-start sm:text-end"><p className="font-mono text-sm text-[#ead391]">{activeOrder.orderNumber}</p><p className="mt-2 text-xs text-[#d9bd72]/65">{statusLabel(activeOrder.status, fa)}</p></div>
        </div>
        <div className="mt-6 grid grid-cols-4 gap-2">
          {[
            [CreditCard, fa ? "پرداخت" : "Payment"],
            [CircleCheck, fa ? "تأ�O�Oد" : "Confirmed"],
            [Package, fa ? "آ�.اد�?�?Oساز�O" : "Preparing"],
            [Truck, fa ? "ارسا�"" : "Shipped"],
          ].map(([Icon, label], index) => {
            const StepIcon = Icon as typeof Package;
            const passed = index <= activeJourney.current;
            return <div key={String(label)} className={`rounded-2xl border p-3 text-center ${passed ? "border-[#d8b967]/26 bg-[#d8b967]/[.08] text-[#ecd482]" : "border-white/5 bg-black/10 text-[#bbaf8e]/50"}`}><StepIcon className="mx-auto h-4 w-4" /><p className="mt-2 text-[10px]">{String(label)}</p></div>;
          })}
        </div>
        <div className="mt-5 flex flex-wrap items-center gap-3"><Link href={`/${locale}/order-tracking?code=${encodeURIComponent(activeOrder.orderNumber)}`} className="inline-flex h-10 items-center justify-center rounded-full border border-[#d8b967]/20 bg-[#123829] px-4 text-xs text-[#edd58b]">{fa ? "پ�Oگ�Oر�O د�,�O�, سفارش" : "Track order"}</Link>{activeOrder.status === "PENDING_PAYMENT" || activeOrder.status === "PAYMENT_FAILED" ? <button type="button" disabled={busy === `pay-${activeOrder.id}`} onClick={() => void continuePayment(activeOrder.id)} className="inline-flex h-10 items-center justify-center rounded-full border border-[#d8b967]/20 px-4 text-xs text-[#edd58b] disabled:opacity-50">{fa ? "ادا�.�? پرداخت" : "Continue payment"}</button> : null}</div>
      </section> : null}

      <section id="orders" className={`${card} mt-6`}>
        <div className="flex items-center gap-3"><Package className="h-5 w-5 text-[#dfc577]" /><h2 className={fa ? "font-persian-title text-xl" : "text-xl font-semibold"}>{fa ? "سفارش�?O�?ا�O �.�?" : "My orders"}</h2></div>
        <div className="mt-5 space-y-3">
          {initialData.orders.length ? initialData.orders.map(order => (
            <article key={order.id} className="rounded-2xl border border-[#d8b967]/9 bg-black/12 p-4 sm:p-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div><p className="font-mono text-sm text-[#ead391]">{order.orderNumber}</p><p className="mt-1 text-xs text-[#c5b798]/50">{new Date(order.createdAt).toLocaleString(fa ? "fa-IR" : "en-US")}</p></div>
                <div className="text-start sm:text-end"><p className="text-sm text-[#ead8ad]">{toman(order.payableToman, fa)} {fa ? "ت�^�.ا�?" : "Toman"}</p><p className="mt-1 text-xs text-[#d9bd72]/65">{statusLabel(order.status, fa)}</p></div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">{order.items.map(item => <Link key={item.id} href={`/${locale}/products/${item.productSlug}`} className="rounded-full border border-[#d8b967]/10 px-3 py-1.5 text-[11px] text-[#d3c49f]/65">{fa ? item.productNameFa : item.productNameEn} �- {item.quantity}</Link>)}</div>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <Link href={`/${locale}/order-tracking?code=${encodeURIComponent(order.orderNumber)}`} className="inline-flex text-xs text-[#e1c576]">{fa ? "پ�Oگ�Oر�O سفارش" : "Track order"}</Link>
                {order.status === "PENDING_PAYMENT" || order.status === "PAYMENT_FAILED" ? (
                  <>
                    <button type="button" disabled={busy === `pay-${order.id}`} onClick={() => void continuePayment(order.id)} className="inline-flex min-h-9 items-center justify-center rounded-full border border-[#d8b967]/20 bg-[#123829] px-4 text-xs text-[#edd58b] disabled:opacity-50">
                      {busy === `pay-${order.id}` ? (fa ? "در حا�" اتصا�"..." : "Connecting...") : (fa ? "ادا�.�? پرداخت" : "Continue payment")}
                    </button>
                    <button type="button" disabled={busy === `cancel-${order.id}`} onClick={() => void cancelOrder(order.id)} className="inline-flex min-h-9 items-center justify-center rounded-full border border-red-300/15 px-4 text-xs text-red-100/60 disabled:opacity-50">
                      {busy === `cancel-${order.id}` ? (fa ? "در حا�" �"غ�^..." : "Cancelling...") : (fa ? "�"غ�^ سفارش" : "Cancel order")}
                    </button>
                  </>
                ) : null}
              </div>
            </article>
          )) : <p className="py-6 text-sm text-[#c7b995]/55">{fa ? "�?�?�^ز سفارش�O ب�? ا�O�? حساب �.تص�" �?شد�? است." : "No orders are linked to this account yet."}</p>}
        </div>
      </section>

      <section id="addresses" className={`${card} mt-6`}>
        <div className="flex items-center justify-between gap-3"><div className="flex items-center gap-3"><MapPin className="h-5 w-5 text-[#dfc577]" /><h2 className={fa ? "font-persian-title text-xl" : "text-xl font-semibold"}>{fa ? "آدرس�?O�?ا�O �.�?" : "My addresses"}</h2></div><Plus className="h-4 w-4 text-[#d8bd72]/60" /></div>
        <div className="mt-5 grid gap-3 md:grid-cols-2">
          {initialData.addresses.map(a => <article key={a.id} className="rounded-2xl border border-[#d8b967]/9 bg-black/12 p-4">
            <div className="flex items-start justify-between gap-3"><div><p className="text-sm text-[#ead9b1]">{a.title}{a.isDefault ? <span className="ms-2 text-[10px] text-[#d9bd72]">{fa ? "پ�Oش�?Oفرض" : "Default"}</span> : null}</p><p className="mt-2 text-xs leading-6 text-[#c5b797]/55">{a.province}�O {a.city}�O {a.address}</p><p className="mt-1 text-xs text-[#c5b797]/45">{a.postalCode} · {a.mobile}</p></div><div className="flex gap-1"><button onClick={() => { setEditingAddressId(a.id); setAddressForm({ title: a.title, recipientName: a.recipientName, mobile: a.mobile, province: a.province, city: a.city, postalCode: a.postalCode, address: a.address, isDefault: a.isDefault }); }} className="rounded-lg p-2 text-[#d9bd72]/60"><Save className="h-4 w-4" /></button><button disabled={busy === `address-${a.id}`} onClick={() => void removeAddress(a.id)} className="rounded-lg p-2 text-red-200/50"><Trash2 className="h-4 w-4" /></button></div></div>
          </article>)}
        </div>
        <form onSubmit={saveAddress} className="mt-5 grid gap-3 md:grid-cols-2">
          <input className={input} placeholder={fa ? "ع�?�^ا�? آدرس (خا�?�?�O �.ح�" کار...)" : "Address title"} value={addressForm.title} onChange={e => setAddressForm(v => ({ ...v, title: e.target.value }))} />
          <input className={input} placeholder={fa ? "�?ا�. تح�^�O�"�?Oگ�Oر�?د�?" : "Recipient name"} value={addressForm.recipientName} onChange={e => setAddressForm(v => ({ ...v, recipientName: e.target.value }))} />
          <input className={input} placeholder={fa ? "�.�^با�O�" تح�^�O�"�?Oگ�Oر�?د�?" : "Recipient mobile"} value={addressForm.mobile} onChange={e => setAddressForm(v => ({ ...v, mobile: e.target.value }))} />
          <input className={input} placeholder={fa ? "استا�?" : "Province"} value={addressForm.province} onChange={e => setAddressForm(v => ({ ...v, province: e.target.value }))} />
          <input className={input} placeholder={fa ? "ش�?ر" : "City"} value={addressForm.city} onChange={e => setAddressForm(v => ({ ...v, city: e.target.value }))} />
          <input className={input} placeholder={fa ? "کد پست�O" : "Postal code"} value={addressForm.postalCode} onChange={e => setAddressForm(v => ({ ...v, postalCode: e.target.value }))} />
          <textarea className="min-h-28 rounded-2xl border border-[#d8b967]/12 bg-black/18 p-4 text-sm text-[#eee0bf] outline-none focus:border-[#dfc575]/35 md:col-span-2" placeholder={fa ? "�?شا�?�O کا�.�"" : "Full address"} value={addressForm.address} onChange={e => setAddressForm(v => ({ ...v, address: e.target.value }))} />
          <label className="flex items-center gap-2 text-xs text-[#c7b998]/60"><input type="checkbox" checked={addressForm.isDefault} onChange={e => setAddressForm(v => ({ ...v, isDefault: e.target.checked }))} />{fa ? "آدرس پ�Oش�?Oفرض" : "Default address"}</label>
          <button disabled={busy === "address"} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-[#d8b967]/20 bg-[#123829] text-xs text-[#e8d18b]"><Save className="h-4 w-4" />{editingAddressId ? (fa ? "ذخ�Oر�? �^�Oرا�Oش" : "Save changes") : (fa ? "افز�^د�? آدرس" : "Add address")}</button>
        </form>
      </section>

      <section id="favorites" className={`${card} mt-6`}>
        <div className="flex items-center gap-3"><Heart className="h-5 w-5 text-[#dfc577]" /><h2 className={fa ? "font-persian-title text-xl" : "text-xl font-semibold"}>{fa ? "ع�"ا�,�?�?O�.�?د�O�?O�?ا" : "Favorites"}</h2></div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {initialData.favorites.map(item => <article key={item.slug} className="flex items-center gap-3 rounded-2xl border border-[#d8b967]/9 bg-black/12 p-3">
            <div className="relative h-16 w-16 overflow-hidden rounded-xl bg-black/20">{item.imageUrl ? <Image src={item.imageUrl} alt={fa ? item.nameFa : item.nameEn} fill sizes="64px" className="object-cover" /> : null}</div>
            <Link href={`/${locale}/products/${item.slug}`} className="min-w-0 flex-1 text-sm text-[#ead9b1]">{fa ? item.nameFa : item.nameEn}</Link>
            <button disabled={busy === `fav-${item.slug}`} onClick={() => void removeFavorite(item.slug)} className="p-2 text-red-200/50"><Trash2 className="h-4 w-4" /></button>
          </article>)}
          {!initialData.favorites.length ? <p className="text-sm text-[#c7b995]/55">{fa ? "�?�?�^ز �.حص�^�"�O ذخ�Oر�? �?کرد�?�?Oا�Oد." : "No saved products yet."}</p> : null}
        </div>
      </section>

      <section id="notifications" className={`${card} mt-6`}>
        <div className="flex items-center justify-between gap-3"><div className="flex items-center gap-3"><Bell className="h-5 w-5 text-[#dfc577]" /><h2 className={fa ? "font-persian-title text-xl" : "text-xl font-semibold"}>{fa ? "اع�"ا�?�?O�?ا" : "Notifications"}</h2></div>{unread ? <button disabled={busy === "notifications"} onClick={() => void markAllRead()} className="inline-flex items-center gap-2 text-xs text-[#d8bd72]/70"><Check className="h-4 w-4" />{fa ? "خ�^ا�?د�? �?�.�?" : "Mark all read"}</button> : null}</div>
        <div className="mt-5 space-y-2">{initialData.notifications.map(n => <article key={n.id} className={`rounded-2xl border p-4 ${n.readAt ? "border-[#d8b967]/7 bg-black/8" : "border-[#d8b967]/16 bg-[#0b2c20]/45"}`}><p className="text-sm text-[#e9d7ad]">{fa ? n.titleFa : n.titleEn}</p><p className="mt-2 text-xs leading-6 text-[#c4b696]/55">{fa ? n.bodyFa : n.bodyEn}</p></article>)}{!initialData.notifications.length ? <p className="text-sm text-[#c7b995]/55">{fa ? "اع�"ا�? جد�Oد�O �?دار�Oد." : "No notifications yet."}</p> : null}</div>
      </section>

      <section id="account" className={`${card} mt-6`}>
        <div className="flex items-center gap-3"><UserRound className="h-5 w-5 text-[#dfc577]" /><h2 className={fa ? "font-persian-title text-xl" : "text-xl font-semibold"}>{fa ? "اط�"اعات حساب" : "Account details"}</h2></div>
        <form onSubmit={saveProfile} className="mt-5 grid gap-3 sm:grid-cols-2"><input className={input} value={profile.fullName} onChange={e => setProfile(v => ({ ...v, fullName: e.target.value }))} placeholder={fa ? "�?ا�. �^ �?ا�. خا�?�^ادگ�O" : "Full name"} /><input className={input} value={profile.email} onChange={e => setProfile(v => ({ ...v, email: e.target.value }))} placeholder={fa ? "ا�O�.�O�"" : "Email"} /><input className={`${input} opacity-65`} value={initialData.customer.mobile} disabled /><button disabled={busy === "profile"} className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl border border-[#d8b967]/20 bg-[#123829] text-xs text-[#e8d18b]"><Save className="h-4 w-4" />{fa ? "ذخ�Oر�? اط�"اعات" : "Save details"}</button></form>
      </section>
    </main>
  );
}

