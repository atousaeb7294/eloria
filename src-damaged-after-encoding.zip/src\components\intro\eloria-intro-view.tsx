﻿"use client";

import { AnimatePresence, motion } from "motion/react";
import { FLASH_IN_DURATION_MS, HERO_REVEAL_DURATION_MS, INTRO_VIDEO_ONE_SRC, INTRO_VIDEO_TWO_SRC, type EloriaIntroExperienceProps } from "@/components/intro/eloria-intro-config";
import type { EloriaIntroController } from "@/components/intro/use-eloria-intro-controller";

export function EloriaIntroView({
  controller,
}: EloriaIntroExperienceProps & { controller: EloriaIntroController }) {
  const {
    firstVideoRef,
    secondVideoRef,
    phase,
    autoplayBlocked,
    setSecondVideoReady,
    secondVideoBuffering,
    isPersian,
    completeIntro,
    beginCinematicReveal,
    handleFirstVideoCanPlay,
    handleManualStart,
    handleFirstVideoEnded,
    handleFirstVideoProgress,
    handleEnterEloria,
    handleSecondVideoPlaying,
    handleSecondVideoWaiting,
    handleVideoFailure,
  } = controller;

  if (
    phase ===
    "complete"
  ) {
    return null;
  }

  const showFirstVideo =
    phase ===
      "video-one" ||
    phase ===
      "awaiting-entry";

  const showSecondVideo =
    phase ===
      "video-two" ||
    phase ===
      "flash-in";

  const transitionActive =
    phase ===
      "flash-in" ||
    phase ===
      "hero-reveal";

  const heroIsRevealing =
    phase ===
    "hero-reveal";

  const introStep =
    phase === "video-two" ||
    phase === "flash-in" ||
    phase === "hero-reveal"
      ? 2
      : 1;

  const introStatus =
    isPersian
      ? introStep === 1
        ? "پرد�? �?خست"
        : "پرد�? د�^�."
      : introStep === 1
        ? "Act One"
        : "Act Two";

  return (
    <AnimatePresence>
      <motion.div
        key="eloria-intro"
        initial={{
          opacity:
            1,
        }}
        className="eloria-intro-root fixed inset-0 z-[100] overflow-hidden"
        aria-label={
          isPersian
            ? "�^ر�^د س�O�?�.ا�O�O ب�? د�?�Oا�O ا�"�^ر�Oا"
            : "Cinematic entrance to Eloria"
        }
      >
        {/*
         * ا�O�? �"ا�O�? �?�?گا�. ا�^ج �?�^ر �.ح�^ �.�O�?Oش�^د
         * �^ Hero �^ا�,ع�O ز�Oر آ�? د�Oد�? خ�^ا�?د شد.
         */}
        <motion.div
          className="absolute inset-0 bg-[#010b07]"
          initial={false}
          animate={
            phase ===
            "flash-in"
              ? {
                  opacity:
                    1,

                  scale:
                    1.035,

                  filter:
                    "brightness(1.75) saturate(1.15) blur(1px)",
                }
              : heroIsRevealing
                ? {
                    opacity:
                      0,

                    scale:
                      1.09,

                    filter:
                      "brightness(2.8) saturate(1.25) blur(12px)",
                  }
                : {
                    opacity:
                      1,

                    scale:
                      1,

                    filter:
                      "brightness(1) saturate(1) blur(0px)",
                  }
          }
          transition={
            heroIsRevealing
              ? {
                  duration:
                    0.48,

                  ease: [
                    0.16,
                    1,
                    0.3,
                    1,
                  ],
                }
              : {
                  duration:
                    FLASH_IN_DURATION_MS /
                    1000,

                  ease:
                    "easeIn",
                }
          }
        >
          <video
            ref={
              firstVideoRef
            }
            className={[
              "absolute inset-0 size-full bg-[#010b07] object-contain object-center transition-opacity duration-500",
              showFirstVideo
                ? "opacity-100"
                : "pointer-events-none opacity-0",
            ].join(" ")}
            src={INTRO_VIDEO_ONE_SRC}
            poster="/images/hero/eloria-hero.jpeg"
            preload="metadata"
            autoPlay
            muted
            playsInline
            disablePictureInPicture
            controls={false}
            onCanPlay={
              handleFirstVideoCanPlay
            }
            onTimeUpdate={
              handleFirstVideoProgress
            }
            onEnded={
              handleFirstVideoEnded
            }
            onError={
              handleVideoFailure
            }
          />

          <video
            ref={
              secondVideoRef
            }
            className={[
              "absolute inset-0 size-full bg-[#010b07] object-contain object-center transition-opacity duration-500",
              showSecondVideo
                ? "opacity-100"
                : "pointer-events-none opacity-0",
            ].join(" ")}
            src={INTRO_VIDEO_TWO_SRC}
            poster="/images/hero/eloria-hero.jpeg"
            preload="none"
            playsInline
            disablePictureInPicture
            controls={false}
            onCanPlay={() => {
              setSecondVideoReady(
                true,
              );
            }}
            onPlaying={
              handleSecondVideoPlaying
            }
            onWaiting={
              handleSecondVideoWaiting
            }
            onEnded={
              beginCinematicReveal
            }
            onError={
              handleVideoFailure
            }
          />

          <div
            aria-hidden="true"
            className="absolute inset-0 bg-[linear-gradient(180deg,rgba(0,7,4,0.13),transparent_34%,transparent_67%,rgba(0,9,5,0.6))]"
          />

          <div
            aria-hidden="true"
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,rgba(0,7,4,0.14)_66%,rgba(0,4,2,0.65)_100%)]"
          />

          <div
            aria-hidden="true"
            className="absolute inset-x-0 bottom-0 h-[42%] bg-[linear-gradient(180deg,transparent,rgba(0,7,4,0.72))] sm:h-[34%]"
          />
        </motion.div>

        {/*
         * �?�^ر �.ت�.رکز از داخ�" در شر�^ع �.�O�?Oش�^د�O
         * �^�"�O Hero د�Oگر از �Oک Mask دا�Oر�?�?Oا�O ظا�?ر �?�.�O�?Oش�^د.
         */}
        <motion.div
          aria-hidden="true"
          className="eloria-door-light pointer-events-none absolute"
          initial={false}
          animate={
            phase ===
            "flash-in"
              ? {
                  opacity:
                    1,

                  scale:
                    3.2,
                }
              : heroIsRevealing
                ? {
                    opacity:
                      0,

                    scale:
                      5.5,
                  }
                : {
                    opacity:
                      0,

                    scale:
                      0.25,
                  }
          }
          transition={
            heroIsRevealing
              ? {
                  duration:
                    HERO_REVEAL_DURATION_MS /
                    1000,

                  ease:
                    "easeOut",
                }
              : {
                  duration:
                    FLASH_IN_DURATION_MS /
                    1000,

                  ease: [
                    0.16,
                    1,
                    0.3,
                    1,
                  ],
                }
          }
        />

        {/*
         * �?�^ر ط�"ا�O�O ت�.ا�. صفح�?.
         * در ا�^ج ا�O�? �?�^ر�O �^�Oد�O�^ با Hero تع�^�Oض �.�O�?Oش�^د.
         */}
        <motion.div
          aria-hidden="true"
          className="eloria-full-gold-wash pointer-events-none absolute inset-0"
          initial={false}
          animate={
            phase ===
            "flash-in"
              ? {
                  opacity:
                    1,
                }
              : heroIsRevealing
                ? {
                    opacity:
                      0,
                }
                : {
                    opacity:
                      0,
                }
          }
          transition={
            heroIsRevealing
              ? {
                  duration:
                    HERO_REVEAL_DURATION_MS /
                    1000,

                  ease: [
                    0.22,
                    1,
                    0.36,
                    1,
                  ],
                }
              : {
                  duration:
                    FLASH_IN_DURATION_MS /
                    1000,

                  ease:
                    "easeIn",
                }
          }
        />

        {/*
         * در �"حظ�? آشکارشد�? Hero�O ا�O�? �"ا�O�?
         * Brightness �^ Blur ا�Oجاد �.�O�?Oک�?د �^ سپس �.ح�^ �.�O�?Oش�^د.
         */}
        <motion.div
          aria-hidden="true"
          className="eloria-hero-exposure pointer-events-none absolute inset-0"
          initial={false}
          animate={
            phase ===
            "flash-in"
              ? {
                  opacity:
                    1,
                }
              : heroIsRevealing
                ? {
                    opacity:
                      0,
                }
                : {
                    opacity:
                      0,
                }
          }
          transition={
            heroIsRevealing
              ? {
                  duration:
                    HERO_REVEAL_DURATION_MS /
                    1000,

                  ease: [
                    0.16,
                    1,
                    0.3,
                    1,
                  ],
                }
              : {
                  duration:
                    0.35,

                  ease:
                    "easeIn",
                }
          }
        />

        {/*
         * خط �?�^ر اف�,�O ک�^تا�? در ز�.ا�? تع�^�Oض.
         */}
        <motion.div
          aria-hidden="true"
          className="eloria-light-line pointer-events-none absolute left-1/2 top-1/2 h-px -translate-x-1/2"
          initial={false}
          animate={
            transitionActive
              ? {
                  width:
                    heroIsRevealing
                      ? "120vw"
                      : "48vw",

                  opacity:
                    heroIsRevealing
                      ? 0
                      : 1,
                }
              : {
                  width:
                    "0vw",

                  opacity:
                    0,
                }
          }
          transition={{
            duration:
              heroIsRevealing
                ? 1.1
                : 0.55,

            ease:
              "easeOut",
          }}
        />

        {/* �?شا�?گر �.رح�"�? Intro */}
        {!transitionActive && phase !== "checking" && (
          <div
            className="absolute start-[max(1rem,env(safe-area-inset-left))] top-[max(1rem,env(safe-area-inset-top))] z-[130] flex items-center gap-3 rounded-full border border-[#e7ca78]/22 bg-black/25 px-3.5 py-2 backdrop-blur-xl sm:start-8 sm:top-8"
            aria-label={
              isPersian
                ? `�.رح�"�? ${introStep} از ۲`
                : `Step ${introStep} of 2`
            }
          >
            <span className="font-eloria-brand text-[9px] text-[#f0d98e]/82 sm:text-[10px]">
              ELORIA
            </span>

            <span className="h-3 w-px bg-[#e3c66f]/24" />

            <span className="text-[9px] font-medium tracking-[0.08em] text-white/62 sm:text-[10px]">
              {introStatus}
            </span>

            <span className="flex items-center gap-1" aria-hidden="true">
              {[1, 2].map((step) => (
                <span
                  key={step}
                  className={[
                    "h-1 rounded-full transition-all duration-500",
                    step <= introStep
                      ? "w-4 bg-[#efd382] shadow-[0_0_10px_rgba(239,211,130,0.48)]"
                      : "w-2 bg-white/18",
                  ].join(" ")}
                />
              ))}
            </span>
          </div>
        )}

        {/* دک�.�? ردکرد�? */}
        {!transitionActive && (
          <button
            type="button"
            onClick={
              completeIntro
            }
            className="absolute end-[max(1rem,env(safe-area-inset-right))] top-[max(1rem,env(safe-area-inset-top))] z-[130] min-h-11 rounded-full border border-white/20 bg-black/30 px-4 py-2 text-[11px] tracking-[0.1em] text-white/72 backdrop-blur-xl transition duration-300 hover:border-[#e7ca78]/60 hover:bg-black/45 hover:text-[#f5dda0] sm:end-8 sm:top-8"
          >
            {isPersian
              ? "رد کرد�?"
              : "Skip"}
          </button>
        )}

        {/* بارگذار�O ا�^�"�O�? */}
        {phase ===
          "checking" && (
          <div className="absolute inset-0 z-[140] grid place-items-center bg-[#010b07]">
            <div className="flex flex-col items-center gap-4">
              <span className="size-10 animate-spin rounded-full border border-[#e6c975]/20 border-t-[#f4dc96]" />

              <span className="font-eloria-brand text-[10px] text-[#e8ce87]/70">
                ELORIA
              </span>
            </div>
          </div>
        )}

        {/* شر�^ع دست�O �^�Oد�O�^�O ا�^�" */}
        {autoplayBlocked &&
          phase ===
            "video-one" && (
            <div className="absolute inset-0 z-[135] grid place-items-center bg-black/50 px-6 backdrop-blur-sm">
              <button
                type="button"
                onClick={
                  handleManualStart
                }
                className="group relative min-h-12 w-full max-w-xs overflow-hidden rounded-full border border-[#efd17f]/65 bg-[linear-gradient(135deg,rgba(222,187,99,0.25),rgba(6,64,44,0.82))] px-7 py-3.5 text-sm text-[#ffebaf] shadow-[0_0_48px_rgba(226,190,98,0.22)] transition duration-500 hover:scale-[1.03] hover:border-[#ffe09a]"
              >
                <span className="absolute inset-0 translate-y-full bg-gradient-to-t from-[#f0ce75]/20 to-transparent transition-transform duration-500 group-hover:translate-y-0" />

                <span className="relative">
                  {isPersian
                    ? "شر�^ع سفر"
                    : "Begin the journey"}
                </span>
              </button>
            </div>
          )}

        {/* �,اب جاد�^�O�O �^ر�^د�> بد�^�? ح�"�,�? �Oا �?رخش دائ�.�O */}
                {phase === "awaiting-entry" && (
          <button
            type="button"
            data-eloria-video-hotspot="true"
            onClick={handleEnterEloria}
            aria-label={isPersian ? "�^ر�^د ب�? د�?�Oا�O ا�"�^ر�Oا" : "Enter the world of Eloria"}
            className="absolute left-1/2 bottom-[8%] z-[150] h-[18%] w-[62%] -translate-x-1/2 cursor-pointer border-0 bg-transparent p-0 outline-none"
          >
            <span className="sr-only">
              {isPersian ? "�^ر�^د ب�? د�?�Oا�O ا�"�^ر�Oا" : "Enter the world of Eloria"}
            </span>
          </button>
        )}

        {/* Buffer �^�Oد�O�^�O د�^�. */}
        <AnimatePresence>
          {phase ===
            "video-two" &&
            secondVideoBuffering && (
              <motion.div
                initial={{
                  opacity:
                    0,
                }}
                animate={{
                  opacity:
                    1,
                }}
                exit={{
                  opacity:
                    0,
                }}
                className="pointer-events-none absolute inset-0 z-[125] grid place-items-center bg-black/20 backdrop-blur-[2px]"
                role="status"
                aria-live="polite"
              >
                <div className="flex flex-col items-center gap-3 rounded-2xl border border-white/10 bg-black/25 px-5 py-4 backdrop-blur-xl">
                  <span className="size-9 animate-spin rounded-full border border-white/20 border-t-[#f1d68d]" />
                  <span className="text-[10px] tracking-[0.08em] text-white/64">
                    {isPersian ? "آ�.اد�?�?Oساز�O ادا�.�? ر�^ا�Oت" : "Preparing the next scene"}
                  </span>
                </div>
              </motion.div>
            )}
        </AnimatePresence>

        <style jsx global>{`
          .eloria-intro-root {
            --eloria-door-x: 50%;
            --eloria-door-y: 52%;
          }

          .eloria-door-light {
            left:
              var(
                --eloria-door-x
              );

            top:
              var(
                --eloria-door-y
              );

            width:
              min(
                30rem,
                54vw
              );

            height:
              min(
                42rem,
                80vh
              );

            transform:
              translate(
                -50%,
                -50%
              );

            transform-origin:
              center;

            border-radius:
              48% 48% 42% 42% /
              38% 38% 56% 56%;

            background:
              radial-gradient(
                ellipse,
                rgba(
                    255,
                    255,
                    244,
                    1
                  )
                  0%,
                rgba(
                    255,
                    242,
                    196,
                    0.98
                  )
                  18%,
                rgba(
                    255,
                    211,
                    112,
                    0.84
                  )
                  40%,
                rgba(
                    208,
                    148,
                    34,
                    0.4
                  )
                  64%,
                transparent
                  84%
              );

            box-shadow:
              0 0 45px
                rgba(
                  255,
                  247,
                  213,
                  1
                ),
              0 0 120px
                rgba(
                  255,
                  215,
                  121,
                  0.9
                ),
              0 0 260px
                rgba(
                  203,
                  143,
                  26,
                  0.64
                );

            filter:
              blur(8px);

            mix-blend-mode:
              screen;
          }

          .eloria-full-gold-wash {
            background:
              radial-gradient(
                ellipse at
                  var(
                    --eloria-door-x
                  )
                  var(
                    --eloria-door-y
                  ),
                rgba(
                    255,
                    255,
                    242,
                    1
                  )
                  0%,
                rgba(
                    255,
                    241,
                    194,
                    0.98
                  )
                  18%,
                rgba(
                    255,
                    213,
                    112,
                    0.88
                  )
                  40%,
                rgba(
                    214,
                    157,
                    45,
                    0.68
                  )
                  67%,
                rgba(
                    70,
                    83,
                    42,
                    0.42
                  )
                  84%,
                rgba(
                    2,
                    20,
                    14,
                    0.2
                  )
                  100%
              );

            mix-blend-mode:
              screen;

            filter:
              saturate(1.16);
          }

          .eloria-hero-exposure {
            background:
              linear-gradient(
                135deg,
                rgba(
                    255,
                    246,
                    210,
                    0.92
                  ),
                rgba(
                    255,
                    213,
                    117,
                    0.7
                  )
                  48%,
                rgba(
                    213,
                    156,
                    48,
                    0.5
                  )
                  72%,
                rgba(
                    16,
                    96,
                    67,
                    0.26
                  )
              );

            -webkit-backdrop-filter:
              brightness(1.9)
              saturate(1.25)
              blur(10px);

            backdrop-filter:
              brightness(1.9)
              saturate(1.25)
              blur(10px);

            mix-blend-mode:
              screen;
          }

          .eloria-light-line {
            background:
              linear-gradient(
                90deg,
                transparent,
                rgba(
                    255,
                    224,
                    143,
                    0.5
                  ),
                rgba(
                    255,
                    255,
                    229,
                    1
                  ),
                rgba(
                    255,
                    224,
                    143,
                    0.5
                  ),
                transparent
              );

            box-shadow:
              0 0 18px
                rgba(
                  255,
                  244,
                  198,
                  1
                ),
              0 0 60px
                rgba(
                  255,
                  204,
                  91,
                  0.9
                );

            filter:
              blur(0.5px);
          }

          @media (
            max-width: 767px
          ) {
            .eloria-intro-root {
              --eloria-door-x: 50%;
              --eloria-door-y: 54%;
            }

            .eloria-door-light {
              width:
                min(
                  21rem,
                  72vw
                );

              height:
                min(
                  35rem,
                  72vh
                );
            }
          }

          @media (max-height: 700px) and (max-width: 767px) {
            .eloria-intro-root {
              --eloria-door-y: 50%;
            }

            .eloria-door-light {
              height: min(28rem, 68vh);
            }
          }

          @media (
            prefers-reduced-motion:
              reduce
          ) {
            .eloria-door-light,
            .eloria-full-gold-wash,
            .eloria-hero-exposure,
            .eloria-light-line {
              animation:
                none !important;

              transition:
                none !important;
            }
          }
        `}</style>
      </motion.div>
    </AnimatePresence>
  );

}

