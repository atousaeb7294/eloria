﻿import type { ReactNode } from "react";
import type { Metadata } from "next";
import { localizedPageMetadata, type EloriaLocale } from "@/lib/seo";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (locale !== "fa" && locale !== "en") return {};

  return localizedPageMetadata({
    locale: locale as EloriaLocale,
    path: "/about",
    title: locale === "fa" ? "داستا�? �^ �?�^�Oت ا�"�^ر�Oا" : "The Story of Eloria",
    description:
      locale === "fa"
        ? "با داستا�?�O ارزش�?O�?ا �^ �?گا�? طراح�O ج�^ا�?رات ا�"�^ر�Oا آش�?ا ش�^�Oد�> ر�^ا�Oت�O ا�"�?ا�.�?Oگرفت�? از شک�^�? ا�Oرا�? ک�?�?."
        : "Discover Eloria�?Ts story, values and jewellery design philosophy inspired by the splendour of ancient Persia.",
    image: "/images/hero/eloria-hero.jpeg",
  });
}

export default function AboutLayout({ children }: { children: ReactNode }) {
  return children;
}

