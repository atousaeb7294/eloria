﻿import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/fa",
    name: "ELORIA �?" د�?�Oا�O ج�^ا�?رات اص�O�"",
    short_name: "ELORIA",
    description:
      "ج�^ا�?رات �"�^کس ا�"�^ر�Oا با ا�"�?ا�. از ا�Oرا�? باستا�? �^ ر�^ا�Oت�?O�?ا�O شا�?�?ا�.�?�?Oا�O",
    start_url: "/fa",
    scope: "/",
    display: "standalone",
    orientation: "portrait-primary",
    background_color: "#010b07",
    theme_color: "#02140e",
    lang: "fa",
    dir: "rtl",
    categories: ["shopping", "lifestyle"],
    icons: [
      {
        src: "/favicon.ico",
        sizes: "any",
        type: "image/x-icon",
      },
      {
        src: "/icons/eloria-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/eloria-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/eloria-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}

