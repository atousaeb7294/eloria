﻿export type MaterialType =
  | "GOLD"
  | "SILVER";

export type MakingChargeType =
  | "NONE"
  | "FIXED"
  | "PER_GRAM"
  | "PERCENT"
  | "COMBINED";

export type DecimalInput =
  | string
  | number
  | bigint;

export type JewelryPriceInput = {
  material: MaterialType;

  /**
   * �^ز�? �.حص�^�" برحسب گر�..
   * برا�O ج�"�^گ�Oر�O از خطا�O اعشار�O ب�?تر است ب�? شک�" رشت�? ارسا�" ش�^د:
   * "3.250"
   */
  weightGrams: DecimalInput;

  /**
   * خ�"�^ص �.حص�^�" بر �.ب�?ا�O �?زار.
   *
   * �?�.�^�?�?:
   * ط�"ا�O ۱۸ ع�Oار = 750
   * ط�"ا�O ۲۴ ع�Oار = 999
   * �?�,ر�? استر�"�O�?گ = 925
   */
  productPurity: number;

  /**
   * �?رخ �?ر گر�. ف�"ز �.رجع ب�? ت�^�.ا�?.
   *
   * �?�.�^�?�?:
   * �?رخ ط�"ا�O ۱۸ ع�Oار با خ�"�^ص �.رجع 750
   * �?رخ �?�,ر�? خا�"ص با خ�"�^ص �.رجع 999
   */
  referencePricePerGramToman: DecimalInput;

  /**
   * خ�"�^ص �?رخ �.رجع.
   *
   * ط�"ا: 750
   * �?�,ر�?: 999
   */
  referencePurity: number;

  makingChargeType: MakingChargeType;

  /**
   * اجرت ثابت ک�" �.حص�^�" ب�? ت�^�.ا�?.
   */
  makingChargeFixedToman?: DecimalInput;

  /**
   * اجرت ب�?�?Oازا�O �?ر گر�. ب�? ت�^�.ا�?.
   */
  makingChargePerGramToman?: DecimalInput;

  /**
   * درصد اجرت از ارزش ف�"ز.
   *
   * �?�.�^�?�?: "12.5"
   */
  makingChargePercent?: DecimalInput;

  /**
   * �?ز�O�?�? اختصاص�O طراح�O �^ اجرا�O �?�?ر�O ا�"�^ر�Oا.
   */
  artisticFeeToman?: DecimalInput;

  /**
   * درصد س�^د فر�^ش�?د�?.
   *
   * �?�.�^�?�?: "7"
   */
  profitPercent: DecimalInput;

  /**
   * درصد �.ا�"�Oات.
   *
   * �?�.�^�?�?: "10"
   */
  taxPercent: DecimalInput;

  /**
   * آ�Oا ارزش خ�^د ف�"ز �?�Oز �.ش�.�^�" �.ا�"�Oات است�Y
   *
   * برا�O ط�"ا�O ساخت�?�?Oشد�? در س�Oاست فع�"�O false است.
   * برا�O سا�Oر ف�"زات از ت�?ظ�O�.ات د�Oتاب�Oس خ�^ا�?د�? �.�O�?Oش�^د.
   */
  taxMetalValue: boolean;

  /**
   * گرد کرد�? �,�O�.ت �?�?ا�O�O.
   *
   * 1 = بد�^�? گرد کرد�? اضاف�O
   * 1000 = گرد کرد�? ب�? �?زد�Oک�?Oتر�O�? �?زار ت�^�.ا�?
   */
  roundingStepToman?: DecimalInput;
};

export type JewelryPriceResult = {
  formulaVersion: "IR_JEWELRY_V1";
  currency: "TOMAN";
  material: MaterialType;

  weightGrams: string;
  productPurity: number;
  referencePurity: number;
  referencePricePerGramToman: string;

  purityRatio: string;

  metalValueToman: string;

  makingChargeFixedToman: string;
  makingChargePerGramTotalToman: string;
  makingChargePercentTotalToman: string;
  makingChargeTotalToman: string;

  artisticFeeToman: string;

  profitBaseToman: string;
  profitPercent: string;
  profitToman: string;

  taxBaseToman: string;
  taxPercent: string;
  taxMetalValue: boolean;
  taxToman: string;

  subtotalBeforeTaxToman: string;
  finalBeforeRoundingToman: string;
  roundingAdjustmentToman: string;
  finalPriceToman: string;
};

const WEIGHT_SCALE = 3;
const PERCENT_SCALE = 3;

function powerOfTen(scale: number) {
  let result = BigInt(1);

  for (
    let index = 0;
    index < scale;
    index += 1
  ) {
    result *= BigInt(10);
  }

  return result;
}

function normalizeDecimalInput(
  value: DecimalInput,
  label: string,
) {
  if (typeof value === "bigint") {
    return value.toString();
  }

  if (typeof value === "number") {
    if (!Number.isFinite(value)) {
      throw new Error(
        `${label} با�Oد عدد �.عتبر باشد.`,
      );
    }

    return value.toString();
  }

  const normalized = value.trim();

  if (!normalized) {
    throw new Error(
      `${label} �?�.�O�?Oت�^ا�?د خا�"�O باشد.`,
    );
  }

  return normalized;
}

function parseNonNegativeScaled(
  value: DecimalInput,
  scale: number,
  label: string,
) {
  const normalized =
    normalizeDecimalInput(
      value,
      label,
    );

  if (
    !/^\d+(?:\.\d+)?$/.test(
      normalized,
    )
  ) {
    throw new Error(
      `${label} با�Oد عدد �.ثبت �Oا صفر باشد.`,
    );
  }

  const [wholePart, fractionPart = ""] =
    normalized.split(".");

  const extraFraction =
    fractionPart.slice(scale);

  if (
    extraFraction.length > 0 &&
    /[1-9]/.test(extraFraction)
  ) {
    throw new Error(
      `${label} حداکثر ${scale} ر�,�. اعشار �.�O�?Oپذ�Oرد.`,
    );
  }

  const normalizedFraction =
    fractionPart
      .slice(0, scale)
      .padEnd(scale, "0");

  const factor = powerOfTen(scale);

  const wholeValue =
    BigInt(wholePart) * factor;

  const fractionValue =
    normalizedFraction.length > 0
      ? BigInt(normalizedFraction)
      : BigInt(0);

  return wholeValue + fractionValue;
}

function parsePositiveScaled(
  value: DecimalInput,
  scale: number,
  label: string,
) {
  const parsed =
    parseNonNegativeScaled(
      value,
      scale,
      label,
    );

  if (parsed <= BigInt(0)) {
    throw new Error(
      `${label} با�Oد ب�Oشتر از صفر باشد.`,
    );
  }

  return parsed;
}

function validatePurity(
  value: number,
  label: string,
) {
  if (
    !Number.isInteger(value) ||
    value <= 0 ||
    value > 1000
  ) {
    throw new Error(
      `${label} با�Oد عدد صح�Oح ب�O�? ۱ تا ۱۰۰۰ باشد.`,
    );
  }

  return value;
}

function parsePercent(
  value: DecimalInput,
  label: string,
  maximum = 100,
) {
  const parsed =
    parseNonNegativeScaled(
      value,
      PERCENT_SCALE,
      label,
    );

  const maximumScaled =
    BigInt(maximum) *
    powerOfTen(PERCENT_SCALE);

  if (parsed > maximumScaled) {
    throw new Error(
      `${label} �?�.�O�?Oت�^ا�?د ب�Oشتر از ${maximum} درصد باشد.`,
    );
  }

  return parsed;
}

function divideRoundHalfUp(
  numerator: bigint,
  denominator: bigint,
) {
  if (denominator <= BigInt(0)) {
    throw new Error(
      "�.خرج �.حاسب�? با�Oد ب�Oشتر از صفر باشد.",
    );
  }

  if (numerator < BigInt(0)) {
    throw new Error(
      "ا�O�? �.�^ت�^ر �.�,دار �.�?ف�O را پشت�Oبا�?�O �?�.�O�?Oک�?د.",
    );
  }

  return (
    numerator +
    denominator / BigInt(2)
  ) / denominator;
}

function calculatePercentAmount(
  baseAmount: bigint,
  percentScaled: bigint,
) {
  const denominator =
    BigInt(100) *
    powerOfTen(PERCENT_SCALE);

  return divideRoundHalfUp(
    baseAmount * percentScaled,
    denominator,
  );
}

function roundToStep(
  value: bigint,
  step: bigint,
) {
  if (step <= BigInt(0)) {
    throw new Error(
      "گا�. گرد کرد�? با�Oد ب�Oشتر از صفر باشد.",
    );
  }

  if (step === BigInt(1)) {
    return value;
  }

  return (
    divideRoundHalfUp(value, step) *
    step
  );
}

function formatScaledValue(
  value: bigint,
  scale: number,
) {
  if (scale === 0) {
    return value.toString();
  }

  const factor = powerOfTen(scale);
  const whole = value / factor;
  const fraction = (
    value % factor
  )
    .toString()
    .padStart(scale, "0")
    .replace(/0+$/, "");

  return fraction
    ? `${whole.toString()}.${fraction}`
    : whole.toString();
}

function includesFixedCharge(
  type: MakingChargeType,
) {
  return (
    type === "FIXED" ||
    type === "COMBINED"
  );
}

function includesPerGramCharge(
  type: MakingChargeType,
) {
  return (
    type === "PER_GRAM" ||
    type === "COMBINED"
  );
}

function includesPercentCharge(
  type: MakingChargeType,
) {
  return (
    type === "PERCENT" ||
    type === "COMBINED"
  );
}

export function calculateJewelryPrice(
  input: JewelryPriceInput,
): JewelryPriceResult {
  const productPurity =
    validatePurity(
      input.productPurity,
      "ع�Oار �.حص�^�"",
    );

  const referencePurity =
    validatePurity(
      input.referencePurity,
      "ع�Oار �.رجع",
    );

  const weightMilliGrams =
    parsePositiveScaled(
      input.weightGrams,
      WEIGHT_SCALE,
      "�^ز�? �.حص�^�"",
    );

  const referencePricePerGram =
    parsePositiveScaled(
      input.referencePricePerGramToman,
      0,
      "�?رخ �?ر گر�. ف�"ز",
    );

  const makingChargeFixed =
    parseNonNegativeScaled(
      input.makingChargeFixedToman ??
        "0",
      0,
      "اجرت ثابت",
    );

  const makingChargePerGram =
    parseNonNegativeScaled(
      input.makingChargePerGramToman ??
        "0",
      0,
      "اجرت گر�.�O",
    );

  const makingChargePercent =
    parsePercent(
      input.makingChargePercent ??
        "0",
      "درصد اجرت",
      100,
    );

  const artisticFee =
    parseNonNegativeScaled(
      input.artisticFeeToman ?? "0",
      0,
      "�?ز�O�?�? کار �?�?ر�O",
    );

  const profitPercent =
    parsePercent(
      input.profitPercent,
      "درصد س�^د",
      100,
    );

  const taxPercent =
    parsePercent(
      input.taxPercent,
      "درصد �.ا�"�Oات",
      100,
    );

  const roundingStep =
    parsePositiveScaled(
      input.roundingStepToman ?? "1",
      0,
      "گا�. گرد کرد�?",
    );

  /*
   * ارزش ف�"ز:
   *
   * �?رخ �.رجع �- �^ز�? �- ع�Oار �.حص�^�"
   * --------------------------------
   * ۱۰۰۰ �- ع�Oار �.رجع
   *
   * �^ز�? با د�,ت �?زار�. گر�. ذخ�Oر�? شد�? است.
   */
  const metalValue =
    divideRoundHalfUp(
      referencePricePerGram *
        weightMilliGrams *
        BigInt(productPurity),
      powerOfTen(WEIGHT_SCALE) *
        BigInt(referencePurity),
    );

  const fixedChargeTotal =
    includesFixedCharge(
      input.makingChargeType,
    )
      ? makingChargeFixed
      : BigInt(0);

  const perGramChargeTotal =
    includesPerGramCharge(
      input.makingChargeType,
    )
      ? divideRoundHalfUp(
          makingChargePerGram *
            weightMilliGrams,
          powerOfTen(WEIGHT_SCALE),
        )
      : BigInt(0);

  const percentChargeTotal =
    includesPercentCharge(
      input.makingChargeType,
    )
      ? calculatePercentAmount(
          metalValue,
          makingChargePercent,
        )
      : BigInt(0);

  const makingChargeTotal =
    fixedChargeTotal +
    perGramChargeTotal +
    percentChargeTotal;

  /*
   * س�^د فر�^ش�?د�? ر�^�O ارزش ف�"ز�O
   * اجرت �^ �?ز�O�?�? کار �?�?ر�O �.حاسب�? �.�O�?Oش�^د.
   */
  const profitBase =
    metalValue +
    makingChargeTotal +
    artisticFee;

  const profit =
    calculatePercentAmount(
      profitBase,
      profitPercent,
    );

  /*
   * در �.ص�?�^عات ط�"ا�O اص�" ف�"ز �.ش�.�^�" �.ا�"�Oات �?�Oست.
   * اجرت�O کار �?�?ر�O �^ س�^د �.ش�.�^�" �.ا�"�Oات�?Oا�?د.
   *
   * برا�O ف�"زات د�Oگر�O taxMetalValue از
   * PricingPolicy د�Oتاب�Oس خ�^ا�?د�? �.�O�?Oش�^د.
   */
  const taxBase =
    makingChargeTotal +
    artisticFee +
    profit +
    (input.taxMetalValue
      ? metalValue
      : BigInt(0));

  const tax =
    calculatePercentAmount(
      taxBase,
      taxPercent,
    );

  const subtotalBeforeTax =
    metalValue +
    makingChargeTotal +
    artisticFee +
    profit;

  const finalBeforeRounding =
    subtotalBeforeTax + tax;

  const finalPrice =
    roundToStep(
      finalBeforeRounding,
      roundingStep,
    );

  const roundingAdjustment =
    finalPrice -
    finalBeforeRounding;

  return {
    formulaVersion:
      "IR_JEWELRY_V1",

    currency: "TOMAN",
    material: input.material,

    weightGrams:
      formatScaledValue(
        weightMilliGrams,
        WEIGHT_SCALE,
      ),

    productPurity,
    referencePurity,

    referencePricePerGramToman:
      referencePricePerGram.toString(),

    purityRatio:
      `${productPurity}/${referencePurity}`,

    metalValueToman:
      metalValue.toString(),

    makingChargeFixedToman:
      fixedChargeTotal.toString(),

    makingChargePerGramTotalToman:
      perGramChargeTotal.toString(),

    makingChargePercentTotalToman:
      percentChargeTotal.toString(),

    makingChargeTotalToman:
      makingChargeTotal.toString(),

    artisticFeeToman:
      artisticFee.toString(),

    profitBaseToman:
      profitBase.toString(),

    profitPercent:
      formatScaledValue(
        profitPercent,
        PERCENT_SCALE,
      ),

    profitToman:
      profit.toString(),

    taxBaseToman:
      taxBase.toString(),

    taxPercent:
      formatScaledValue(
        taxPercent,
        PERCENT_SCALE,
      ),

    taxMetalValue:
      input.taxMetalValue,

    taxToman:
      tax.toString(),

    subtotalBeforeTaxToman:
      subtotalBeforeTax.toString(),

    finalBeforeRoundingToman:
      finalBeforeRounding.toString(),

    roundingAdjustmentToman:
      roundingAdjustment.toString(),

    finalPriceToman:
      finalPrice.toString(),
  };
}
