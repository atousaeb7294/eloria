﻿import type { Metadata } from "next";

import { notFound } from "next/navigation";

import { localizedPageMetadata } from "@/lib/seo";

export const revalidate = 3600;

export async function generateMetadata({
  params,
}: {
  params: Promise<{
    locale: string;
  }>;
}): Promise<Metadata> {
  const { locale } = await params;

  if (locale !== "fa" && locale !== "en") {
    notFound();
  }

  const isPersian = locale === "fa";

  return localizedPageMetadata({
    locale,
    path: "/journal",
    title: isPersian
      ? "�.ج�"�?�" ا�"�^ر�Oا | را�?�?�.ا�O ا�?تخاب �^ �.را�,بت از ج�^ا�?ر"
      : "Eloria Journal | Jewellery guides and stories",
    description: isPersian
      ? "را�?�?�.ا�?ا�O د�,�O�, �^ بازب�O�?�O�?Oشد�?�" ا�"�^ر�Oا برا�O ش�?اخت ج�^ا�?ر�O ا�?تخاب آگا�?ا�?�? �^ �.را�,بت از آثار."
      : "Eloria's reviewed guides for understanding jewellery, making considered choices, and caring for your pieces.",
  });
}

export default function JournalLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}

