﻿import type {
  MetalRateFreshness,
  MetalRateFreshnessReason,
} from "@/lib/metal-rate-freshness";

export type MetalRateSaleMode =
  | "LIVE"
  | "CLOSED_MARKET"
  | "UNAVAILABLE";

export type MetalRateSaleReason =
  | "LIVE_RATE"
  | "CLOSED_MARKET_RATE"
  | "CLOSED_MARKET_DISABLED"
  | "RATE_TOO_OLD"
  | "SOURCE_TIME_INVALID";

type DecimalInput =
  | string
  | number
  | bigint;

export type GetMetalRateSaleDecisionInput = {
  material:
    "GOLD" | "SILVER";

  referencePricePerGramToman:
    DecimalInput;

  freshness:
    Pick<
      MetalRateFreshness,
      | "ageSeconds"
      | "isStale"
      | "reason"
    >;

  closedMarketPricingEnabled:
    boolean;

  /**
   * ب�Oشتر�O�? ز�.ا�?�O ک�? آخر�O�? �?رخ �.عتبر در حا�"ت بازار بست�?
   * �.�O�?Oت�^ا�?د برا�O فر�^ش استفاد�? ش�^د.
   */
  closedMarketMaxAgeMinutes:
    number;

  closedMarketSafetyMarginPercent:
    DecimalInput;
};

export type MetalRateSaleDecision = {
  mode:
    MetalRateSaleMode;

  reason:
    MetalRateSaleReason;

  freshnessReason:
    MetalRateFreshnessReason;

  isUsableForSale:
    boolean;

  ageSeconds:
    number | null;

  originalPricePerGramToman:
    string;

  effectivePricePerGramToman:
    string | null;

  appliedSafetyMarginPercent:
    string;

  safetyMarginAmountToman:
    string;
};

const PERCENT_SCALE =
  3;

const PERCENT_FACTOR =
  BigInt(1000);

const PERCENT_DENOMINATOR =
  BigInt(100) *
  PERCENT_FACTOR;

const CLOSED_MARKET_MARGIN_TIERS = {
  GOLD: [
    { maxAgeHours: 24, percent: "3" },
    { maxAgeHours: 48, percent: "5" },
    { maxAgeHours: 72, percent: "8" },
    { maxAgeHours: 96, percent: "12" },
    { maxAgeHours: 240, percent: "15" },
  ],

  SILVER: [
    { maxAgeHours: 24, percent: "5" },
    { maxAgeHours: 48, percent: "8" },
    { maxAgeHours: 72, percent: "12" },
    { maxAgeHours: 96, percent: "18" },
    { maxAgeHours: 240, percent: "25" },
  ],
} as const;

function getTierSafetyMarginPercent({
  material,
  ageSeconds,
  configuredMinimumPercent,
}: {
  material:
    GetMetalRateSaleDecisionInput["material"];

  ageSeconds:
    number;

  configuredMinimumPercent:
    DecimalInput;
}): bigint {
  const configuredMinimum =
    parseSafetyMarginPercent(
      configuredMinimumPercent,
    );

  const ageHours =
    ageSeconds / 3600;

  const tier =
    CLOSED_MARKET_MARGIN_TIERS[
      material
    ].find(
      (item) =>
        ageHours <=
        item.maxAgeHours,
    ) ??
    CLOSED_MARKET_MARGIN_TIERS[
      material
    ][
      CLOSED_MARKET_MARGIN_TIERS[
        material
      ].length - 1
    ];

  const tierMinimum =
    parseSafetyMarginPercent(
      tier.percent,
    );

  return configuredMinimum >
    tierMinimum
    ? configuredMinimum
    : tierMinimum;
}

function normalizeDecimalInput(
  value: DecimalInput,
  label: string,
): string {
  if (
    typeof value ===
    "bigint"
  ) {
    return value.toString();
  }

  if (
    typeof value ===
    "number"
  ) {
    if (
      !Number.isFinite(
        value,
      )
    ) {
      throw new Error(
        `${label} با�Oد عدد �.عتبر باشد.`,
      );
    }

    return value.toString();
  }

  const normalized =
    value.trim();

  if (
    !normalized
  ) {
    throw new Error(
      `${label} �?�.�O�?Oت�^ا�?د خا�"�O باشد.`,
    );
  }

  return normalized;
}

function parsePositiveInteger(
  value: DecimalInput,
  label: string,
): bigint {
  const normalized =
    normalizeDecimalInput(
      value,
      label,
    );

  if (
    !/^\d+$/.test(
      normalized,
    )
  ) {
    throw new Error(
      `${label} با�Oد عدد صح�Oح �.ثبت باشد.`,
    );
  }

  const parsed =
    BigInt(
      normalized,
    );

  if (
    parsed <=
    BigInt(0)
  ) {
    throw new Error(
      `${label} با�Oد ب�Oشتر از صفر باشد.`,
    );
  }

  return parsed;
}

function parseSafetyMarginPercent(
  value: DecimalInput,
): bigint {
  const normalized =
    normalizeDecimalInput(
      value,
      "درصد حاش�O�? ا�.�?�Oت",
    );

  if (
    !/^\d+(?:\.\d+)?$/.test(
      normalized,
    )
  ) {
    throw new Error(
      "درصد حاش�O�? ا�.�?�Oت �.عتبر �?�Oست.",
    );
  }

  const [
    wholePart,
    fractionPart = "",
  ] =
    normalized.split(
      ".",
    );

  const extraFraction =
    fractionPart.slice(
      PERCENT_SCALE,
    );

  if (
    extraFraction.length >
      0 &&
    /[1-9]/.test(
      extraFraction,
    )
  ) {
    throw new Error(
      "درصد حاش�O�? ا�.�?�Oت حداکثر س�? ر�,�. اعشار �.�O�?Oپذ�Oرد.",
    );
  }

  const normalizedFraction =
    fractionPart
      .slice(
        0,
        PERCENT_SCALE,
      )
      .padEnd(
        PERCENT_SCALE,
        "0",
      );

  const parsed =
    BigInt(
      wholePart,
    ) *
      PERCENT_FACTOR +
    BigInt(
      normalizedFraction,
    );

  const maximumPercent =
    BigInt(100) *
    PERCENT_FACTOR;

  if (
    parsed >
    maximumPercent
  ) {
    throw new Error(
      "درصد حاش�O�? ا�.�?�Oت �?�.�O�?Oت�^ا�?د ب�Oشتر از ۱۰۰ درصد باشد.",
    );
  }

  return parsed;
}

function formatScaledPercent(
  value: bigint,
): string {
  const whole =
    value /
    PERCENT_FACTOR;

  const fraction =
    (
      value %
      PERCENT_FACTOR
    )
      .toString()
      .padStart(
        PERCENT_SCALE,
        "0",
      )
      .replace(
        /0+$/,
        "",
      );

  return fraction
    ? `${whole.toString()}.${fraction}`
    : whole.toString();
}

/**
 * برا�O ج�"�^گ�Oر�O از ک�.تر �.حاسب�?�?Oشد�? حاش�O�? ا�.�?�Oت�O
 * ت�,س�O�. �?�.�Oش�? ر�^ ب�? با�"ا گرد �.�O�?Oش�^د.
 */
function divideRoundUp(
  numerator: bigint,
  denominator: bigint,
): bigint {
  if (
    denominator <=
    BigInt(0)
  ) {
    throw new Error(
      "�.خرج �.حاسب�? با�Oد ب�Oشتر از صفر باشد.",
    );
  }

  if (
    numerator <
    BigInt(0)
  ) {
    throw new Error(
      "�.�,دار �.�?ف�O در ا�O�? �.حاسب�? پشت�Oبا�?�O �?�.�O�?Oش�^د.",
    );
  }

  if (
    numerator ===
    BigInt(0)
  ) {
    return BigInt(0);
  }

  return (
    numerator +
    denominator -
    BigInt(1)
  ) / denominator;
}

function createUnavailableDecision({
  referencePrice,
  freshness,
  reason,
}: {
  referencePrice:
    bigint;

  freshness:
    GetMetalRateSaleDecisionInput["freshness"];

  reason:
    MetalRateSaleReason;
}): MetalRateSaleDecision {
  return {
    mode:
      "UNAVAILABLE",

    reason,

    freshnessReason:
      freshness.reason,

    isUsableForSale:
      false,

    ageSeconds:
      freshness.ageSeconds,

    originalPricePerGramToman:
      referencePrice.toString(),

    effectivePricePerGramToman:
      null,

    appliedSafetyMarginPercent:
      "0",

    safetyMarginAmountToman:
      "0",
  };
}

/**
 * تص�.�O�. �?�?ا�O�O برا�O �,اب�"�?Oاستفاد�?�?Oب�^د�? �?رخ ف�"ز در فر�^ش.
 *
 * �,�^ا�?�O�?:
 *
 * ۱. �?رخ تاز�?:
 *    بد�^�? حاش�O�? ا�.�?�Oت �^ در حا�"ت LIVE استفاد�? �.�O�?Oش�^د.
 *
 * ۲. �?رخ �,د�O�.�O با ز�.ا�? �.عتبر:
 *    ف�,ط تا س�,ف closedMarketMaxAgeMinutes �^ با حاش�O�? ا�.�?�Oت
 *    پ�"کا�?�O �.ت�?اسب با �?�^ع ف�"ز �^ ع�.ر �?رخ در حا�"ت CLOSED_MARKET
 *    استفاد�? �.�O�?Oش�^د.
 *
 * ۳. �?رخ دارا�O ز�.ا�? �.ف�,�^د�O �?ا�.عتبر �Oا آ�O�?د�?:
 *    �,اب�" استفاد�? برا�O فر�^ش �?�Oست.
 *
 * ۴. اگر �,�O�.ت�?Oگذار�O بازار بست�? غ�Oرفعا�" باشد:
 *    �?رخ �,د�O�.�O �,اب�" استفاد�? �?�Oست.
 *
 * باز�? پ�Oش�?Oفرض بازار بست�? تا ۱۰ ر�^ز است. بعد از عب�^ر از س�,ف
 * ت�?ظ�O�.�?Oشد�?�O �?رخ برا�O فر�^ش غ�Oر�,اب�" استفاد�? �.�O�?Oش�^د.
 */
export function getMetalRateSaleDecision(
  input: GetMetalRateSaleDecisionInput,
): MetalRateSaleDecision {
  const {
    material,
    referencePricePerGramToman,
    freshness,
    closedMarketPricingEnabled,
    closedMarketMaxAgeMinutes,
    closedMarketSafetyMarginPercent,
  } =
    input;

  const referencePrice =
    parsePositiveInteger(
      referencePricePerGramToman,
      "�?رخ �.رجع �?ر گر�. ف�"ز",
    );

  /*
   * �?رخ تاز�? بد�^�? حاش�O�? ا�.�?�Oت �,اب�" استفاد�? است.
   */
  if (
    !freshness.isStale
  ) {
    return {
      mode:
        "LIVE",

      reason:
        "LIVE_RATE",

      freshnessReason:
        freshness.reason,

      isUsableForSale:
        true,

      ageSeconds:
        freshness.ageSeconds,

      originalPricePerGramToman:
        referencePrice.toString(),

      effectivePricePerGramToman:
        referencePrice.toString(),

      appliedSafetyMarginPercent:
        "0",

      safetyMarginAmountToman:
        "0",
    };
  }

  /*
   * timestamp �.ف�,�^د�O �?ا�.عتبر �Oا �.رب�^ط ب�? آ�O�?د�?
   * �?با�Oد �^ارد حا�"ت بازار بست�? ش�^د.
   */
  if (
    freshness.reason !==
      "STALE" ||
    freshness.ageSeconds ===
      null ||
    !Number.isFinite(
      freshness.ageSeconds,
    ) ||
    freshness.ageSeconds <
      0
  ) {
    return createUnavailableDecision({
      referencePrice,

      freshness,

      reason:
        "SOURCE_TIME_INVALID",
    });
  }

  /*
   * استفاد�? از �?رخ �,د�O�.�O ف�,ط ز�.ا�?�O �.جاز است
   * ک�? س�Oاست �,�O�.ت�?Oگذار�O بازار بست�? فعا�" باشد.
   */
  if (
    !closedMarketPricingEnabled
  ) {
    return createUnavailableDecision({
      referencePrice,

      freshness,

      reason:
        "CLOSED_MARKET_DISABLED",
    });
  }

  const normalizedMaxAgeMinutes =
    Number.isFinite(closedMarketMaxAgeMinutes)
      ? Math.max(0, Math.trunc(closedMarketMaxAgeMinutes))
      : 0;

  const maximumAgeSeconds =
    normalizedMaxAgeMinutes * 60;

  if (
    maximumAgeSeconds <= 0 ||
    freshness.ageSeconds > maximumAgeSeconds
  ) {
    return createUnavailableDecision({
      referencePrice,
      freshness,
      reason: "RATE_TOO_OLD",
    });
  }

  const safetyMarginPercent =
    getTierSafetyMarginPercent({
      material,
      ageSeconds:
        freshness.ageSeconds,
      configuredMinimumPercent:
        closedMarketSafetyMarginPercent,
    });

  const safetyMarginAmount =
    divideRoundUp(
      referencePrice *
        safetyMarginPercent,

      PERCENT_DENOMINATOR,
    );

  const effectivePrice =
    referencePrice +
    safetyMarginAmount;

  return {
    mode:
      "CLOSED_MARKET",

    reason:
      "CLOSED_MARKET_RATE",

    freshnessReason:
      freshness.reason,

    isUsableForSale:
      true,

    ageSeconds:
      freshness.ageSeconds,

    originalPricePerGramToman:
      referencePrice.toString(),

    effectivePricePerGramToman:
      effectivePrice.toString(),

    appliedSafetyMarginPercent:
      formatScaledPercent(
        safetyMarginPercent,
      ),

    safetyMarginAmountToman:
      safetyMarginAmount.toString(),
  };
}
