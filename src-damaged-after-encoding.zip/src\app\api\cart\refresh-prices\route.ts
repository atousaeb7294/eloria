﻿import {
  NextRequest,
  NextResponse,
} from "next/server";

import {
  getMetalPriceSnapshot,
} from "@/lib/metal-prices";

import {
  consumeRateLimit,
} from "@/lib/security/rate-limit";

import {
  hasTrustedOrigin,
  requestIp,
} from "@/lib/security/request";

export const dynamic =
  "force-dynamic";

export const revalidate =
  0;

export const runtime =
  "nodejs";

function noStoreHeaders() {
  return {
    "Cache-Control":
      "no-store, no-cache, must-revalidate",

    Pragma:
      "no-cache",

    Expires:
      "0",
  };
}

function getLatestSuccessTimestamp(
  timestamps: string[],
): string {
  const validTimestamps =
    timestamps
      .map((timestamp) =>
        Date.parse(timestamp),
      )
      .filter(
        (timestamp) =>
          Number.isFinite(
            timestamp,
          ),
      );

  if (
    validTimestamps.length ===
    0
  ) {
    return new Date()
      .toISOString();
  }

  return new Date(
    Math.max(
      ...validTimestamps,
    ),
  ).toISOString();
}

/**
 * ا�O�? Route سر�^�Oس خارج�O �?رخ ط�"ا �^ �?�,ر�? را فراخ�^ا�?�O �?�.�O�?Oک�?د.
 *
 * ف�,ط آخر�O�? �?رخ�?O�?ا�O ذخ�Oر�?�?Oشد�? در د�Oتاب�Oس �^ س�Oاست �,�O�.ت�?Oگذار�O
 * �?ر ف�"ز را بررس�O �.�O�?Oک�?د.
 *
 * �?�.گا�.�?Oساز�O �^ا�,ع�O �?رخ�?O�?ا ف�,ط از Route ا�.�? Cron ا�?جا�. �.�O�?Oش�^د:
 *
 * GET /api/cron/metal-prices
 */
export async function POST(
  request: NextRequest,
) {
  if (
    !hasTrustedOrigin(
      request,
    )
  ) {
    return NextResponse.json(
      {
        successful:
          false,

        code:
          "FORBIDDEN_ORIGIN",

        message:
          "درخ�^است �.عتبر �?�Oست.",
      },
      {
        status:
          403,

        headers:
          noStoreHeaders(),
      },
    );
  }

  const rate = await consumeRateLimit({
    key: `metal-price-refresh:${requestIp(request)}`,
    limit: 20,
    windowMs: 60_000,
  });

  if (!rate.allowed) {
    return NextResponse.json(
      { successful: false, code: "RATE_LIMITED", message: "تعداد درخ�^است�?O�?ا ب�Oش از حد �.جاز است." },
      { status: 429, headers: { ...noStoreHeaders(), "Retry-After": String(rate.retryAfterSeconds) } },
    );
  }

  try {
    const snapshot =
      await getMetalPriceSnapshot();

    if (
      snapshot.prices.length ===
      0
    ) {
      return NextResponse.json(
        {
          successful:
            false,

          code:
            "METAL_PRICES_NOT_AVAILABLE",

          message:
            "�?�?�^ز �?رخ �.عتبر�O برا�O ط�"ا �Oا �?�,ر�? ثبت �?شد�? است.",
        },
        {
          status:
            503,

          headers:
            noStoreHeaders(),
        },
      );
    }

    const refreshedAt =
      getLatestSuccessTimestamp(
        snapshot.prices.map(
          (price) =>
            price.lastSuccessAt,
        ),
      );

    /*
     * �?رخ�?O�?ا�O�O ک�? از �?ظر ز�.ا�?�O �.�?�,ض�O �?ست�?د�O
     * حت�O اگر طب�, س�Oاست بازار بست�? �?�?�^ز �,اب�" فر�^ش باش�?د.
     */
    const technicallyStaleMaterials =
      snapshot.prices
        .filter(
          (price) =>
            price.isStale,
        )
        .map(
          (price) =>
            price.material,
        );

    /*
     * �?رخ�?O�?ا�O�O ک�? در حا�"ت بازار بست�? �^ با حاش�O�? ا�.�?�Oت
     * �,اب�" استفاد�? �?ست�?د.
     */
    const closedMarketMaterials =
      snapshot.prices
        .filter(
          (price) =>
            price.saleMode ===
            "CLOSED_MARKET",
        )
        .map(
          (price) =>
            price.material,
        );

    /*
     * ف�,ط ا�O�? �?رخ�?O�?ا با�Oد خر�Oد را �.ت�^�,ف ک�?�?د.
     */
    const unavailableMaterials =
      snapshot.prices
        .filter(
          (price) =>
            !price.isUsableForSale,
        )
        .map(
          (price) =>
            price.material,
        );

    const rateStates =
      snapshot.prices.map(
        (price) => ({
          material:
            price.material,

          saleMode:
            price.saleMode,

          saleReason:
            price.saleReason,

          isUsableForSale:
            price.isUsableForSale,

          isStale:
            price.isStale,

          freshnessReason:
            price.freshnessReason,

          ageSeconds:
            price.ageSeconds,

          originalPricePerGramToman:
            price.pricePerGramToman,

          effectivePricePerGramToman:
            price.effectivePricePerGramToman,

          appliedSafetyMarginPercent:
            price.appliedSafetyMarginPercent,

          safetyMarginAmountToman:
            price.safetyMarginAmountToman,

          staleAfterMinutes:
            price.staleAfterMinutes,

          closedMarketMaxAgeMinutes:
            price.closedMarketMaxAgeMinutes,
        }),
      );

    return NextResponse.json(
      {
        successful:
          true,

        refreshed:
          false,

        reused:
          true,

        refreshedAt,

        checkedAt:
          new Date()
            .toISOString(),

        staleAfterMinutes:
          snapshot.staleAfterMinutes,

        /*
         * �^ضع�Oت جد�Oد �^ د�,�O�,
         */
        hasUnavailableRates:
          unavailableMaterials.length >
          0,

        unavailableMaterials,

        hasClosedMarketRates:
          closedMarketMaterials.length >
          0,

        closedMarketMaterials,

        technicallyStaleMaterials,

        rateStates,

        /*
         * سازگار�O �.�^�,ت با �?سخ�? فع�"�O کا�.پ�^�?�?ت سبد خر�Oد:
         * �?رخ بازار بست�? �?با�Oد ب�?�?Oع�?�^ا�? خطا گزارش ش�^د.
         */
        hasStaleRates:
          unavailableMaterials.length >
          0,

        staleMaterials:
          unavailableMaterials,
      },
      {
        status:
          200,

        headers:
          noStoreHeaders(),
      },
    );
  } catch (error) {
    console.error(
      "[Eloria Cart] Unable to read stored metal prices.",
      error,
    );

    return NextResponse.json(
      {
        successful:
          false,

        code:
          "PRICE_REFRESH_FAILED",

        message:
          "بررس�O �?رخ�?O�?ا�O ذخ�Oر�?�?Oشد�? در حا�" حاضر ا�.کا�?�?Oپذ�Oر �?�Oست.",
      },
      {
        status:
          503,

        headers:
          noStoreHeaders(),
      },
    );
  }
}
