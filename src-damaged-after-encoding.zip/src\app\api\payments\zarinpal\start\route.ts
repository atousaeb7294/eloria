﻿import { NextRequest, NextResponse } from "next/server";

import { getCustomerFromRequest } from "@/lib/customer-auth";
import {
  initiateOrderPayment,
  PaymentServiceError,
} from "@/lib/payment-service";
import {
  readPaymentStartAuthorizationCookie,
  verifyPaymentStartAuthorization,
} from "@/lib/payment-start-authorization";
import { prisma } from "@/lib/prisma";
import { consumeRateLimit } from "@/lib/security/rate-limit";
import { hasTrustedOrigin, requestIp } from "@/lib/security/request";
import { JsonRequestBodyError, readJsonBody } from "@/lib/security/json-body";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function noStore() {
  return {
    "Cache-Control": "no-store",
  };
}

export async function POST(request: NextRequest) {
  if (!hasTrustedOrigin(request)) {
    return NextResponse.json(
      {
        successful: false,
        message: "�.بدأ درخ�^است �.عتبر �?�Oست.",
      },
      {
        status: 403,
        headers: noStore(),
      },
    );
  }

  const ip = requestIp(request);
  const rate = await consumeRateLimit({
    key: `payment-start:${ip}`,
    limit: 8,
    windowMs: 60_000,
  });

  if (!rate.allowed) {
    return NextResponse.json(
      {
        successful: false,
        message: "درخ�^است�?O�?ا�O پرداخت ب�Oش از حد �.جاز است.",
      },
      {
        status: 429,
        headers: {
          ...noStore(),
          "Retry-After": String(rate.retryAfterSeconds),
        },
      },
    );
  }

  let body: {
    orderId?: unknown;
  };

  try {
    body = await readJsonBody<{
      orderId?: unknown;
    }>(request, 8 * 1024);
  } catch (error) {
    const bodyError = error instanceof JsonRequestBodyError ? error : null;

    return NextResponse.json(
      {
        successful: false,
        message: bodyError?.message ?? "اط�"اعات پرداخت �.عتبر �?�Oست.",
      },
      {
        status: bodyError?.status ?? 400,
        headers: noStore(),
      },
    );
  }

  if (typeof body.orderId !== "string" || !body.orderId.trim()) {
    return NextResponse.json(
      {
        successful: false,
        message: "اط�"اعات پرداخت �.عتبر �?�Oست.",
      },
      {
        status: 400,
        headers: noStore(),
      },
    );
  }

  const orderId = body.orderId.trim();

  const orderRate = await consumeRateLimit({
    key: `payment-start-order:${orderId}`,
    limit: 6,
    windowMs: 5 * 60_000,
  });

  if (!orderRate.allowed) {
    return NextResponse.json(
      {
        successful: false,
        message: "تعداد ت�"اش برا�O ا�O�? سفارش ب�Oش از حد �.جاز است.",
      },
      {
        status: 429,
        headers: {
          ...noStore(),
          "Retry-After": String(orderRate.retryAfterSeconds),
        },
      },
    );
  }

  const order = await prisma.order.findUnique({
    where: {
      id: orderId,
    },
    select: {
      id: true,
      customerId: true,
      customerMobile: true,
      payableToman: true,
    },
  });

  if (!order) {
    return NextResponse.json(
      {
        successful: false,
        message: "سفارش پ�Oدا �?شد.",
      },
      {
        status: 404,
        headers: noStore(),
      },
    );
  }

  const customerAuth = await getCustomerFromRequest(request);

  let authorized = false;

  if (order.customerId) {
    authorized = customerAuth?.customer.id === order.customerId;
  } else if (order.customerMobile) {
    const token = readPaymentStartAuthorizationCookie(request, order.id);

    authorized = Boolean(
      token &&
      verifyPaymentStartAuthorization(token, {
        orderId: order.id,
        amountToman: order.payableToman.toString(),
        mobile: order.customerMobile,
      }),
    );
  }

  if (!authorized) {
    return NextResponse.json(
      {
        successful: false,
        message: "�.ج�^ز شر�^ع پرداخت �.عتبر �?�Oست.",
      },
      {
        status: 403,
        headers: noStore(),
      },
    );
  }

  try {
    const payment = await initiateOrderPayment(order.id);

    return NextResponse.json(
      {
        successful: true,
        payment,
      },
      {
        headers: noStore(),
      },
    );
  } catch (error) {
    if (error instanceof PaymentServiceError) {
      return NextResponse.json(
        {
          successful: false,
          message: error.message,
        },
        {
          status: error.status,
          headers: noStore(),
        },
      );
    }

    console.error(
      "[Eloria Payment Start] Unexpected payment initialization error.",
      error,
    );

    return NextResponse.json(
      {
        successful: false,
        message: "ارتباط با درگا�? پرداخت ا�?جا�. �?شد. �"طفا�< د�^بار�? ت�"اش ک�?�Oد.",
      },
      {
        status: 502,
        headers: noStore(),
      },
    );
  }
}

