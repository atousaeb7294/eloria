﻿const TROY_OUNCE_GRAMS =
  31.1034768;

const REQUEST_TIMEOUT_MS =
  15_000;

const UNIX_MILLISECONDS_THRESHOLD =
  100_000_000_000;

export type MetalMaterial =
  | "GOLD"
  | "SILVER";

export type FetchedMetalRate = {
  material: MetalMaterial;
  pricePerGramToman: number;
  referencePurity: number;

  source: string;
  sourceSymbol: string;
  sourceUnit: string;

  sourceDate: string | null;
  sourceTime: string | null;
  sourceTimeUnix: number | null;

  rawPayload: Record<
    string,
    unknown
  >;
};

export type RequiredSourceTimestamp = {
  sourceDate: string | null;
  sourceTime: string | null;
  sourceTimeUnix: number | null;
};

function getRequiredApiKey() {
  const apiKey =
    process.env.BRS_API_KEY?.trim();

  if (!apiKey) {
    throw new Error(
      "�.تغ�Oر BRS_API_KEY در فا�O�" .env ت�?ظ�O�. �?شد�? است.",
    );
  }

  return apiKey;
}

function buildApiUrl(
  baseUrl: string,

  parameters: Record<
    string,
    string
  > = {},
) {
  const url =
    new URL(baseUrl);

  url.searchParams.set(
    "key",
    getRequiredApiKey(),
  );

  for (
    const [key, value] of
    Object.entries(parameters)
  ) {
    url.searchParams.set(
      key,
      value,
    );
  }

  return url;
}

async function fetchJson(
  url: URL,
  label: string,
) {
  const controller =
    new AbortController();

  const timeout =
    setTimeout(() => {
      controller.abort();
    }, REQUEST_TIMEOUT_MS);

  try {
    const response =
      await fetch(url, {
        method:
          "GET",

        headers: {
          Accept:
            "application/json",
        },

        cache:
          "no-store",

        signal:
          controller.signal,
      });

    const responseText =
      await response.text();

    if (!response.ok) {
      throw new Error(
        `${label}: خطا�O HTTP ${response.status}`,
      );
    }

    try {
      return JSON.parse(
        responseText,
      );
    } catch {
      throw new Error(
        `${label}: پاسخ API �.عتبر �?�Oست.`,
      );
    }
  } catch (error) {
    if (
      error instanceof Error &&
      error.name ===
        "AbortError"
    ) {
      throw new Error(
        `${label}: ز�.ا�? در�Oافت پاسخ ب�Oشتر از ۱۵ ثا�?�O�? شد.`,
      );
    }

    throw error;
  } finally {
    clearTimeout(
      timeout,
    );
  }
}

function convertIranianPriceToToman(
  price: unknown,
  unit: unknown,
) {
  const numericPrice =
    Number(price);

  if (
    !Number.isFinite(
      numericPrice,
    ) ||
    numericPrice <= 0
  ) {
    throw new Error(
      "�,�O�.ت در�Oافت�?Oشد�? از API �.عتبر �?�Oست.",
    );
  }

  const normalizedUnit =
    String(
      unit ?? "",
    )
      .trim()
      .replace(
        /\s+/g,
        "",
      );

  if (
    normalizedUnit.includes(
      "ت�^�.ا�?",
    )
  ) {
    return numericPrice;
  }

  if (
    normalizedUnit.includes(
      "ر�Oا�"",
    )
  ) {
    return (
      numericPrice /
      10
    );
  }

  throw new Error(
    `�^احد پ�^�" �?اش�?اخت�? است: ${String(unit)}`,
  );
}

function normalizeUnixTime(
  value: unknown,
): number | null {
  const numericValue =
    Number(value);

  return (
    Number.isInteger(
      numericValue,
    ) &&
    numericValue > 0
  )
    ? numericValue
    : null;
}

function unixTimeToMilliseconds(
  value: number,
): number {
  if (
    value >=
    UNIX_MILLISECONDS_THRESHOLD
  ) {
    return value;
  }

  return (
    value *
    1000
  );
}

function getOptionalString(
  value: unknown,
): string | null {
  return typeof value ===
    "string"
    ? value
    : null;
}

/**
 * �?رخ ترک�Oب�O ف�,ط ب�? ا�?داز�? �,د�O�.�O�?Oتر�O�?
 * �^ر�^د�O �.�^رد�?�Oاز خ�^د تاز�? است.
 *
 * �?رخ �?�,ر�? از �,�O�.ت ج�?ا�?�O �?�,ر�? �^ �?رخ د�"ار
 * ساخت�? �.�O�?Oش�^د�> پس timestamp �?�?ا�O�O با�Oد
 * �,د�O�.�O�?Oتر�O�? timestamp ا�O�? د�^ �^ر�^د�O باشد.
 */
export function getOldestRequiredSourceTimestamp(
  firstSource: Record<
    string,
    unknown
  >,

  secondSource: Record<
    string,
    unknown
  >,
): RequiredSourceTimestamp {
  const firstSourceTimeUnix =
    normalizeUnixTime(
      firstSource.time_unix,
    );

  const secondSourceTimeUnix =
    normalizeUnixTime(
      secondSource.time_unix,
    );

  if (
    firstSourceTimeUnix ===
      null ||
    secondSourceTimeUnix ===
      null
  ) {
    return {
      sourceDate:
        null,

      sourceTime:
        null,

      sourceTimeUnix:
        null,
    };
  }

  const firstTimestampMilliseconds =
    unixTimeToMilliseconds(
      firstSourceTimeUnix,
    );

  const secondTimestampMilliseconds =
    unixTimeToMilliseconds(
      secondSourceTimeUnix,
    );

  const useFirstSource =
    firstTimestampMilliseconds <=
    secondTimestampMilliseconds;

  const selectedSource =
    useFirstSource
      ? firstSource
      : secondSource;

  return {
    sourceDate:
      getOptionalString(
        selectedSource.date,
      ),

    sourceTime:
      getOptionalString(
        selectedSource.time,
      ),

    sourceTimeUnix:
      useFirstSource
        ? firstSourceTimeUnix
        : secondSourceTimeUnix,
  };
}

function productionProviderUrl(
  environmentKey: "BRS_GOLD_API_URL" | "BRS_COMMODITY_API_URL",
  fallback: string,
): string {
  const selected = process.env[environmentKey]?.trim() || fallback;
  const url = new URL(selected);

  if (url.protocol !== "https:") {
    throw new Error(`${environmentKey}: ف�,ط HTTPS �.جاز است.`);
  }

  if (
    process.env.NODE_ENV === "production" &&
    url.hostname.toLowerCase() !== "api.brsapi.ir"
  ) {
    throw new Error(`${environmentKey}: در Production ف�,ط Api.BrsApi.ir �.جاز است.`);
  }

  return url.toString();
}

export async function fetchBrsMetalRates(): Promise<
  FetchedMetalRate[]
> {
  const goldApiUrl =
    productionProviderUrl(
      "BRS_GOLD_API_URL",
      "https://Api.BrsApi.ir/Market/Gold_Currency_Pro.php",
    );

  const commodityApiUrl =
    productionProviderUrl(
      "BRS_COMMODITY_API_URL",
      "https://Api.BrsApi.ir/Market/Commodity.php",
    );

  const goldSymbol =
    process.env
      .BRS_GOLD_SYMBOL
      ?.trim() ||
    "IR_GOLD_18K";

  const usdSymbol =
    process.env
      .BRS_USD_SYMBOL
      ?.trim() ||
    "USD";

  const silverSymbol =
    process.env
      .BRS_SILVER_SYMBOL
      ?.trim() ||
    "XAGUSD";

  const marketUrl =
    buildApiUrl(
      goldApiUrl,
      {
        section:
          "gold,currency",
      },
    );

  const marketResponse =
    await fetchJson(
      marketUrl,
      "API ط�"ا �^ ارز",
    );

  if (
    marketResponse
      ?.successful ===
    false
  ) {
    throw new Error(
      marketResponse
        .message_error ||
        "API ط�"ا پاسخ �?ا�.�^ف�, برگردا�?د.",
    );
  }

  const goldItems =
    marketResponse
      ?.gold
      ?.type;

  if (
    !Array.isArray(
      goldItems,
    )
  ) {
    throw new Error(
      "ف�?رست �?رخ�?O�?ا�O ط�"ا در پاسخ API پ�Oدا �?شد.",
    );
  }

  const gold18 =
    goldItems.find(
      (
        item: Record<
          string,
          unknown
        >,
      ) =>
        item.symbol ===
        goldSymbol,
    );

  if (!gold18) {
    throw new Error(
      `�?�.اد ${goldSymbol} در پاسخ ط�"ا پ�Oدا �?شد.`,
    );
  }

  const goldPricePerGramToman =
    Math.round(
      convertIranianPriceToToman(
        gold18.price,
        gold18.unit,
      ),
    );

  const rates: FetchedMetalRate[] = [
    {
      material:
        "GOLD",

      pricePerGramToman:
        goldPricePerGramToman,

      referencePurity:
        750,

      source:
        "BRS_API",

      sourceSymbol:
        goldSymbol,

      sourceUnit:
        String(
          gold18.unit ??
            "ت�^�.ا�?",
        ),

      sourceDate:
        getOptionalString(
          gold18.date,
        ),

      sourceTime:
        getOptionalString(
          gold18.time,
        ),

      sourceTimeUnix:
        normalizeUnixTime(
          gold18.time_unix,
        ),

      rawPayload: {
        gold:
          gold18,
      },
    },
  ];

  /**
   * خراب�O �Oا �.حد�^د�Oت API کا�.�^د�Oت�O �?با�Oد Sync ط�"ا را �.ت�^�,ف ک�?د.
   * در ا�O�? حا�"ت �?رخ �,ب�"�O �?�,ر�? در د�Oتاب�Oس حفظ �.�O�?Oش�^د �^ س�Oاست
   * بازار بست�? دربار�? �,اب�"�?Oفر�^ش�?Oب�^د�? آ�? تص�.�O�. �.�O�?Oگ�Oرد.
   */
  let commodityResponse: Record<string, unknown> | null = null;

  try {
    const commodityUrl =
      buildApiUrl(
        commodityApiUrl,
      );

    commodityResponse =
      await fetchJson(
        commodityUrl,
        "API �?�,ر�?",
      );
  } catch (error) {
    console.warn(
      `�?شدار: Sync �?�,ر�? ا�?جا�. �?شد �^ �?رخ �,ب�"�O حفظ شد. ${
        error instanceof Error
          ? error.message
          : String(error)
      }`,
    );

    return rates;
  }

  try {
    const currencyItems =
      marketResponse
        ?.currency
        ?.free;

    if (
      !Array.isArray(
        currencyItems,
      )
    ) {
      throw new Error(
        "ف�?رست �?رخ ارز در پاسخ API پ�Oدا �?شد.",
      );
    }

    const usd =
      currencyItems.find(
        (
          item: Record<
            string,
            unknown
          >,
        ) =>
          item.symbol ===
          usdSymbol,
      );

    if (!usd) {
      throw new Error(
        `�?�.اد ${usdSymbol} در پاسخ ارز پ�Oدا �?شد.`,
      );
    }

    const preciousMetals =
      commodityResponse
        ?.metal_precious;

    if (
      !Array.isArray(
        preciousMetals,
      )
    ) {
      throw new Error(
        "ف�?رست ف�"زات گرا�?�?Oب�?ا در پاسخ API پ�Oدا �?شد.",
      );
    }

    const silverOunce =
      preciousMetals.find(
        (
          item: Record<
            string,
            unknown
          >,
        ) =>
          item.symbol ===
          silverSymbol,
      );

    if (!silverOunce) {
      throw new Error(
        `�?�.اد ${silverSymbol} در پاسخ �?�,ر�? پ�Oدا �?شد.`,
      );
    }

    const usdPriceToman =
      convertIranianPriceToToman(
        usd.price,
        usd.unit,
      );

    const silverOunceUsd =
      Number(
        silverOunce.price,
      );

    if (
      !Number.isFinite(
        silverOunceUsd,
      ) ||
      silverOunceUsd <= 0
    ) {
      throw new Error(
        "�,�O�.ت ا�?س �?�,ر�? �.عتبر �?�Oست.",
      );
    }

    const silverPricePerGramToman =
      Math.round(
        (
          silverOunceUsd *
          usdPriceToman
        ) /
          TROY_OUNCE_GRAMS,
      );

    const silverRateTimestamp =
      getOldestRequiredSourceTimestamp(
        silverOunce,
        usd,
      );

    rates.push({
      material:
        "SILVER",

      pricePerGramToman:
        silverPricePerGramToman,

      referencePurity:
        999,

      source:
        "BRS_API",

      sourceSymbol:
        silverSymbol,

      sourceUnit:
        "ت�^�.ا�?/گر�.",

      sourceDate:
        silverRateTimestamp
          .sourceDate,

      sourceTime:
        silverRateTimestamp
          .sourceTime,

      sourceTimeUnix:
        silverRateTimestamp
          .sourceTimeUnix,

      rawPayload: {
        silverOunce,

        usd,

        usdPriceToman,

        timestampPolicy:
          "OLDEST_REQUIRED_SOURCE",

        selectedSourceTimeUnix:
          silverRateTimestamp
            .sourceTimeUnix,
      },
    });
  } catch (error) {
    console.warn(
      `�?شدار: پاسخ �?�,ر�? �,اب�" استفاد�? �?ب�^د �^ �?رخ �,ب�"�O حفظ شد. ${
        error instanceof Error
          ? error.message
          : String(error)
      }`,
    );
  }

  return rates;
}

