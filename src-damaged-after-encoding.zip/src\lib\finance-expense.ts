﻿import type {
  FinanceExpenseCategory,
} from "@/generated/prisma/client";

export const financeExpenseCategories: FinanceExpenseCategory[] = [
  "INVENTORY_PURCHASE",
  "SHIPPING_COST",
  "MARKETING",
  "RENT",
  "PAYROLL",
  "GATEWAY_FEE",
  "PACKAGING",
  "TAX",
  "SOFTWARE",
  "OTHER",
];

const labels: Record<
  FinanceExpenseCategory,
  string
> = {
  INVENTORY_PURCHASE: "خر�Oد کا�"ا �Oا ط�"ا",
  SHIPPING_COST: "ارسا�" �^ ح�.�"",
  MARKETING: "تب�"�Oغات �^ بازار�Oاب�O",
  RENT: "اجار�? �^ �?ز�O�?�?�" �.ح�"",
  PAYROLL: "ح�,�^�, �^ دست�.زد",
  GATEWAY_FEE: "کار�.زد درگا�?",
  PACKAGING: "بست�?�?Oب�?د�O",
  TAX: "�.ا�"�Oات �^ ع�^ارض",
  SOFTWARE: "�?ر�.�?Oافزار �^ سر�^�Oس�?O�?ا",
  OTHER: "سا�Oر �?ز�O�?�?�?O�?ا",
};

export function getFinanceExpenseCategoryLabel(
  category: FinanceExpenseCategory,
): string {
  return labels[category];
}

export function isFinanceExpenseCategory(
  value: string,
): value is FinanceExpenseCategory {
  return financeExpenseCategories.includes(
    value as FinanceExpenseCategory,
  );
}

export function isOperatingExpense(
  category: FinanceExpenseCategory,
): boolean {
  return category !==
    "INVENTORY_PURCHASE";
}

