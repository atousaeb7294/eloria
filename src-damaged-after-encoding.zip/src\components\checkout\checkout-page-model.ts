﻿import { readCartItems, type CartItem } from "@/lib/cart-storage";
export type QuotedCartItem = {
  slug: string;
  variantId: string | null;
  quantity: number;

  product: {
    id: string;
    nameFa: string;
    nameEn: string;
    material: "GOLD" | "SILVER";
    sku: string | null;
    stock: number;
    isPurchasable: boolean;
  };

  variant: {
    id: string;
    titleFa: string;
    titleEn: string;
    sku: string | null;
    stock: number;
  } | null;

  pricing: {
    currency: "TOMAN";
    unitPriceToman: string;
    lineTotalToman: string;
  };

  canPurchase: boolean;
  unavailableReason: string | null;
};

export type FailedCartItem = {
  slug: string;
  variantId: string | null;
  quantity: number;
  code: string;
  message: string;
};

export type CartQuoteResponse = {
  successful: true;
  currency: "TOMAN";
  items: QuotedCartItem[];
  failedItems: FailedCartItem[];

  summary: {
    uniqueItems: number;
    totalQuantity: number;
    subtotalToman: string;
    canCheckout: boolean;
  };

  generatedAt: string;
};

export type CreatedOrder = {
  id: string;
  paymentConfigured?: boolean;
  paymentUrl?: string | null;
  paymentMessage?: string;
  orderNumber: string;
  status: string;
  currency: "TOMAN";
  subtotalToman: string;
  payableToman: string;
  priceVerifiedAt: string;
  priceExpiresAt: string;
  inventoryReservedAt: string;
  inventoryExpiresAt: string;

  items: Array<{
    id: string;
    productSlug: string;
    variantId: string | null;
    quantity: number;
    unitPriceToman: string;
    lineTotalToman: string;
    stockBeforeReservation: number;
    stockAfterReservation: number;
  }>;
};

export type CreateOrderResponse = {
  successful: true;
  reused: boolean;
  order: CreatedOrder;
  payment: {
    configured: boolean;
    redirectUrl: string | null;
    message: string;
  };
  requestId: string;
};

export type CustomerForm = {
  fullName: string;
  mobile: string;
  email: string;
  province: string;
  city: string;
  postalCode: string;
  address: string;
};

export type PriceChangeNotice = {
  previousSubtotalToman: string;
  currentSubtotalToman: string;
};

export type CheckoutPageClientProps = {
  locale: "fa" | "en";
  persianTitleClassName: string;
};

export const FA_TEXT = {
  eyebrow: "Eloria Secure Checkout",
  title: "تک�.�O�" سفارش",
  description:
    "�,�O�.ت �^ �.�^ج�^د�O پ�Oش از ثبت سفارش د�^بار�? �.ست�,�O�.ا�< از سر�^ر بررس�O �.�O�?Oش�^د.",

  customerTitle:
    "اط�"اعات خر�Oدار �^ تح�^�O�"",

  customerDescription:
    "اط�"اعات را د�,�O�, �^ �.طاب�, �?شا�?�O در�Oافت سفارش �^ارد ک�?�Oد.",

  fullName:
    "�?ا�. �^ �?ا�. خا�?�^ادگ�O",

  mobile:
    "ش�.ار�? �.�^با�O�"",

  email:
    "ا�O�.�O�" اخت�Oار�O",

  province:
    "استا�?",

  city:
    "ش�?ر",

  postalCode:
    "کد پست�O",

  address:
    "�?شا�?�O کا�.�" تح�^�O�"",

  fullNamePlaceholder:
    "�?ا�. �^ �?ا�. خا�?�^ادگ�O خر�Oدار",

  mobilePlaceholder:
    "�.ث�"ا�< ۰۹۱۲۱۲۳۴۵۶۷",

  emailPlaceholder:
    "example@email.com",

  provincePlaceholder:
    "�?ا�. استا�?",

  cityPlaceholder:
    "�?ا�. ش�?ر",

  postalCodePlaceholder:
    "کد پست�O ۱۰ ر�,�.�O",

  addressPlaceholder:
    "خ�Oابا�?�O ک�^�?�?�O پ�"اک�O �^احد �^ ت�^ض�Oحات �"از�.",

  summary:
    "خ�"اص�? سفارش",

  quantity:
    "تعداد",

  unitPrice:
    "�,�O�.ت �^احد",

  subtotal:
    "�.ب�"غ سفارش",

  payable:
    "�.ب�"غ �,اب�" پرداخت",

  toman:
    "ت�^�.ا�?",

  loading:
    "در حا�" در�Oافت آخر�O�? �,�O�.ت �^ �.�^ج�^د�O...",

  retry:
    "بررس�O د�^بار�?",

  cart:
    "بازگشت ب�? سبد خر�Oد",

  products:
    "�.شا�?د�? �.حص�^�"ات",

  emptyTitle:
    "سبد خر�Oد خا�"�O است",

  emptyDescription:
    "برا�O ادا�.�? پرداخت ابتدا �.حص�^�"�O ب�? سبد خر�Oد اضاف�? ک�?�Oد.",

  unavailable:
    "حدا�,�" �Oک�O از �.حص�^�"ات در حا�" حاضر �,اب�" سفارش �?�Oست.",

  rateFailed:
    "بررس�O �?رخ بازار ا�?جا�. �?شد. ثبت سفارش تا در�Oافت �?رخ �.عتبر �.ت�^�,ف است.",

  priceUpdated:
    "�,�O�.ت سفارش ب�?�?Oر�^زرسا�?�O شد",

  priceUpdatedDescription:
    "�,�O�.ت �Oا �.ب�"غ �Oک�O از �.حص�^�"ات تغ�O�Oر کرد�? است. �.ب�"غ جد�Oد جا�Oگز�O�? شد.",

  previousAmount:
    "�.ب�"غ �,ب�"�O",

  currentAmount:
    "�.ب�"غ جد�Oد",

  submit:
    "ثبت سفارش �^ ادا�.�? پرداخت",

  submitting:
    "در حا�" بررس�O �?�?ا�O�O �^ ثبت سفارش...",

  secureNotice:
    "�.ب�"غ ارسا�"�O �.ر�^رگر پذ�Oرفت�? �?�.�O�?Oش�^د�> �,�O�.ت �?�?ا�O�O ت�^سط سر�^ر ا�"�^ر�Oا �.حاسب�? �.�O�?Oش�^د.",

  reservationNotice:
    "پس از ثبت سفارش�O �.�^ج�^د�O �.حص�^�"ات ب�? �.دت ۱۵ د�,�O�,�? برا�O ش�.ا رزر�^ �.�O�?Oش�^د.",

  orderCreated:
    "سفارش با �.�^ف�,�Oت ثبت شد",

  orderNumber:
    "ش�.ار�? سفارش",

  verifiedAmount:
    "�.ب�"غ تأ�O�Oدشد�? سر�^ر",

  reservedUntil:
    "�.�?�"ت رزر�^ �.�^ج�^د�O",

  gatewayPending:
    "اتصا�" �?�?ا�O�O درگا�? پرداخت �?�.�?Oز�.ا�? با را�?�?Oا�?داز�O �?است �^ دا�.�?�? فعا�" �.�O�?Oش�^د.",

  gatewayButton:
    "درگا�? پرداخت �?�?�^ز فعا�" �?شد�? است",

  changedBeforeSubmit:
    "�,�O�.ت سفارش تغ�O�Oر کرد�? است. �.ب�"غ جد�Oد را بررس�O کرد�? �^ د�^بار�? دک�.�? ادا�.�? پرداخت را بز�?�Oد.",

  genericError:
    "ثبت سفارش در حا�" حاضر ا�.کا�?�?Oپذ�Oر �?�Oست. �"طفا�< د�^بار�? ت�"اش ک�?�Oد.",

  dismiss:
    "بست�? اع�"ا�?",

  lastChecked:
    "آخر�O�? بررس�O",
} as const;

export const EN_TEXT = {
  eyebrow: "Eloria Secure Checkout",
  title: "Complete your order",
  description:
    "Price and availability are verified directly by the server before order creation.",

  customerTitle:
    "Customer and delivery details",

  customerDescription:
    "Enter accurate information for delivery and order processing.",

  fullName:
    "Full name",

  mobile:
    "Mobile number",

  email:
    "Optional email",

  province:
    "Province",

  city:
    "City",

  postalCode:
    "Postal code",

  address:
    "Full delivery address",

  fullNamePlaceholder:
    "Customer full name",

  mobilePlaceholder:
    "Example: 09121234567",

  emailPlaceholder:
    "example@email.com",

  provincePlaceholder:
    "Province",

  cityPlaceholder:
    "City",

  postalCodePlaceholder:
    "10-digit postal code",

  addressPlaceholder:
    "Street, building number, unit, and delivery notes",

  summary:
    "Order summary",

  quantity:
    "Quantity",

  unitPrice:
    "Unit price",

  subtotal:
    "Order amount",

  payable:
    "Payable amount",

  toman:
    "Toman",

  loading:
    "Checking the latest price and availability...",

  retry:
    "Check again",

  cart:
    "Back to shopping bag",

  products:
    "Explore products",

  emptyTitle:
    "Your shopping bag is empty",

  emptyDescription:
    "Add a product to your shopping bag before continuing.",

  unavailable:
    "At least one product is currently unavailable.",

  rateFailed:
    "The market rate could not be verified. Order creation is temporarily unavailable.",

  priceUpdated:
    "Order price updated",

  priceUpdatedDescription:
    "A product price or the order amount changed. The new amount is now displayed.",

  previousAmount:
    "Previous amount",

  currentAmount:
    "New amount",

  submit:
    "Create order and continue",

  submitting:
    "Verifying and creating your order...",

  secureNotice:
    "Browser-submitted amounts are ignored; the final amount is calculated by the Eloria server.",

  reservationNotice:
    "After order creation, inventory is reserved for 15 minutes.",

  orderCreated:
    "Order created successfully",

  orderNumber:
    "Order number",

  verifiedAmount:
    "Server-verified amount",

  reservedUntil:
    "Inventory reserved until",

  gatewayPending:
    "The payment gateway will be activated when hosting and the production domain are connected.",

  gatewayButton:
    "Payment gateway is not active yet",

  changedBeforeSubmit:
    "The order price changed. Review the new amount and submit again.",

  genericError:
    "The order cannot be created right now. Please try again.",

  dismiss:
    "Dismiss notification",

  lastChecked:
    "Last checked",
} as const;

const CHECKOUT_SESSION_KEY =
  "eloria-checkout-idempotency-v1";

export function getCartSnapshot(): string {
  return JSON.stringify(
    readCartItems(),
  );
}

export function getServerCartSnapshot(): string {
  return "[]";
}

export function parseCartSnapshot(
  snapshot: string,
): CartItem[] {
  try {
    const parsed: unknown =
      JSON.parse(snapshot);

    return Array.isArray(parsed)
      ? (parsed as CartItem[])
      : [];
  } catch {
    return [];
  }
}

export function isCartQuoteResponse(
  value: unknown,
): value is CartQuoteResponse {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return false;
  }

  const candidate =
    value as Partial<CartQuoteResponse>;

  return (
    candidate.successful === true &&
    Array.isArray(candidate.items) &&
    Array.isArray(
      candidate.failedItems,
    ) &&
    typeof candidate.summary ===
      "object" &&
    candidate.summary !== null &&
    typeof candidate.generatedAt ===
      "string"
  );
}

export function isCreateOrderResponse(
  value: unknown,
): value is CreateOrderResponse {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return false;
  }

  const candidate =
    value as Partial<CreateOrderResponse>;

  return (
    candidate.successful === true &&
    typeof candidate.reused ===
      "boolean" &&
    typeof candidate.order ===
      "object" &&
    candidate.order !== null &&
    typeof candidate.order.id ===
      "string" &&
    typeof candidate.order.orderNumber ===
      "string" &&
    typeof candidate.order.payableToman ===
      "string" &&
    typeof candidate.order.inventoryExpiresAt ===
      "string" &&
    typeof candidate.payment === "object" &&
    candidate.payment !== null &&
    typeof candidate.payment.configured === "boolean"
  );
}

export function getErrorMessage(
  value: unknown,
  fallback: string,
): string {
  if (
    typeof value === "object" &&
    value !== null &&
    "message" in value &&
    typeof value.message ===
      "string"
  ) {
    return value.message;
  }

  return fallback;
}

export function getItemKey(
  item: {
    slug: string;
    variantId: string | null;
  },
): string {
  return `${item.slug}:${item.variantId ?? "default"}`;
}

export function didQuotePriceChange(
  previousQuote: CartQuoteResponse,
  currentQuote: CartQuoteResponse,
): boolean {
  if (
    previousQuote.summary
      .subtotalToman !==
    currentQuote.summary
      .subtotalToman
  ) {
    return true;
  }

  const previousPrices =
    new Map<string, string>();

  for (
    const item of
    previousQuote.items
  ) {
    previousPrices.set(
      getItemKey(item),
      item.pricing
        .unitPriceToman,
    );
  }

  if (
    previousQuote.items.length !==
    currentQuote.items.length
  ) {
    return true;
  }

  return currentQuote.items.some(
    (item) =>
      previousPrices.get(
        getItemKey(item),
      ) !==
      item.pricing
        .unitPriceToman,
  );
}

export function getCartFingerprint(
  items: CartItem[],
): string {
  return items
    .map((item) => ({
      slug:
        item.slug,

      variantId:
        item.variantId,

      quantity:
        item.quantity,
    }))
    .sort((first, second) =>
      getItemKey(first).localeCompare(
        getItemKey(second),
      ),
    )
    .map(
      (item) =>
        `${getItemKey(item)}:${item.quantity}`,
    )
    .join("|");
}

export function generateIdempotencyKey(): string {
  return `checkout:${window.crypto.randomUUID()}`;
}

export function getOrCreateIdempotencyKey(
  items: CartItem[],
): string {
  const fingerprint =
    getCartFingerprint(items);

  try {
    const stored =
      window.sessionStorage.getItem(
        CHECKOUT_SESSION_KEY,
      );

    if (stored) {
      const parsed: unknown =
        JSON.parse(stored);

      if (
        typeof parsed === "object" &&
        parsed !== null &&
        "fingerprint" in parsed &&
        "key" in parsed &&
        parsed.fingerprint ===
          fingerprint &&
        typeof parsed.key ===
          "string"
      ) {
        return parsed.key;
      }
    }
  } catch {
    // در ص�^رت غ�Oرفعا�" ب�^د�? Session Storage�O ک�"�Oد حافظ�?�?Oا�O استفاد�? �.�O�?Oش�^د.
  }

  const key =
    generateIdempotencyKey();

  try {
    window.sessionStorage.setItem(
      CHECKOUT_SESSION_KEY,
      JSON.stringify({
        fingerprint,
        key,
      }),
    );
  } catch {
    // ادا�.�? فرا�O�?د بد�^�? ذخ�Oر�? Session Storage �.�.ک�? است.
  }

  return key;
}

