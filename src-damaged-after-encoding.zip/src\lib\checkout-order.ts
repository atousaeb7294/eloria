﻿import {
  randomBytes,
} from "node:crypto";

import {
  Prisma,
} from "@/generated/prisma/client";

import {
  CheckoutCustomerError,
  normalizeCheckoutCustomer,
  type CheckoutCustomerInput,
  type NormalizedCheckoutCustomer,
} from "@/lib/checkout-customer";

import {
  getProductLivePrice,
  ProductPricingError,
  type ProductPriceResult,
} from "@/lib/product-pricing";

import {
  checkoutPrisma,
  withCheckoutDatabaseRetry,
} from "@/lib/prisma";

import { syncProductInventory } from "@/lib/inventory";
import { calculateShipping } from "@/lib/shipping";
import {
  hasMatchingCheckoutIdempotencyOwner,
} from "@/lib/checkout-idempotency";

const MAX_CART_ITEMS =
  30;

const MAX_ITEM_QUANTITY =
  99;

const INVENTORY_RESERVATION_MINUTES =
  15;

const TRANSACTION_RETRY_COUNT =
  1;

const CHECKOUT_TRANSACTION_MAX_WAIT_MS =
  3_000;

const CHECKOUT_TRANSACTION_TIMEOUT_MS =
  10_000;

const CONCURRENT_ORDER_LOOKUP_ATTEMPTS =
  2;

const CONCURRENT_ORDER_LOOKUP_DELAY_MS =
  150;

function wait(
  milliseconds: number,
): Promise<void> {
  return new Promise(
    (resolve) => {
      setTimeout(
        resolve,
        milliseconds,
      );
    },
  );
}

function getDatabaseErrorText(
  error: unknown,
): string {
  const parts: string[] = [];

  let current: unknown =
    error;

  for (
    let depth = 0;
    depth < 4;
    depth += 1
  ) {
    if (
      typeof current !== "object" ||
      current === null
    ) {
      if (current !== undefined) {
        parts.push(
          String(current),
        );
      }

      break;
    }

    const candidate =
      current as {
        code?: unknown;
        message?: unknown;
        cause?: unknown;
      };

    if (
      typeof candidate.code ===
      "string"
    ) {
      parts.push(
        candidate.code,
      );
    }

    if (
      typeof candidate.message ===
      "string"
    ) {
      parts.push(
        candidate.message,
      );
    }

    if (!candidate.cause) {
      break;
    }

    current =
      candidate.cause;
  }

  return parts
    .join(" ")
    .toLowerCase();
}

function isTransientDatabaseError(
  error: unknown,
): boolean {
  const text =
    getDatabaseErrorText(
      error,
    );

  return (
    text.includes(
      "econnreset",
    ) ||
    text.includes(
      "etimedout",
    ) ||
    text.includes(
      "connection terminated unexpectedly",
    ) ||
    text.includes(
      "connection terminated due to connection timeout",
    ) ||
    text.includes(
      "unable to start a transaction in the given time",
    ) ||
    text.includes(
      "p2028",
    ) ||
    text.includes(
      "57014",
    ) ||
    text.includes(
      "canceling statement due to statement timeout",
    ) ||
    text.includes(
      "p2010",
    )
  );
}

export type CheckoutOrderItemInput = {
  slug: string;

  variantId:
    string | null;

  quantity:
    number;
};

export type CreateCheckoutOrderInput = {
  idempotencyKey:
    string;

  locale:
    string;

  customer:
    CheckoutCustomerInput;

  items:
    CheckoutOrderItemInput[];

  requestId?:
    string | null;
};

export type CheckoutOrderResult = {
  reused:
    boolean;

  order: {
    id:
      string;

    orderNumber:
      string;

    status:
      string;

    currency:
      "TOMAN";

    subtotalToman:
      string;

    payableToman:
      string;

    priceVerifiedAt:
      string;

    priceExpiresAt:
      string;

    inventoryReservedAt:
      string;

    inventoryExpiresAt:
      string;

    items: Array<{
      id:
        string;

      productSlug:
        string;

      variantId:
        string | null;

      quantity:
        number;

      unitPriceToman:
        string;

      lineTotalToman:
        string;

      stockBeforeReservation:
        number;

      stockAfterReservation:
        number;
    }>;
  };
};

export type CheckoutOrderErrorCode =
  | "INVALID_IDEMPOTENCY_KEY"
  | "IDEMPOTENCY_KEY_CONFLICT"
  | "INVALID_LOCALE"
  | "INVALID_CUSTOMER"
  | "INVALID_CART"
  | "INVALID_CART_ITEM"
  | "TOO_MANY_ITEMS"
  | "PRODUCT_UNAVAILABLE"
  | "INSUFFICIENT_STOCK"
  | "PENDING_ORDER_LIMIT"
  | "PRICE_EXPIRED"
  | "CHECKOUT_BUSY"
  | "PRICING_FAILED"
  | "TRANSACTION_FAILED";

export class CheckoutOrderError extends Error {
  readonly code:
    CheckoutOrderErrorCode;

  readonly status:
    number;

  constructor(
    code:
      CheckoutOrderErrorCode,

    message:
      string,

    status =
      400,
  ) {
    super(message);

    this.name =
      "CheckoutOrderError";

    this.code =
      code;

    this.status =
      status;
  }
}

type PricedCheckoutItem = {
  input:
    CheckoutOrderItemInput;

  result:
    ProductPriceResult;

  unitPriceToman:
    string;

  lineTotalToman:
    string;

  pricingSnapshot:
    Prisma.InputJsonValue;
};

type ReservedCheckoutItem = {
  pricedItem:
    PricedCheckoutItem;

  stockBeforeReservation:
    number;

  stockAfterReservation:
    number;
};

type SerializableOrder = {
  id:
    string;

  orderNumber:
    string;

  status:
    string;

  currency:
    string;

  subtotalToman: {
    toString():
      string;
  };

  payableToman: {
    toString():
      string;
  };

  priceVerifiedAt:
    Date;

  priceExpiresAt:
    Date;

  inventoryReservedAt:
    Date;

  inventoryExpiresAt:
    Date;

  items: Array<{
    id:
      string;

    productSlug:
      string;

    variantId:
      string | null;

    quantity:
      number;

    unitPriceToman: {
      toString():
        string;
    };

    lineTotalToman: {
      toString():
        string;
    };

    stockBeforeReservation:
      number;

    stockAfterReservation:
      number;
  }>;
};

function normalizeIdempotencyKey(
  value:
    string,
): string {
  const normalized =
    value.trim();

  if (
    normalized.length < 16 ||
    normalized.length > 128
  ) {
    throw new CheckoutOrderError(
      "INVALID_IDEMPOTENCY_KEY",

      "ش�?اس�? �Oکتا�O درخ�^است پرداخت �.عتبر �?�Oست.",

      400,
    );
  }

  if (
    !/^[A-Za-z0-9._:-]+$/.test(
      normalized,
    )
  ) {
    throw new CheckoutOrderError(
      "INVALID_IDEMPOTENCY_KEY",

      "ساختار ش�?اس�? �Oکتا�O درخ�^است پرداخت �.عتبر �?�Oست.",

      400,
    );
  }

  return normalized;
}

function normalizeLocale(
  value:
    string,
): string {
  const normalized =
    value
      .trim()
      .toLowerCase();

  if (
    normalized !== "fa" &&
    normalized !== "en"
  ) {
    throw new CheckoutOrderError(
      "INVALID_LOCALE",

      "زبا�? سفارش �.عتبر �?�Oست.",

      400,
    );
  }

  return normalized;
}

function normalizeCustomer(
  customer:
    CheckoutCustomerInput,
): NormalizedCheckoutCustomer {
  try {
    return normalizeCheckoutCustomer(
      customer,
    );
  } catch (error) {
    if (
      error instanceof
      CheckoutCustomerError
    ) {
      throw new CheckoutOrderError(
        "INVALID_CUSTOMER",

        error.message,

        400,
      );
    }

    throw error;
  }
}

function normalizeCheckoutItem(
  item:
    CheckoutOrderItemInput,
): CheckoutOrderItemInput {
  if (
    typeof item !==
      "object" ||
    item === null
  ) {
    throw new CheckoutOrderError(
      "INVALID_CART_ITEM",

      "حدا�,�" �Oک�O از ا�,�"ا�. سبد خر�Oد �.عتبر �?�Oست.",

      400,
    );
  }

  if (
    typeof item.slug !==
      "string"
  ) {
    throw new CheckoutOrderError(
      "INVALID_CART_ITEM",

      "ش�?اس�? �.حص�^�" �.عتبر �?�Oست.",

      400,
    );
  }

  const slug =
    item.slug.trim();

  if (
    !slug ||
    slug.length > 160
  ) {
    throw new CheckoutOrderError(
      "INVALID_CART_ITEM",

      "ش�?اس�? �.حص�^�" �.عتبر �?�Oست.",

      400,
    );
  }

  let variantId:
    string | null = null;

  if (
    typeof item.variantId ===
      "string"
  ) {
    variantId =
      item.variantId.trim() ||
      null;
  } else if (
    item.variantId !== null
  ) {
    throw new CheckoutOrderError(
      "INVALID_CART_ITEM",

      "ش�?اس�? �.د�" �.حص�^�" �.عتبر �?�Oست.",

      400,
    );
  }

  if (
    typeof item.quantity !==
      "number" ||
    !Number.isInteger(
      item.quantity,
    ) ||
    item.quantity < 1 ||
    item.quantity >
      MAX_ITEM_QUANTITY
  ) {
    throw new CheckoutOrderError(
      "INVALID_CART_ITEM",

      "تعداد �.حص�^�" �.عتبر �?�Oست.",

      400,
    );
  }

  return {
    slug,

    variantId,

    quantity:
      item.quantity,
  };
}

function mergeDuplicateItems(
  items:
    CheckoutOrderItemInput[],
): CheckoutOrderItemInput[] {
  const merged =
    new Map<
      string,
      CheckoutOrderItemInput
    >();

  for (
    const item of items
  ) {
    const key =
      `${item.slug}::${item.variantId ?? ""}`;

    const existing =
      merged.get(key);

    if (!existing) {
      merged.set(
        key,
        {
          ...item,
        },
      );

      continue;
    }

    const mergedQuantity =
      existing.quantity +
      item.quantity;

    if (
      mergedQuantity >
      MAX_ITEM_QUANTITY
    ) {
      throw new CheckoutOrderError(
        "INVALID_CART_ITEM",

        "تعداد ا�?تخاب�?Oشد�? برا�O �Oک �.حص�^�" ب�Oش از حد �.جاز است.",

        400,
      );
    }

    existing.quantity =
      mergedQuantity;
  }

  return Array.from(
    merged.values(),
  );
}

function toJsonValue(
  value:
    unknown,
): Prisma.InputJsonValue {
  return JSON.parse(
    JSON.stringify(value),
  ) as Prisma.InputJsonValue;
}

function generateOrderNumber(
  now =
    new Date(),
): string {
  const pad = (
    value:
      number,
  ) =>
    value
      .toString()
      .padStart(
        2,
        "0",
      );

  const timestamp = [
    now
      .getUTCFullYear()
      .toString()
      .slice(-2),

    pad(
      now.getUTCMonth() +
        1,
    ),

    pad(
      now.getUTCDate(),
    ),

    pad(
      now.getUTCHours(),
    ),

    pad(
      now.getUTCMinutes(),
    ),

    pad(
      now.getUTCSeconds(),
    ),
  ].join("");

  const randomPart =
    randomBytes(4)
      .toString("hex")
      .toUpperCase();

  return `ELR${timestamp}${randomPart}`;
}

function getPrismaErrorCode(
  error:
    unknown,
): string | null {
  if (
    typeof error !==
      "object" ||
    error === null ||
    !("code" in error) ||
    typeof error.code !==
      "string"
  ) {
    return null;
  }

  return error.code;
}

function serializeOrder(
  order:
    SerializableOrder,

  reused:
    boolean,
): CheckoutOrderResult {
  return {
    reused,

    order: {
      id:
        order.id,

      orderNumber:
        order.orderNumber,

      status:
        order.status,

      currency:
        "TOMAN",

      subtotalToman:
        order.subtotalToman.toString(),

      payableToman:
        order.payableToman.toString(),

      priceVerifiedAt:
        order.priceVerifiedAt.toISOString(),

      priceExpiresAt:
        order.priceExpiresAt.toISOString(),

      inventoryReservedAt:
        order.inventoryReservedAt.toISOString(),

      inventoryExpiresAt:
        order.inventoryExpiresAt.toISOString(),

      items:
        order.items.map(
          (
            item,
          ) => ({
            id:
              item.id,

            productSlug:
              item.productSlug,

            variantId:
              item.variantId,

            quantity:
              item.quantity,

            unitPriceToman:
              item.unitPriceToman.toString(),

            lineTotalToman:
              item.lineTotalToman.toString(),

            stockBeforeReservation:
              item.stockBeforeReservation,

            stockAfterReservation:
              item.stockAfterReservation,
          }),
        ),
    },
  };
}

async function mapWithConcurrency<
  T,
  R,
>(
  items:
    T[],

  concurrency:
    number,

  mapper: (
    item:
      T,

    index:
      number,
  ) => Promise<R>,
): Promise<R[]> {
  if (
    items.length === 0
  ) {
    return [];
  }

  const output =
    new Array<R>(
      items.length,
    );

  let nextIndex =
    0;

  async function worker() {
    while (true) {
      const currentIndex =
        nextIndex;

      nextIndex +=
        1;

      if (
        currentIndex >=
        items.length
      ) {
        return;
      }

      output[currentIndex] =
        await mapper(
          items[currentIndex],
          currentIndex,
        );
    }
  }

  const workerCount =
    Math.min(
      Math.max(
        concurrency,
        1,
      ),
      items.length,
    );

  await Promise.all(
    Array.from(
      {
        length:
          workerCount,
      },

      () =>
        worker(),
    ),
  );

  return output;
}

async function loadCheckoutPriceWithRetry(
  item:
    CheckoutOrderItemInput,
): Promise<ProductPriceResult> {
  /*
   * ensureDatabaseReady خ�^دش اتصا�" تاز�? را با Retry ک�^تا�? بررس�O �.�O�?Oک�?د �^
   * �.�^ت�^ر �,�O�.ت�?Oگذار�O �?�Oز Query�?ا�O �.�^�,تا�< �?ا�.�^ف�, را Retry �.�O�?Oک�?د. Retry �?�?د�"ا�O�?
   * �,ب�"�O باعث ا�?تظار�?ا�O ۲۰ تا ۳۰ ثا�?�O�?�?Oا�O در اتصا�" سرد �.�O�?Oشد.
   */
  
  return getProductLivePrice({
    slug:
      item.slug,

    variantId:
      item.variantId,
  });
}

async function priceCheckoutItem(
  item:
    CheckoutOrderItemInput,
): Promise<PricedCheckoutItem> {
  try {
    const result =
      await loadCheckoutPriceWithRetry(
        item,
      );

    if (
      !result.product
        .isPurchasable
    ) {
      throw new CheckoutOrderError(
        "PRODUCT_UNAVAILABLE",

        `�.حص�^�" «${result.product.nameFa}» در حا�" حاضر �,اب�" سفارش �?�Oست.`,

        409,
      );
    }

    const availableStock =
      result.variant
        ?.stock ??
      result.product.stock;

    if (
      availableStock <
      item.quantity
    ) {
      throw new CheckoutOrderError(
        "INSUFFICIENT_STOCK",

        `�.�^ج�^د�O �.حص�^�" «${result.product.nameFa}» برا�O تعداد ا�?تخاب�?Oشد�? کاف�O �?�Oست.`,

        409,
      );
    }

    const unitPriceToman =
      result.pricing
        .finalPriceToman;

    const lineTotalToman =
      (
        BigInt(
          unitPriceToman,
        ) *
        BigInt(
          item.quantity,
        )
      ).toString();

    return {
      input:
        item,

      result,

      unitPriceToman,

      lineTotalToman,

      pricingSnapshot:
        toJsonValue({
          product:
            result.product,

          variant:
            result.variant,

          pricing:
            result.pricing,

          liveRate:
            result.liveRate,

          policy:
            result.policy,

          quote:
            result.quote,

          quantity:
            item.quantity,

          unitPriceToman,

          lineTotalToman,
        }),
    };
  } catch (error) {
    if (
      error instanceof
      CheckoutOrderError
    ) {
      throw error;
    }

    if (
      error instanceof
      ProductPricingError
    ) {
      throw new CheckoutOrderError(
        "PRICING_FAILED",

        error.message,

        error.status,
      );
    }

    throw error;
  }
}

function ensureIdempotencyKeyOwnership(
  existingCustomerMobile: string | null,
  requestedCustomerMobile: string,
): void {
  if (
    hasMatchingCheckoutIdempotencyOwner(
      existingCustomerMobile,
      requestedCustomerMobile,
    )
  ) {
    return;
  }

  throw new CheckoutOrderError(
    "IDEMPOTENCY_KEY_CONFLICT",
    "ش�?اس�? �Oکتا�O ا�O�? درخ�^است �,ب�"ا�< �.صرف شد�? است. �"طفا�< د�^بار�? ت�"اش ک�?�Oد.",
    409,
  );
}

async function findExistingOrder(
  idempotencyKey:
    string,
  customerMobile:
    string,
): Promise<CheckoutOrderResult | null> {
  
  const existingOrder =
    await withCheckoutDatabaseRetry(() => checkoutPrisma.order.findUnique({
      where: {
        idempotencyKey,
      },

      include: {
        items: {
          orderBy: {
            createdAt:
              "asc",
          },

          select: {
            id:
              true,

            productSlug:
              true,

            variantId:
              true,

            quantity:
              true,

            unitPriceToman:
              true,

            lineTotalToman:
              true,

            stockBeforeReservation:
              true,

            stockAfterReservation:
              true,
          },
        },
      },
    }), { attempts: 2, delayMilliseconds: 200 });

  if (
    !existingOrder
  ) {
    return null;
  }

  ensureIdempotencyKeyOwnership(
    existingOrder.customerMobile,
    customerMobile,
  );

  return serializeOrder(
    existingOrder,
    true,
  );
}

async function waitForExistingOrder(
  idempotencyKey: string,
  customerMobile: string,
): Promise<CheckoutOrderResult | null> {
  for (
    let attempt = 1;
    attempt <= CONCURRENT_ORDER_LOOKUP_ATTEMPTS;
    attempt += 1
  ) {
    const existingOrder =
      await findExistingOrder(
        idempotencyKey,
        customerMobile,
      );

    if (existingOrder) {
      return existingOrder;
    }

    if (
      attempt <
      CONCURRENT_ORDER_LOOKUP_ATTEMPTS
    ) {
      await wait(
        CONCURRENT_ORDER_LOOKUP_DELAY_MS,
      );
    }
  }

  return null;
}

export async function createCheckoutOrder({
  idempotencyKey,
  locale,
  customer,
  items,
  requestId = null,
}: CreateCheckoutOrderInput): Promise<CheckoutOrderResult> {
  const normalizedIdempotencyKey =
    normalizeIdempotencyKey(
      idempotencyKey,
    );

  const normalizedLocale =
    normalizeLocale(
      locale,
    );

  const normalizedCustomer =
    normalizeCustomer(
      customer,
    );

  if (
    !Array.isArray(items) ||
    items.length === 0
  ) {
    throw new CheckoutOrderError(
      "INVALID_CART",

      "سبد خر�Oد خا�"�O �Oا �?ا�.عتبر است.",

      400,
    );
  }

  if (
    items.length >
    MAX_CART_ITEMS
  ) {
    throw new CheckoutOrderError(
      "TOO_MANY_ITEMS",

      "تعداد ا�,�"ا�. سبد خر�Oد ب�Oش از حد �.جاز است.",

      400,
    );
  }

  const existingOrder =
    await findExistingOrder(
      normalizedIdempotencyKey,
      normalizedCustomer.mobile,
    );

  if (
    existingOrder
  ) {
    return existingOrder;
  }

  const normalizedItems =
    mergeDuplicateItems(
      items.map(
        normalizeCheckoutItem,
      ),
    );

  if (
    normalizedItems.length >
    MAX_CART_ITEMS
  ) {
    throw new CheckoutOrderError(
      "TOO_MANY_ITEMS",

      "حداکثر ۳۰ �.حص�^�" �.تفا�^ت �.�O�?Oت�^ا�?د در سفارش �^ج�^د داشت�? باشد.",

      400,
    );
  }

  const pricedItems =
    await mapWithConcurrency(
      normalizedItems,
      1,
      priceCheckoutItem,
    );

  const subtotalToman =
    pricedItems.reduce(
      (
        total,
        item,
      ) =>
        total +
        BigInt(
          item.lineTotalToman,
        ),

      BigInt(0),
    );

  if (
    subtotalToman <=
    BigInt(0)
  ) {
    throw new CheckoutOrderError(
      "PRICING_FAILED",

      "�.ب�"غ سفارش �.عتبر �?�Oست.",

      422,
    );
  }

  // ELORIA_V3_SERVER_SHIPPING
  const shippingQuote = calculateShipping(subtotalToman);
  const payableToman = subtotalToman + BigInt(shippingQuote.shippingToman);

  const quoteExpirationTimes =
    pricedItems.map(
      (
        item,
      ) =>
        new Date(
          item.result.quote
            .expiresAt,
        ).getTime(),
    );

  if (
    quoteExpirationTimes.some(
      (
        value,
      ) =>
        !Number.isFinite(
          value,
        ),
    )
  ) {
    throw new CheckoutOrderError(
      "PRICING_FAILED",

      "ز�.ا�? اعتبار �,�O�.ت سفارش �.عتبر �?�Oست.",

      500,
    );
  }

  const priceExpiresAt =
    new Date(
      Math.min(
        ...quoteExpirationTimes,
      ),
    );

  const priceVerifiedAt =
    new Date();

  if (
    priceExpiresAt.getTime() <=
    priceVerifiedAt.getTime()
  ) {
    throw new CheckoutOrderError(
      "PRICE_EXPIRED",

      "اعتبار �,�O�.ت سفارش پا�Oا�? �Oافت�? است. �,�O�.ت�?O�?ا با�Oد د�^بار�? بررس�O ش�^�?د.",

      409,
    );
  }

  const inventoryExpiresAt =
    new Date(
      priceVerifiedAt.getTime() +
        INVENTORY_RESERVATION_MINUTES *
          60_000,
    );

  const orderPricingSnapshot =
    toJsonValue({
      currency:
        "TOMAN",

      subtotalToman:
        subtotalToman.toString(),

      shippingToman:
        shippingQuote.shippingToman,

      discountToman:
        "0",

      payableToman:
        payableToman.toString(),

      priceVerifiedAt:
        priceVerifiedAt.toISOString(),

      priceExpiresAt:
        priceExpiresAt.toISOString(),

      customer: {
        fullName:
          normalizedCustomer.fullName,

        mobile:
          normalizedCustomer.mobile,

        email:
          normalizedCustomer.email,

        province:
          normalizedCustomer.province,

        city:
          normalizedCustomer.city,

        postalCode:
          normalizedCustomer.postalCode,

        address:
          normalizedCustomer.address,
      },

      items:
        pricedItems.map(
          (
            item,
          ) => ({
            slug:
              item.result.product
                .slug,

            productId:
              item.result.product
                .id,

            variantId:
              item.result.variant
                ?.id ??
              null,

            quantity:
              item.input.quantity,

            unitPriceToman:
              item.unitPriceToman,

            lineTotalToman:
              item.lineTotalToman,

            pricing:
              item.result.pricing,

            liveRate:
              item.result.liveRate,

            policy:
              item.result.policy,

            quote:
              item.result.quote,
          }),
        ),
    });

  for (
    let attempt =
      1;

    attempt <=
      TRANSACTION_RETRY_COUNT;

    attempt +=
      1
  ) {
    try {
      
      const transactionResult =
        await withCheckoutDatabaseRetry(() => checkoutPrisma.$transaction(
          async (
            transaction,
          ) => {
            const orderAlreadyCreated =
              await transaction.order.findUnique({
                where: {
                  idempotencyKey:
                    normalizedIdempotencyKey,
                },

                include: {
                  items: {
                    orderBy: {
                      createdAt:
                        "asc",
                    },

                    select: {
                      id:
                        true,

                      productSlug:
                        true,

                      variantId:
                        true,

                      quantity:
                        true,

                      unitPriceToman:
                        true,

                      lineTotalToman:
                        true,

                      stockBeforeReservation:
                        true,

                      stockAfterReservation:
                        true,
                    },
                  },
                },
              });

            if (
              orderAlreadyCreated
            ) {
              ensureIdempotencyKeyOwnership(
                orderAlreadyCreated.customerMobile,
                normalizedCustomer.mobile,
              );

              return {
                reused:
                  true,

                order:
                  orderAlreadyCreated,
              };
            }

            const lockRows =
              await transaction.$queryRaw<
                Array<{
                  lockAcquired:
                    boolean;
                }>
              >`
                SELECT
                  pg_try_advisory_xact_lock(
                    hashtext(
                      ${normalizedCustomer.mobile}
                    )
                  ) AS "lockAcquired"
              `;

            if (
              !lockRows[0]
                ?.lockAcquired
            ) {
              throw new CheckoutOrderError(
                "CHECKOUT_BUSY",

                "�Oک درخ�^است ثبت سفارش د�Oگر در حا�" پردازش است. �?�?د �"حظ�? بعد د�^بار�? ت�"اش ک�?�Oد.",

                409,
              );
            }

            const activeReservationCount = await transaction.order.count({
              where: {
                customerMobile: normalizedCustomer.mobile,
                status: { in: ["PENDING_PAYMENT", "PAYMENT_FAILED"] },
                inventoryReleasedAt: null,
                inventoryExpiresAt: { gt: new Date() },
              },
            });

            if (activeReservationCount >= 3) {
              throw new CheckoutOrderError(
                "PENDING_ORDER_LIMIT",
                "ابتدا �Oک�O از سفارش�?O�?ا�O در ا�?تظار پرداخت �,ب�"�O را تک�.�O�" ک�?�Oد.",
                409,
              );
            }

            if (
              priceExpiresAt.getTime() <=
              Date.now()
            ) {
              throw new CheckoutOrderError(
                "PRICE_EXPIRED",

                "اعتبار �,�O�.ت سفارش پا�Oا�? �Oافت�? است. �,�O�.ت�?O�?ا با�Oد د�^بار�? بررس�O ش�^�?د.",

                409,
              );
            }

            const reservedItems:
              ReservedCheckoutItem[] =
                [];

            for (
              const pricedItem of
              pricedItems
            ) {
              const quantity =
                pricedItem.input
                  .quantity;

              const productId =
                pricedItem.result
                  .product.id;

              const selectedVariant =
                pricedItem.result
                  .variant;

              if (
                selectedVariant
              ) {
                const currentVariant =
                  await transaction.productVariant.findUnique({
                    where: {
                      id:
                        selectedVariant.id,
                    },

                    select: {
                      productId:
                        true,

                      stock:
                        true,

                      isActive:
                        true,
                    },
                  });

                if (
                  !currentVariant ||
                  !currentVariant.isActive ||
                  currentVariant.productId !==
                    productId
                ) {
                  throw new CheckoutOrderError(
                    "PRODUCT_UNAVAILABLE",

                    `�.د�" ا�?تخاب�?Oشد�? �.حص�^�" «${pricedItem.result.product.nameFa}» د�Oگر �,اب�" سفارش �?�Oست.`,

                    409,
                  );
                }

                const currentProduct =
                  await transaction.product.findUnique({
                    where: {
                      id: productId,
                    },
                    select: {
                      status: true,
                      stock: true,
                    },
                  });

                if (
                  !currentProduct ||
                  currentProduct.status !== "ACTIVE" ||
                  currentProduct.stock < quantity
                ) {
                  throw new CheckoutOrderError(
                    "INSUFFICIENT_STOCK",
                    `�.�^ج�^د�O ک�"�O �.حص�^�" «${pricedItem.result.product.nameFa}» تغ�O�Oر کرد�? است.`,
                    409,
                  );
                }

                const reservation =
                  await transaction.productVariant.updateMany({
                    where: {
                      id:
                        selectedVariant.id,

                      productId,

                      isActive:
                        true,

                      stock: {
                        gte:
                          quantity,
                      },
                    },

                    data: {
                      stock: {
                        decrement:
                          quantity,
                      },
                    },
                  });

                if (
                  reservation.count !==
                  1
                ) {
                  throw new CheckoutOrderError(
                    "INSUFFICIENT_STOCK",

                    `�.�^ج�^د�O �.حص�^�" «${pricedItem.result.product.nameFa}» تغ�O�Oر کرد�? است.`,

                    409,
                  );
                }

                await syncProductInventory(transaction, productId);

                reservedItems.push({
                  pricedItem,

                  stockBeforeReservation:
                    currentVariant.stock,

                  stockAfterReservation:
                    currentVariant.stock -
                    quantity,
                });

                continue;
              }

              const currentProduct =
                await transaction.product.findUnique({
                  where: {
                    id:
                      productId,
                  },

                  select: {
                    status:
                      true,

                    stock:
                      true,
                  },
                });

              if (
                !currentProduct ||
                currentProduct.status !==
                  "ACTIVE"
              ) {
                throw new CheckoutOrderError(
                  "PRODUCT_UNAVAILABLE",

                  `�.حص�^�" «${pricedItem.result.product.nameFa}» د�Oگر �,اب�" سفارش �?�Oست.`,

                  409,
                );
              }

              const reservation =
                await transaction.product.updateMany({
                  where: {
                    id:
                      productId,

                    status:
                      "ACTIVE",

                    stock: {
                      gte:
                        quantity,
                    },
                  },

                  data: {
                    stock: {
                      decrement:
                        quantity,
                    },
                  },
                });

              if (
                reservation.count !==
                1
              ) {
                throw new CheckoutOrderError(
                  "INSUFFICIENT_STOCK",

                  `�.�^ج�^د�O �.حص�^�" «${pricedItem.result.product.nameFa}» تغ�O�Oر کرد�? است.`,

                  409,
                );
              }

              if (currentProduct.stock - quantity === 0) {
                await transaction.product.updateMany({
                  where: { id: productId, stock: 0, status: "ACTIVE" },
                  data: { status: "OUT_OF_STOCK" },
                });
              }

              reservedItems.push({
                pricedItem,

                stockBeforeReservation:
                  currentProduct.stock,

                stockAfterReservation:
                  currentProduct.stock -
                  quantity,
              });
            }

            const createdOrder =
              await transaction.order.create({
                data: {
                  orderNumber:
                    generateOrderNumber(),

                  idempotencyKey:
                    normalizedIdempotencyKey,

                  locale:
                    normalizedLocale,

                  currency:
                    "TOMAN",

                  status:
                    "PENDING_PAYMENT",

                  customerFullName:
                    normalizedCustomer.fullName,

                  customerMobile:
                    normalizedCustomer.mobile,

                  customerEmail:
                    normalizedCustomer.email,

                  province:
                    normalizedCustomer.province,

                  city:
                    normalizedCustomer.city,

                  postalCode:
                    normalizedCustomer.postalCode,

                  address:
                    normalizedCustomer.address,

                  subtotalToman:
                    subtotalToman.toString(),

                  shippingToman:
        shippingQuote.shippingToman,

                  discountToman:
                    "0",

                  payableToman:
        payableToman.toString(),

                  pricingSnapshot:
                    orderPricingSnapshot,

                  priceVerifiedAt,

                  priceExpiresAt,

                  inventoryReservedAt:
                    priceVerifiedAt,

                  inventoryExpiresAt,

                  items: {
                    create:
                      reservedItems.map(
                        (
                          reservedItem,
                        ) => {
                          const {
                            pricedItem,
                            stockBeforeReservation,
                            stockAfterReservation,
                          } =
                            reservedItem;

                          const {
                            result,
                            input,
                          } =
                            pricedItem;

                          const breakdown =
                            result.pricing
                              .breakdown;

                          return {
                            productId:
                              result.product
                                .id,

                            variantId:
                              result.variant
                                ?.id ??
                              null,

                            productSlug:
                              result.product
                                .slug,

                            productSku:
                              result.product
                                .sku,

                            productNameFa:
                              result.product
                                .nameFa,

                            productNameEn:
                              result.product
                                .nameEn,

                            variantTitleFa:
                              result.variant
                                ?.titleFa ??
                              null,

                            variantTitleEn:
                              result.variant
                                ?.titleEn ??
                              null,

                            variantSku:
                              result.variant
                                ?.sku ??
                              null,

                            material:
                              result.product
                                .material,

                            quantity:
                              input.quantity,

                            unitPriceToman:
                              pricedItem.unitPriceToman,

                            lineTotalToman:
                              pricedItem.lineTotalToman,

                            metalValueToman:
                              breakdown
                                ?.metalValueToman ??
                              null,

                            makingChargeToman:
                              breakdown
                                ?.makingChargeTotalToman ??
                              null,

                            artisticFeeToman:
                              breakdown
                                ?.artisticFeeToman ??
                              null,

                            profitToman:
                              breakdown
                                ?.profitToman ??
                              null,

                            taxToman:
                              breakdown
                                ?.taxToman ??
                              null,

                            originalMetalRateToman:
                              result.liveRate
                                ?.originalPricePerGramToman ??
                              null,

                            effectiveMetalRateToman:
                              result.liveRate
                                ?.effectivePricePerGramToman ??
                              null,

                            metalRateMode:
                              result.liveRate
                                ?.saleMode ??
                              null,

                            metalRateReason:
                              result.liveRate
                                ?.saleReason ??
                              null,

                            safetyMarginPercent:
                              result.liveRate
                                ?.appliedSafetyMarginPercent ??
                              null,

                            safetyMarginToman:
                              result.liveRate
                                ?.safetyMarginAmountToman ??
                              null,

                            stockBeforeReservation,

                            stockAfterReservation,

                            pricingSnapshot:
                              pricedItem.pricingSnapshot,
                          };
                        },
                      ),
                  },

                  auditEvents: {
                    create: {
                      actorType:
                        "CUSTOMER",

                      eventType:
                        "CHECKOUT_ORDER_CREATED",

                      requestId:
                        requestId
                          ?.trim()
                          .slice(
                            0,
                            128,
                          ) ||
                        null,

                      payload:
                        toJsonValue({
                          idempotencyKey:
                            normalizedIdempotencyKey,

                          customerMobile:
                            normalizedCustomer.mobile,

                          itemCount:
                            reservedItems.length,

                          totalQuantity:
                            reservedItems.reduce(
                              (
                                total,
                                item,
                              ) =>
                                total +
                                item.pricedItem
                                  .input
                                  .quantity,

                              0,
                            ),

                          subtotalToman:
                            subtotalToman.toString(),

                          payableToman:
        payableToman.toString(),

                          priceExpiresAt:
                            priceExpiresAt.toISOString(),

                          inventoryExpiresAt:
                            inventoryExpiresAt.toISOString(),
                        }),
                    },
                  },
                },

                include: {
                  items: {
                    orderBy: {
                      createdAt:
                        "asc",
                    },

                    select: {
                      id:
                        true,

                      productSlug:
                        true,

                      variantId:
                        true,

                      quantity:
                        true,

                      unitPriceToman:
                        true,

                      lineTotalToman:
                        true,

                      stockBeforeReservation:
                        true,

                      stockAfterReservation:
                        true,
                    },
                  },
                },
              });

            return {
              reused:
                false,

              order:
                createdOrder,
            };
          },
          {
            isolationLevel:
              "Serializable",

            maxWait:
              CHECKOUT_TRANSACTION_MAX_WAIT_MS,

            timeout:
              CHECKOUT_TRANSACTION_TIMEOUT_MS,
          },
        ), { attempts: 2, delayMilliseconds: 200 });

      return serializeOrder(
        transactionResult.order,
        transactionResult.reused,
      );
    } catch (error) {
      if (
        error instanceof
        CheckoutOrderError
      ) {
        if (
          error.code ===
          "CHECKOUT_BUSY"
        ) {
          const concurrentOrder =
            await waitForExistingOrder(
              normalizedIdempotencyKey,
              normalizedCustomer.mobile,
            );

          if (concurrentOrder) {
            return concurrentOrder;
          }

          if (
            attempt <
            TRANSACTION_RETRY_COUNT
          ) {
            await wait(
              attempt * 300,
            );

            continue;
          }
        }

        throw error;
      }

      const prismaErrorCode =
        getPrismaErrorCode(
          error,
        );

      if (
        prismaErrorCode ===
        "P2002"
      ) {
        const orderCreatedByConcurrentRequest =
          await waitForExistingOrder(
            normalizedIdempotencyKey,
            normalizedCustomer.mobile,
          );

        if (
          orderCreatedByConcurrentRequest
        ) {
          return orderCreatedByConcurrentRequest;
        }
      }

      if (
        (
          prismaErrorCode ===
            "P2034" ||
          prismaErrorCode ===
            "P2028" ||
          isTransientDatabaseError(
            error,
          )
        ) &&
        attempt <
          TRANSACTION_RETRY_COUNT
      ) {
        await wait(
          attempt * 750,
        );

        continue;
      }

      console.error(
        "[Eloria Checkout] Unable to create checkout order.",
        error,
      );

      throw new CheckoutOrderError(
        "TRANSACTION_FAILED",

        "ثبت سفارش در حا�" حاضر ا�.کا�?�?Oپذ�Oر �?�Oست. �"طفا�< د�^بار�? ت�"اش ک�?�Oد.",

        500,
      );
    }
  }

  throw new CheckoutOrderError(
    "TRANSACTION_FAILED",

    "ثبت سفارش در حا�" حاضر ا�.کا�?�?Oپذ�Oر �?�Oست. �"طفا�< د�^بار�? ت�"اش ک�?�Oد.",

    500,
  );
}

