﻿import {
  createHash,
} from "node:crypto";

import type {
  Prisma,
} from "@/generated/prisma/client";

import {
  fetchBrsMetalRates,
  type FetchedMetalRate,
} from "@/lib/brs-market";

import {
  prisma,
} from "@/lib/prisma";
import {
  assessMetalRateAnomaly,
} from "@/lib/metal-rate-anomaly";
import {
  recordSecurityEvent,
} from "@/lib/security/security-events";

type SavedMetalRate = {
  material:
    FetchedMetalRate["material"];

  pricePerGramToman:
    number;

  referencePurity:
    number;

  sourceSymbol:
    string;

  sourceDate:
    string | null;

  sourceTime:
    string | null;

  sourceTimeUnix:
    number | null;

  appliedToCurrent:
    boolean;

  writeReason:
    CurrentRateWriteReason;
};

type ComparableSourceTimeUnix =
  | number
  | bigint
  | null
  | undefined;

export type CurrentRateWriteReason =
  | "CURRENT_TIMESTAMP_MISSING"
  | "BOTH_TIMESTAMPS_MISSING"
  | "INCOMING_TIMESTAMP_MISSING"
  | "INCOMING_IS_OLDER"
  | "INCOMING_IS_NEWER_OR_EQUAL"
  | "ANOMALOUS_RATE_REJECTED";

export type CurrentRateWriteDecision = {
  applyIncoming:
    boolean;

  reason:
    CurrentRateWriteReason;
};

const UNIX_MILLISECONDS_THRESHOLD =
  BigInt(
    100_000_000_000,
  );

const MILLISECONDS_PER_SECOND =
  BigInt(
    1000,
  );

const MAXIMUM_CONCURRENT_WRITE_ATTEMPTS =
  3;

/**
 * timestamp�?ا�O ثا�?�O�?�?Oا�O �^ �.�O�"�O�?Oثا�?�O�?�?Oا�O
 * را برا�O �.�,ا�Oس�? ب�? �.�O�"�O�?Oثا�?�O�? تبد�O�" �.�O�?Oک�?د.
 */
function normalizeSourceTimeUnixToMilliseconds(
  value:
    ComparableSourceTimeUnix,
): bigint | null {
  let normalizedValue:
    bigint;

  if (
    typeof value ===
    "bigint"
  ) {
    normalizedValue =
      value;
  } else if (
    typeof value ===
      "number" &&
    Number.isSafeInteger(
      value,
    )
  ) {
    normalizedValue =
      BigInt(
        value,
      );
  } else {
    return null;
  }

  if (
    normalizedValue <=
    BigInt(0)
  ) {
    return null;
  }

  if (
    normalizedValue >=
    UNIX_MILLISECONDS_THRESHOLD
  ) {
    return normalizedValue;
  }

  return (
    normalizedValue *
    MILLISECONDS_PER_SECOND
  );
}

/**
 * تع�O�O�? �.�O�?Oک�?د �?رخ در�Oافت�O جد�Oد اجاز�? دارد
 * رک�^رد جار�O د�Oتاب�Oس را جا�Oگز�O�? ک�?د �Oا �?�?.
 *
 * �,�^ا�?�O�?:
 *
 * - �?رخ �,د�O�.�O�?Oتر �?رگز �?رخ جد�Oدتر را باز�?�^�Oس�O �?�.�O�?Oک�?د.
 * - �?رخ بد�^�? timestamp جا�O �?رخ timestampدار را �?�.�O�?Oگ�Oرد.
 * - �?رخ timestampدار �.�O�?Oت�^ا�?د رک�^رد بد�^�? timestamp را اص�"اح ک�?د.
 * - timestamp برابر �.جاز است�> �?�^�? �.�.ک�? است �,�O�.ت �?�.ا�? �"حظ�? اص�"اح شد�? باشد.
 */
export function decideCurrentRateWrite({
  currentSourceTimeUnix,
  incomingSourceTimeUnix,
}: {
  currentSourceTimeUnix:
    ComparableSourceTimeUnix;

  incomingSourceTimeUnix:
    ComparableSourceTimeUnix;
}): CurrentRateWriteDecision {
  const currentTimestamp =
    normalizeSourceTimeUnixToMilliseconds(
      currentSourceTimeUnix,
    );

  const incomingTimestamp =
    normalizeSourceTimeUnixToMilliseconds(
      incomingSourceTimeUnix,
    );

  if (
    currentTimestamp ===
      null &&
    incomingTimestamp ===
      null
  ) {
    return {
      applyIncoming:
        true,

      reason:
        "BOTH_TIMESTAMPS_MISSING",
    };
  }

  if (
    currentTimestamp ===
    null
  ) {
    return {
      applyIncoming:
        true,

      reason:
        "CURRENT_TIMESTAMP_MISSING",
    };
  }

  if (
    incomingTimestamp ===
    null
  ) {
    return {
      applyIncoming:
        false,

      reason:
        "INCOMING_TIMESTAMP_MISSING",
    };
  }

  if (
    incomingTimestamp <
    currentTimestamp
  ) {
    return {
      applyIncoming:
        false,

      reason:
        "INCOMING_IS_OLDER",
    };
  }

  return {
    applyIncoming:
      true,

    reason:
      "INCOMING_IS_NEWER_OR_EQUAL",
  };
}

/**
 * برا�O ج�"�^گ�Oر�O از ثبت �?�?دبار�?
 * �Oک �?رخ �Oکسا�? در تار�Oخ�?�?.
 */
function createFingerprint(
  rate:
    FetchedMetalRate,
): string {
  const sourceMoment =
    rate.sourceTimeUnix ??
    `${rate.sourceDate ?? ""}-${rate.sourceTime ?? ""}`;

  return createHash(
    "sha256",
  )
    .update(
      [
        rate.material,
        rate.source,
        rate.sourceSymbol,
        sourceMoment,
        rate.pricePerGramToman,
        rate.referencePurity,
      ].join("|"),
    )
    .digest(
      "hex",
    );
}

/**
 * داد�? API را ب�? JSON سازگار با Prisma
 * تبد�O�" �.�O�?Oک�?د.
 */
function normalizeJson(
  value:
    Record<
      string,
      unknown
    >,
): Prisma.InputJsonValue {
  return JSON.parse(
    JSON.stringify(
      value,
    ),
  ) as Prisma.InputJsonValue;
}

function toNullableBigInt(
  value:
    number | null,
): bigint | null {
  if (
    value ===
    null
  ) {
    return null;
  }

  if (
    !Number.isSafeInteger(
      value,
    ) ||
    value <= 0
  ) {
    return null;
  }

  return BigInt(
    value,
  );
}

function getErrorMessage(
  error:
    unknown,
): string {
  if (
    error instanceof
    Error
  ) {
    return error.message.slice(
      0,
      1000,
    );
  }

  return "خطا�O �?اش�?اخت�? در در�Oافت �Oا ذخ�Oر�? �?رخ";
}

function isUniqueConstraintError(
  error:
    unknown,
): boolean {
  return (
    typeof error ===
      "object" &&
    error !== null &&
    "code" in error &&
    error.code ===
      "P2002"
  );
}

function buildCurrentRateData(
  rate:
    FetchedMetalRate,

  fetchedAt:
    Date,

  rawPayload:
    Prisma.InputJsonValue,
) {
  return {
    pricePerGram:
      String(
        rate.pricePerGramToman,
      ),

    referencePurity:
      rate.referencePurity,

    currency:
      "TOMAN" as const,

    source:
      rate.source,

    sourceSymbol:
      rate.sourceSymbol,

    sourceUnit:
      rate.sourceUnit,

    sourceDate:
      rate.sourceDate,

    sourceTime:
      rate.sourceTime,

    sourceTimeUnix:
      toNullableBigInt(
        rate.sourceTimeUnix,
      ),

    fetchedAt,

    lastSuccessAt:
      fetchedAt,

    lastError:
      null,

    rawPayload,
  };
}

/**
 * �?رخ جار�O را با ک�?تر�" �?�.�?Oز�.ا�?�O ذخ�Oر�? �.�O�?Oک�?د.
 *
 * از تراک�?ش تعا�.�"�O استفاد�? �?�.�O�?Oش�^د تا ر�^�O
 * Supabase Session Pooler خطا�O P2028 ا�Oجاد �?ش�^د.
 */
async function saveCurrentRate(
  rate:
    FetchedMetalRate,

  fetchedAt:
    Date,

  rawPayload:
    Prisma.InputJsonValue,
): Promise<{
  metalPriceId:
    string;

  decision:
    CurrentRateWriteDecision;
}> {
  for (
    let attempt = 1;
    attempt <=
    MAXIMUM_CONCURRENT_WRITE_ATTEMPTS;
    attempt += 1
  ) {
    const currentRate =
      await prisma
        .metalPrice
        .findUnique({
          where: {
            material:
              rate.material,
          },

          select: {
            id:
              true,

            sourceTimeUnix:
              true,

            pricePerGram:
              true,

            updatedAt:
              true,
          },
        });

    const anomaly =
      assessMetalRateAnomaly({
        material: rate.material,
        incomingPricePerGramToman:
          rate.pricePerGramToman,
        currentPricePerGramToman:
          currentRate
            ? Number(
                currentRate.pricePerGram.toString(),
              )
            : null,
      });

    if (!anomaly.safe) {
      const anomalyMessage =
        `ANOMALOUS_RATE:${anomaly.reason}:deviation=${anomaly.deviationPercent ?? "n/a"}`;

      await recordSecurityEvent({
        eventType:
          "METAL_RATE_ANOMALY_REJECTED",
        severity:
          "CRITICAL",
        scope:
          "SYSTEM",
        successful:
          false,
        subject:
          rate.material,
        details: {
          material:
            rate.material,
          incomingPricePerGramToman:
            rate.pricePerGramToman,
          currentPricePerGramToman:
            currentRate
              ? currentRate.pricePerGram.toString()
              : null,
          source:
            rate.source,
          sourceSymbol:
            rate.sourceSymbol,
          reason:
            anomaly.reason,
          deviationPercent:
            anomaly.deviationPercent,
          maximumDeviationPercent:
            anomaly.maximumDeviationPercent,
        },
        dispatchKey:
          `metal-rate-anomaly:${rate.material}`,
      });

      if (!currentRate) {
        throw new Error(
          `�?رخ ا�^�"�O�? ${rate.material} از �.حد�^د�? �.ا�"�O ا�.�? خارج است �^ ذخ�Oر�? �?شد.`,
        );
      }

      const anomalyMetadataUpdate =
        await prisma.metalPrice.updateMany({
          where: {
            id:
              currentRate.id,
            updatedAt:
              currentRate.updatedAt,
          },
          data: {
            lastSuccessAt:
              fetchedAt,
            lastError:
              anomalyMessage.slice(0, 1000),
          },
        });

      if (
        anomalyMetadataUpdate.count === 0
      ) {
        continue;
      }

      return {
        metalPriceId:
          currentRate.id,
        decision: {
          applyIncoming:
            false,
          reason:
            "ANOMALOUS_RATE_REJECTED",
        },
      };
    }

    /**
     * �?�?�^ز �?�O�? رک�^رد�O برا�O ا�O�? ف�"ز �^ج�^د �?دارد.
     */
    if (!currentRate) {
      try {
        const createdRate =
          await prisma
            .metalPrice
            .create({
              data: {
                material:
                  rate.material,

                ...buildCurrentRateData(
                  rate,
                  fetchedAt,
                  rawPayload,
                ),
              },

              select: {
                id:
                  true,
              },
            });

        return {
          metalPriceId:
            createdRate.id,

          decision: {
            applyIncoming:
              true,

            reason:
              rate.sourceTimeUnix ===
              null
                ? "BOTH_TIMESTAMPS_MISSING"
                : "CURRENT_TIMESTAMP_MISSING",
          },
        };
      } catch (error) {
        /**
         * �.�.ک�? است �Oک درخ�^است �?�.�?Oز�.ا�?
         * �?�.�O�? رک�^رد را ساخت�? باشد.
         */
        if (
          isUniqueConstraintError(
            error,
          ) &&
          attempt <
            MAXIMUM_CONCURRENT_WRITE_ATTEMPTS
        ) {
          continue;
        }

        throw error;
      }
    }

    const decision =
      decideCurrentRateWrite({
        currentSourceTimeUnix:
          currentRate.sourceTimeUnix,

        incomingSourceTimeUnix:
          rate.sourceTimeUnix,
      });

    /**
     * پاسخ API �.�^ف�, ب�^د�? ا�.ا timestamp آ�?
     * از �?رخ جار�O �,د�O�.�O�?Oتر �Oا �?ا�.عتبر است.
     *
     * �,�O�.ت �^ timestamp جار�O تغ�O�Oر �?�.�O�?Oک�?�?د.
     * ف�,ط ز�.ا�? آخر�O�? درخ�^است �.�^ف�, �^ خطا�O �,ب�"�O
     * ب�?�?Oر�^زرسا�?�O �.�O�?Oش�^�?د.
     */
    if (
      !decision.applyIncoming
    ) {
      const metadataUpdate =
        await prisma
          .metalPrice
          .updateMany({
            where: {
              id:
                currentRate.id,

              updatedAt:
                currentRate.updatedAt,
            },

            data: {
              lastSuccessAt:
                fetchedAt,

              lastError:
                null,
            },
          });

      /**
       * اگر count صفر باشد�O �Oع�?�O �Oک درخ�^است د�Oگر
       * رک�^رد را �?�.�?Oز�.ا�? تغ�O�Oر داد�? است.
       */
      if (
        metadataUpdate.count ===
        0
      ) {
        continue;
      }

      return {
        metalPriceId:
          currentRate.id,

        decision,
      };
    }

    /**
     * timestamp جد�Oدتر �Oا برابر است�>
     * �?رخ جار�O اجاز�? ب�?�?Oر�^زرسا�?�O دارد.
     */
    const currentRateUpdate =
      await prisma
        .metalPrice
        .updateMany({
          where: {
            id:
              currentRate.id,

            updatedAt:
              currentRate.updatedAt,
          },

          data:
            buildCurrentRateData(
              rate,
              fetchedAt,
              rawPayload,
            ),
        });

    if (
      currentRateUpdate.count ===
      0
    ) {
      continue;
    }

    return {
      metalPriceId:
        currentRate.id,

      decision,
    };
  }

  throw new Error(
    `ذخ�Oر�? �?رخ ${rate.material} ب�?�?Oد�"�O�" تغ�O�Oر �?�.�?Oز�.ا�? د�Oتاب�Oس ا�?جا�. �?شد.`,
  );
}

/**
 * �Oک �?رخ ط�"ا �Oا �?�,ر�? را ذخ�Oر�? �.�O�?Oک�?د.
 */
async function saveSingleRate(
  rate:
    FetchedMetalRate,

  fetchedAt:
    Date,
): Promise<SavedMetalRate> {
  const rawPayload =
    normalizeJson(
      rate.rawPayload,
    );

  const currentWrite =
    await saveCurrentRate(
      rate,
      fetchedAt,
      rawPayload,
    );

  const fingerprint =
    createFingerprint(
      rate,
    );

  /**
   * �?رخ در�Oافت�O حت�O اگر �,د�O�.�O�?Oتر از �?رخ جار�O باشد�O
   * در تار�Oخ�?�? ثبت �.�O�?Oش�^د.
   *
   * ا�O�? رفتار برا�O �.�.�Oز�O �^ بررس�O ک�Oف�Oت
   * پاسخ�?O�?ا�O �.�?بع خارج�O ضر�^ر�O است.
   */
  await prisma
    .metalPriceHistory
    .upsert({
      where: {
        fingerprint,
      },

      /**
       * �?�?گا�. در�Oافت د�^بار�? �?�.ا�? �?رخ�O
       * تار�Oخ�?�? �,ب�"�O دست�?O�?خ�^رد�? با�,�O �.�O�?O�.ا�?د.
       */
      update: {},

      create: {
        metalPriceId:
          currentWrite
            .metalPriceId,

        material:
          rate.material,

        pricePerGram:
          String(
            rate.pricePerGramToman,
          ),

        referencePurity:
          rate.referencePurity,

        currency:
          "TOMAN",

        source:
          rate.source,

        sourceSymbol:
          rate.sourceSymbol,

        sourceUnit:
          rate.sourceUnit,

        sourceDate:
          rate.sourceDate,

        sourceTime:
          rate.sourceTime,

        sourceTimeUnix:
          toNullableBigInt(
            rate.sourceTimeUnix,
          ),

        fetchedAt,

        fingerprint,

        rawPayload,
      },
    });

  return {
    material:
      rate.material,

    pricePerGramToman:
      rate.pricePerGramToman,

    referencePurity:
      rate.referencePurity,

    sourceSymbol:
      rate.sourceSymbol,

    sourceDate:
      rate.sourceDate,

    sourceTime:
      rate.sourceTime,

    sourceTimeUnix:
      rate.sourceTimeUnix,

    appliedToCurrent:
      currentWrite
        .decision
        .applyIncoming,

    writeReason:
      currentWrite
        .decision
        .reason,
  };
}

/**
 * آخر�O�? �?رخ ط�"ا �^ �?�,ر�? را از BRS در�Oافت �.�O�?Oک�?د.
 *
 * �?رخ جار�O با �.حافظت در برابر پاسخ �,د�O�.�O�?Oتر
 * ب�?�?Oر�^زرسا�?�O �.�O�?Oش�^د �^ �?�.�? پاسخ�?O�?ا در جد�^�"
 * تار�Oخ�?�? ثبت �.�O�?Oش�^�?د.
 */
export async function syncMetalPrices(): Promise<
  SavedMetalRate[]
> {
  try {
    const rates =
      await fetchBrsMetalRates();

    if (
      !Array.isArray(
        rates,
      )
    ) {
      throw new Error(
        "ساختار �?رخ�?O�?ا�O در�Oافت�O از BRS �.عتبر �?�Oست.",
      );
    }

    if (
      rates.length ===
      0
    ) {
      throw new Error(
        "�?�O�? �?رخ �.عتبر�O از سر�^�Oس BRS در�Oافت �?شد.",
      );
    }

    const fetchedAt =
      new Date();

    const savedRates:
      SavedMetalRate[] =
      [];

    /**
     * ذخ�Oر�? ترت�Oب�O است تا فشار �?�.�?Oز�.ا�?
     * ر�^�O Connection Pool ا�Oجاد �?ش�^د.
     */
    for (
      const rate of
      rates
    ) {
      if (
        !Number.isFinite(
          rate.pricePerGramToman,
        ) ||
        rate.pricePerGramToman <=
          0
      ) {
        throw new Error(
          `�?رخ ${rate.material} �.عتبر �?�Oست.`,
        );
      }

      if (
        !Number.isInteger(
          rate.referencePurity,
        ) ||
        rate.referencePurity <=
          0 ||
        rate.referencePurity >
          1000
      ) {
        throw new Error(
          `ع�Oار �.رجع ${rate.material} �.عتبر �?�Oست.`,
        );
      }

      const savedRate =
        await saveSingleRate(
          rate,
          fetchedAt,
        );

      savedRates.push(
        savedRate,
      );
    }

    return savedRates;
  } catch (error) {
    const errorMessage =
      getErrorMessage(
        error,
      );

    /**
     * خطا�O آخر برا�O ک�?تر�" س�"ا�.ت �?رخ�?O�?ا ذخ�Oر�? �.�O�?Oش�^د.
     * خطا�O ثبت ا�O�? پ�Oا�. �?با�Oد خطا�O اص�"�O را �.خف�O ک�?د.
     */
    await prisma
      .metalPrice
      .updateMany({
        data: {
          lastError:
            errorMessage,
        },
      })
      .catch(
        () =>
          undefined,
      );

    throw error;
  }
}
